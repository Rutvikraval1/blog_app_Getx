import 'package:flutter/material.dart';
import 'package:sarfix/utils/app_locale.dart';
import 'package:sarfix/widget/Scaffold_widget.dart';

import '../../utils/app_style.dart';
import '../../utils/custColors.dart';
import '../../widget/asset_img/asset_image_show.dart';
import '../refer_earn/refer_Screen.dart';
import '../wallet/wallet_screen.dart';
import 'edit_profile_screen.dart';

class Profile_screen extends StatefulWidget {
  const Profile_screen({super.key});

  @override
  State<Profile_screen> createState() => _Profile_screenState();
}

class _Profile_screenState extends State<Profile_screen> {
  bool dartmode=false;

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        body: SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.grey.shade200,
                        backgroundImage: const AssetImage(AppImages.dummyimg),
                        radius: 70,
                      ),
                      Positioned(
                          bottom: 5,
                          right: 5,
                          child: Asset_imge_show()
                              .SvgPicture_asset(AppImages.edit_icon))
                    ],
                  ),
                  cus_size_box().sizedBox_10,
                  Text(
                    'Rutvik Raval',
                    style: App_style().textS16BoldPtc,
                  ),
                  Text(
                    '+234 84 7227 4922',
                    style: App_style().textS14SemiboldPtc,
                  ),
                  cus_size_box().sizedBox_10,
                ],
              ),
            ),
            const Divider(
              thickness: 0.3,
            ),
            AccountButton(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const EditProfile_screen(),
                    ));
              },
              icon: AppImages.profile_icon,
              text: 'Edit Profile',
            ),
            AccountButton(
              onTap: () {},
              icon: AppImages.notifi_icon,
              text: 'Notification',
            ),
            AccountButton(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const wallet_screen(),
                    ));
              },
              icon: AppImages.wallet_icon,
              text: 'My Wallet',
            ),
            AccountButton(
              onTap: () {},
              icon: AppImages.payment_icon,
              text: 'Payment Method',
            ),
            AccountButton(
              onTap: () {},
              icon: AppImages.lang_icon,
              text: 'Language',
            ),
            AccountButton(
              onTap: () {},
              icon: AppImages.darkmode_icon,
              switchButton: 'true',
              text: 'Dark Mode',
            ),
            AccountButton(
              onTap: () {},
              icon: AppImages.policy_icon,
              text: 'Privacy Policy',
            ),
            AccountButton(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const refer_screen(),
                    ));
              },
              icon: AppImages.refer_icon,
              text: 'Refer & Earn',
            ),
            const Divider(
              thickness: 0.3,
            ),
            AccountButton(
              onTap: () {},
              icon: AppImages.logout_icon,
              text: 'Logout',
            ),
          ],
        ),
      ),
    ));
  }

  Widget AccountButton({
    required String text,
    required Function onTap,
    String? switchButton,
    required String icon}){
    return ListTile(
      onTap: (){
        onTap();
      },
      visualDensity: const VisualDensity(vertical: -3),
      leading: Asset_imge_show().SvgPicture_asset(icon, width: 24, height: 24),
      title: Text(
        text,
        style: App_style().textS14MediumPriTextColor,
      ),

      trailing: switchButton!=null?Transform.scale(
        scale: 0.6,
        alignment: Alignment.centerRight,
        child: Switch(
          value: dartmode,
          inactiveTrackColor: AppColors.whiteColor,
          activeTrackColor:  AppColors.whiteColor,
          thumbColor: MaterialStatePropertyAll<Color>(AppColors.primaryTextColor.withOpacity(0.2)),
          trackOutlineWidth: const MaterialStatePropertyAll<double?>(0.4),
          onChanged: (value) {
            setState(() {
              dartmode = value;
            });
          },
        ),
      )
     :const SizedBox(
          width: 30,
          child: Icon(Icons.arrow_forward_ios, size: 18)),
    );
  }
}
