
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:sarfix/screen/SignUp/verification_screen.dart';
import 'package:sarfix/screen/auth_screen/login_screen.dart';
import 'package:sarfix/utils/custColors.dart';
import 'package:sarfix/widget/Scaffold_widget.dart';

import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../widget/appbar_common.dart';
import '../../widget/asset_img/asset_image_show.dart';
import '../../widget/button/cus_navigateBtn.dart';
import '../../widget/input/CommonTextField.dart';

class createAccountScreen extends StatefulWidget {
  const createAccountScreen({super.key});

  @override
  State<createAccountScreen> createState() => _createAccountScreenState();
}

class _createAccountScreenState extends State<createAccountScreen> {
  TextEditingController Fname=TextEditingController();
  TextEditingController Lname=TextEditingController();
  TextEditingController Mobile=TextEditingController();
  TextEditingController email=TextEditingController();
  TextEditingController password=TextEditingController();
  TextEditingController referral_code=TextEditingController();


  bool ChangeTab=true;
  bool Terms_privacy=false;

  List category_list = [];
  var dropdownValue;
  String category_name = '';

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Scaffold_widget(
        appBar: AppBar(
          title:Row(
            children: [
              Text('Step ',style: App_style().textS14RegularOpacity,),
              Text(
                  ChangeTab?'1':'2',
                  style: App_style().textS14MediumPriTextColor),
              Text('/2',style: App_style().textS14RegularOpacity),
            ],
          ),
          titleSpacing: 15,
          backgroundColor: Colors.transparent,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          leadingWidth:65,
          automaticallyImplyLeading: false,
          leading:Padding(
            padding: const EdgeInsets.only(left: 20),
            child: GestureDetector(
                onTap: (){
                  if(ChangeTab){
                    Navigator.pop(context);
                  }else{
                    ChangeTab=true;
                    setState(() {});
                  }
                },
                child: Asset_imge_show().SvgPicture_asset(AppImages.back_arrow,width: 25)),
          ),
          bottom:PreferredSize(
            preferredSize: const Size.fromHeight(8),
            child: Column(
              children: [
                Row(
                  children: [
                    const SizedBox(width: 20,),
                    Expanded(
                      child: Container(
                        height: 4.0,
                        decoration: BoxDecoration(
                            color: AppColors.primaryColorBlue,
                          borderRadius: BorderRadius.circular(30)
                        ),
                      ),
                    ),
                    const SizedBox(width: 10,),
                    Expanded(
                      child: Container(
                        height: 4.0,
                        decoration: BoxDecoration(
                            color:ChangeTab?AppColors.primaryColorBlue.withOpacity(0.1):AppColors.primaryColorBlue,
                            borderRadius: BorderRadius.circular(30)
                        ),
                      ),
                    ),
                    const SizedBox(width: 20,),
                  ],
                ),
              ],
            ),
          )
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if(ChangeTab)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(Common_text.createAC, style: App_style().textS24SemiboldPtc),
                        Text(Common_text.welcomeText2, style: App_style().textS14SemiboldPtc),
                        cus_size_box().sizedBox_30,
                        Row(
                          children: [
                            Expanded(child: CommonText_Title.textField_title(text: 'First name*')),
                            const SizedBox(width: 20,),
                            Expanded(child: CommonText_Title.textField_title(text: 'Last name*'))
                          ],
                        ),
                        cus_size_box().sizedBox_5,
                        Row(
                          children: [
                            Expanded(
                              child: CustomInput(controller: Fname,hintText: 'Enter first name'),
                            ),
                            const SizedBox(width: 20,),
                            Expanded(
                              child: CustomInput(controller: Lname,hintText: 'Enter last name'),
                            ),
                          ],
                        ),
                        cus_size_box().sizedBox_15,
                        CommonText_Title.textField_title(text: 'Mobile Number*'),
                        cus_size_box().sizedBox_5,
                        CustomInput(controller: Mobile,hintText: 'Enter mobile number'),
                        cus_size_box().sizedBox_15,
                        CommonText_Title.textField_title(text: 'Email*'),
                        cus_size_box().sizedBox_5,
                        CustomInput(controller: email,hintText: 'example12@gmail.com'),
                        cus_size_box().sizedBox_15,
                        CommonText_Title.textField_title(text: Common_text.password),
                        cus_size_box().sizedBox_5,
                        CustomInput(controller: password,hintText: '*********',suffixIcon: true),
                        cus_size_box().sizedBox_15,
                        CommonText_Title.textField_title(text: 'Referral Code'),
                        cus_size_box().sizedBox_5,
                        CustomInput(controller: email,hintText: 'Enter your referral code'),
                      ],
                    ),

                    if(!ChangeTab)
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(Common_text.createAC, style: App_style().textS24SemiboldPtc),
                          Text(Common_text.welcomeText2, style: App_style().textS14SemiboldPtc),
                          cus_size_box().sizedBox_30,
                          CommonText_Title.textField_title(text: 'Company Name*'),
                          cus_size_box().sizedBox_5,
                          CustomInput(controller: Mobile,hintText: 'Enter company name'),
                          cus_size_box().sizedBox_15,
                          CommonText_Title.textField_title(text: 'No of Employee'),
                          cus_size_box().sizedBox_5,
                          CustomInput(controller: email,hintText: 'Enter company name'),
                          cus_size_box().sizedBox_15,
                          CommonText_Title.textField_title(text: 'Company Address'),
                          cus_size_box().sizedBox_5,
                          CustomInput(controller: password,hintText: 'Enter company address'),
                          cus_size_box().sizedBox_15,
                          CommonText_Title.textField_title(text: 'Select your Business Category '),
                          cus_size_box().sizedBox_5,
                          Container(
                              decoration: ShapeDecoration(
                                shape: RoundedRectangleBorder(
                                  side:   BorderSide(
                                    width: 1,
                                      color: AppColors.primaryTextColor.withOpacity(0.1)
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 20),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton(
                                    value: dropdownValue,
                                    icon: const Icon(Icons.keyboard_arrow_down_outlined),
                                    iconSize: 20,
                                    isExpanded: true,
                                    hint:  Text('Select your Business Category',
                                      style: App_style().textS16withOpacity,),
                                    onChanged: (newValue) {
                                      setState(() {
                                        dropdownValue = newValue;
                                        category_name = newValue.toString();
                                      });
                                    },
                                    items: category_list.map<DropdownMenuItem>((value) {
                                      return DropdownMenuItem(
                                        value: value,
                                        child: Text(value),
                                      );
                                    }).toList(),
                                  ),
                                ),
                              )),
                          cus_size_box().sizedBox_15,
                          Row(
                            children: [
                              Checkbox(value: Terms_privacy, onChanged: (value){
                                if(value!=null){
                                  Terms_privacy=value;
                                  setState(() {});
                                }
                              }),
                              Expanded(
                                child: Text.rich(
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                  textAlign: TextAlign.start,
                                  TextSpan(
                                    text: 'I accept the ',
                                    style: App_style().textS16withOpacity,
                                    children: <TextSpan>[
                                      TextSpan(
                                          text: 'Terms of Service ',
                                          // recognizer: TapGestureRecognizer()..onTap = () => ),
                                          style: App_style().textS16RegularBlue),
                                      TextSpan(
                                          text: 'and ',
                                          style: App_style().textS16withOpacity),
                                      TextSpan(
                                          text: 'Privacy Policy',
                                          // recognizer: TapGestureRecognizer()..onTap = () => Navigator.push(context, MaterialPageRoute(builder: (context) => const login_screen(),)),
                                          style: App_style().textS16RegularBlue),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                  ],
                ),
          ),
        ),
        bottomNavigationBar: Container(
          padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: BottomAppBar(
            elevation: 0,
            height: height / 5.8,
            padding:
            const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
            color: Colors.transparent,
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                        child: cus_navigateBtn(
                          onPressed: () {
                            FocusScope.of(context).requestFocus(FocusNode());
                            if(ChangeTab){
                              ChangeTab=false;
                              setState(() {});
                            }else{
                              Navigator.push(context, MaterialPageRoute(builder: (context) => const verification_screen(),)).then((value){
                                ChangeTab=false;
                                setState(() {});
                              });
                            }

                          },
                          text: ChangeTab?'Next':'Submit',
                        )),
                  ],
                ),
                cus_size_box().sizedBox_15,
                Text.rich(
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                  textAlign: TextAlign.center,
                  TextSpan(
                    text: 'Don’t have an account? ',
                    style: App_style().textS16SemiboldwithOpacity,
                    children: <TextSpan>[
                      TextSpan(
                          text: 'Log in',
                          recognizer: TapGestureRecognizer()..onTap = () => Navigator.push(context, MaterialPageRoute(builder: (context) => const login_screen(),)),
                          style: App_style().textS16BoldPtc),
                    ],
                  ),
                ),
              ],
            ),
          ),
        )
    );
  }
}
