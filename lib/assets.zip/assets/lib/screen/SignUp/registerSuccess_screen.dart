
import 'package:flutter/material.dart';
import 'package:sarfix/utils/app_locale.dart';
import 'package:sarfix/widget/Scaffold_widget.dart';
import 'package:sarfix/widget/asset_img/asset_image_show.dart';

import '../../utils/app_style.dart';
import '../../widget/button/cus_navigateBtn.dart';
import '../main_home_screen.dart';

class registerSuccess_screen extends StatefulWidget {
  const registerSuccess_screen({super.key});

  @override
  State<registerSuccess_screen> createState() => _registerSuccess_screenState();
}

class _registerSuccess_screenState extends State<registerSuccess_screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(body: Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Asset_imge_show().SvgPicture_asset(AppImages.register_success_img),
            cus_size_box().sizedBox_20,
            Text('Lorem ipsum dolor sit amet, consectetur adipiscing '
              'elit, sed do eiusmod tempor incididunt ut.', textAlign: TextAlign.center,style: App_style().textS16withOpacity),

          ],
        ),
      ),
    ),
        bottomNavigationBar: Container(
          padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: BottomAppBar(
            elevation: 0,
            padding:
            const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
            color: Colors.transparent,
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                        child: cus_navigateBtn(
                          onPressed: () {
                            FocusScope.of(context).requestFocus(FocusNode());
                            Navigator.push(context, MaterialPageRoute(builder: (context) => const Main_home_screen()));
                          },
                          text:'Done',
                        )),
                  ],
                ),
              ],
            ),
          ),
        ));
  }
}
