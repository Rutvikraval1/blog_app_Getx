

import 'package:flutter/material.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/otp_field_style.dart';
import 'package:otp_text_field/style.dart';
import 'package:sarfix/screen/SignUp/registerSuccess_screen.dart';
import 'package:sarfix/utils/app_locale.dart';
import 'package:sarfix/widget/Scaffold_widget.dart';

import '../../utils/app_style.dart';
import '../../utils/custColors.dart';
import '../../widget/appbar_common.dart';
import '../../widget/button/cus_navigateBtn.dart';

class verification_screen extends StatefulWidget {
  const verification_screen({super.key});

  @override
  State<verification_screen> createState() => _verification_screenState();
}

class _verification_screenState extends State<verification_screen> {
  OtpFieldController otpController =OtpFieldController();
  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(leading_ontap: () {
          Navigator.pop(context);
        }),
        body: SingleChildScrollView(
          child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Verification Code', style: App_style().textS24SemiboldPtc),
            Text.rich(
              overflow: TextOverflow.ellipsis,
              maxLines: 3,
              textAlign: TextAlign.start,
              TextSpan(
                text: 'We have sent the code verification to your number ',
                style: App_style().textS16withOpacity,
                children: <TextSpan>[
                  TextSpan(
                      text: '(+234) 543-0909',
                      style: App_style().textS14MediumPriTextColor),
                ],
              ),
            ),
            cus_size_box().sizedBox_40,
            OTPTextField(
                controller: otpController,
                length: 4,
                width: MediaQuery.of(context).size.width,
                textFieldAlignment: MainAxisAlignment.spaceAround,
                fieldStyle: FieldStyle.box,
                fieldWidth:  MediaQuery.of(context).size.width / 9,
                otpFieldStyle: OtpFieldStyle(
                  focusBorderColor: AppColors.primaryTextColor.withOpacity(0.1),
                ),
                // style: text_style().text_black,
                onChanged: (pin) {
                  // smscode_check = pin;
                }),
            cus_size_box().sizedBox_40,
            Text.rich(
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
              textAlign: TextAlign.start,
              TextSpan(
                text: 'Didn’t received any code? ',
                style: App_style().textS16SemiboldwithOpacity,
                children: <TextSpan>[
                  TextSpan(
                      text: ' Resend OTP',
                      // recognizer: TapGestureRecognizer()..onTap = () => Navigator.push(context, MaterialPageRoute(builder: (context) => const login_screen(),)),
                      style: App_style().textS16BoldPtc),
                ],
              ),
            ),
          ],
                ),
              ),
        ),
        bottomNavigationBar: Container(
          padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: BottomAppBar(
            elevation: 0,
            padding:
            const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
            color: Colors.transparent,
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                        child: cus_navigateBtn(
                          onPressed: () {
                            FocusScope.of(context).requestFocus(FocusNode());
                            Navigator.push(context, MaterialPageRoute(builder: (context) => const registerSuccess_screen()));
                          },
                          text:'Continue',
                        )),
                  ],
                ),
              ],
            ),
          ),
        ));
  }
}
