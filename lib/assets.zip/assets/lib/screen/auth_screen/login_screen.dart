import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:sarfix/screen/auth_screen/signup_screen.dart';
import 'package:sarfix/widget/Scaffold_widget.dart';
import 'package:sarfix/widget/appbar_common.dart';

import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../widget/button/cus_navigateBtn.dart';
import '../../widget/input/CommonTextField.dart';
import '../main_home_screen.dart';

class login_screen extends StatefulWidget {
  const login_screen({super.key});

  @override
  State<login_screen> createState() => _login_screenState();
}

class _login_screenState extends State<login_screen> {
  TextEditingController email=TextEditingController();
  TextEditingController password=TextEditingController();



  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Scaffold_widget(
        appBar: appbarCommon(leading_ontap: () {
          Navigator.pop(context);
        }),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(Common_text.login, style: App_style().textS24SemiboldPtc),
                Text(Common_text.welcomeText, style: App_style().textS14SemiboldPtc),
                cus_size_box().sizedBox_30,
                CommonText_Title.textField_title(text: Common_text.email),
                cus_size_box().sizedBox_5,
                CustomInput(controller: email,hintText: 'example12@gmail.com'),
                cus_size_box().sizedBox_30,
                CommonText_Title.textField_title(text: Common_text.password),
                cus_size_box().sizedBox_5,
                CustomInput(controller: password,hintText: '*********',suffixIcon: true),
                cus_size_box().sizedBox_5,
                Align(
                    alignment: Alignment.topRight,
                    child: Text(Common_text.forgetPassword, style: App_style().textS16Medium_blue)),
              ],
            ),
          ),
        ),
        bottomNavigationBar: Container(
          padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: BottomAppBar(
            elevation: 0,
            height: height / 5.8,
            padding:
            const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
            color: Colors.transparent,
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                        child: cus_navigateBtn(
                          onPressed: () {
                            FocusScope.of(context).requestFocus(FocusNode());
                            // controller.login_api();
                            print('submit');
                            Navigator.push(context, MaterialPageRoute(builder: (context) => const Main_home_screen(),));
                          },
                          text: 'Log in',
                        )),
                  ],
                ),
                cus_size_box().sizedBox_15,
                Text.rich(
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                  textAlign: TextAlign.center,
                  TextSpan(
                    text: 'Don’t have an account? ',
                    style: App_style().textS16SemiboldwithOpacity,
                    children: <TextSpan>[
                      TextSpan(
                          text: 'Sign up',
                          recognizer: TapGestureRecognizer()..onTap = () => Navigator.push(context, MaterialPageRoute(builder: (context) => const signup_screen(),)),
                          style: App_style().textS16BoldPtc),
                    ],
                  ),
                ),
              ],
            ),
          ),
        )
    );
  }
}
