
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../widget/Scaffold_widget.dart';
import '../../widget/appbar_common.dart';
import '../../widget/button/cus_navigateBtn.dart';
import '../../widget/input/CommonTextField.dart';

class signup_screen extends StatefulWidget {
  const signup_screen({super.key});

  @override
  State<signup_screen> createState() => _signup_screenState();
}

class _signup_screenState extends State<signup_screen> {
  TextEditingController fullName=TextEditingController();
  TextEditingController email=TextEditingController();
  TextEditingController password=TextEditingController();



  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Scaffold_widget(
        appBar: appbarCommon(leading_ontap: () {
          Navigator.pop(context);
        }),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(Common_text.createAC, style: App_style().textS24SemiboldPtc),
                Text(Common_text.welcomeText2, style: App_style().textS14SemiboldPtc),
                cus_size_box().sizedBox_30,
                CommonText_Title.textField_title(text: Common_text.fullName),
                cus_size_box().sizedBox_10,
                CustomInput(controller: email,hintText: 'Enter your full name'),
                cus_size_box().sizedBox_30,
                CommonText_Title.textField_title(text: Common_text.email),
                cus_size_box().sizedBox_10,
                CustomInput(controller: email,hintText: 'example12@gmail.com'),
                cus_size_box().sizedBox_30,
                CommonText_Title.textField_title(text: Common_text.password),
                cus_size_box().sizedBox_10,
                CustomInput(controller: password,hintText: '*********',suffixIcon: true),
                cus_size_box().sizedBox_5,
              ],
            ),
          ),
        ),
        bottomNavigationBar: Container(
          padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: BottomAppBar(
            elevation: 0,
            height: height / 5.8,
            padding:
            const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
            color: Colors.transparent,
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                        child: cus_navigateBtn(
                          onPressed: () {
                            FocusScope.of(context).requestFocus(FocusNode());
                            // controller.login_api();
                            print('submit');
                          },
                          text: 'Sign up',
                        )),
                  ],
                ),
                cus_size_box().sizedBox_15,
                Text.rich(
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                  textAlign: TextAlign.center,
                  TextSpan(
                    text: 'Already have an account? ',
                    style: App_style().textS16SemiboldwithOpacity,
                    children: <TextSpan>[
                      TextSpan(
                          text: 'Log in',
                          recognizer: TapGestureRecognizer()..onTap = () => Navigator.pop(context),
                          style: App_style().textS16BoldPtc),
                    ],
                  ),
                ),
              ],
            ),
          ),
        )
    );
  }
}
