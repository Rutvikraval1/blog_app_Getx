
import 'package:flutter/material.dart';
import 'package:sarfix/utils/app_locale.dart';
import 'package:sarfix/utils/app_style.dart';
import 'package:sarfix/utils/custColors.dart';
import 'package:sarfix/widget/Scaffold_widget.dart';
import 'package:sarfix/widget/asset_img/asset_image_show.dart';

import '../../widget/appbar_common.dart';
import '../../widget/button/cus_navigateBtn.dart';
import '../../widget/down_up/custom_accordion.dart';
class refer_screen extends StatefulWidget {
  const refer_screen({super.key});

  @override
  State<refer_screen> createState() => _refer_screenState();
}

class _refer_screenState extends State<refer_screen> {

  List referwork=[
    'What is refer and earn program?',
    'Where can i use this coins?',
    'How can i earn coins?',
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(title_text: 'Refer & Earn',leading_ontap: () {
          Navigator.pop(context);
        }),
        body: SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  cus_size_box().sizedBox_20,
                  SizedBox(
                      height: 84,
                      width: 84,
                      child: Asset_imge_show().SvgPicture_asset(AppImages.referGift_icon)),
                  cus_size_box().sizedBox_20,
                  Text('Refer your friends, and earn!',style: App_style().textS20SemiboldPtc,),
                  Text('Refer a friend earn coins! They get XX coins on signup, more on protection plan purchase.',
                    textAlign:TextAlign.center,style: App_style().textS14SemiboldPtc,),
                ],
              ),
            ),
            cus_size_box().sizedBox_20,
            Align(
              alignment: Alignment.center,
              child: Container(
                width: MediaQuery.of(context).size.width/1.4,
                decoration: BoxDecoration(
                    color: AppColors.whiteColor,
                  border: Border.all(color:AppColors.primaryTextColor.withOpacity(0.2))
                ),
                padding: const EdgeInsets.all(10),
                child: IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(child: Text('1234567895623524',overflow: TextOverflow.ellipsis,style: App_style().textS16Semibold)),
                      const VerticalDivider(
                        color: Colors.black,
                        thickness: 0.5,
                      ),
                      const SizedBox(width: 10,),
                      GestureDetector(
                        onTap: (){},
                        child: Row(
                          children: [
                            Asset_imge_show().SvgPicture_asset(AppImages.copy_icon),
                            const SizedBox(width: 5,),
                            Text('Copy',style: App_style().textS14MediumPriTextColor,)
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ),
            ),
            cus_size_box().sizedBox_20,
            Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        FocusScope.of(context).requestFocus(FocusNode());
                        print('submit');
                      },
                      text: 'Share with Friends',
                    )),
              ],
            ),
            cus_size_box().sizedBox_10,
            const Divider(thickness: 0.3,),
            cus_size_box().sizedBox_10,
            Text('How it works?',style: App_style().textS16Semibold,),
            cus_size_box().sizedBox_10,
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: referwork.length,
              itemBuilder: (context, index) => Column(
              children: [
                CustomAccordion(
                    title: referwork[index],
                    content: Text('')),
                cus_size_box().sizedBox_10,
              ],
            ),)
            ,
          ],
        ),
      ),
    ));
  }
}
