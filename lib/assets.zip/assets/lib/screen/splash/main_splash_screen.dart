import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:sarfix/utils/app_locale.dart';
import 'package:sarfix/utils/app_style.dart';
import 'package:sarfix/utils/custColors.dart';
import 'package:sarfix/widget/Scaffold_widget.dart';
import 'package:sarfix/widget/asset_img/asset_image_show.dart';

import '../../widget/button/cus_navigateBtn.dart';
import '../SignUp/create_account_screen.dart';
import '../auth_screen/login_screen.dart';
import '../auth_screen/signup_screen.dart';

class mainSplashScreen extends StatefulWidget {
  const mainSplashScreen({super.key});

  @override
  State<mainSplashScreen> createState() => _mainSplashScreenState();
}

class _mainSplashScreenState extends State<mainSplashScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
      body: Container(
        // height: MediaQuery.of(context).size.height,
        // width: MediaQuery.of(context).size.width,
        // decoration: const BoxDecoration(
        //     image: DecorationImage(
        //         image: AssetImage(AppImages.splash_img), fit: BoxFit.fill)),
        child: Stack(
          children: [
            Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(AppImages.backSplashScreen),
                      fit: BoxFit.fill)),
              alignment: Alignment.centerRight,
            ),
                Positioned.fill(
                    child: Padding(
                      padding: const EdgeInsets.only(top:30),
                      child: Align(
                          alignment: Alignment.topCenter,
                          child: Asset_imge_show().Img_asset(AppImages.appmainLogo,height: 85)),
                    )),
                Positioned(
                  bottom: 20,
                    width: MediaQuery.of(context).size.width,
                    child: ContainerColums(context))
          ],
        ),
      ),
    );
  }

  Widget ContainerColums(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Text(
            'Get your packages delivered safely to you',
            style: App_style().textS24boldPtcwhiteColor,
          ),
          cus_size_box().sizedBox_10,
          Text(
            'We pack and ship packages from anywhere in the world to the comfort of your home',
            style: App_style().textS14RegularwhiteColor,
          ),
          cus_size_box().sizedBox_10,
          Row(
            children: [
              Expanded(
                child: cus_navigateBtn(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const login_screen(),
                        ));
                  },
                  text: 'Log in',
                ),
              ),
            ],
          ),
          cus_size_box().sizedBox_10,
          Row(
            children: [
              Expanded(
                child: cus_navigateBtn(
                  backgroundColor: Colors.transparent,
                  border: 'true',
                  onPressed: () {
                    showBrandsBottomSheet(context);
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //       builder: (context) => const createAccountScreen(),
                    //     ));
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //       builder: (context) => const signup_screen(),
                    //     ));
                  },
                  text: 'Create Account',
                ),
              ),
            ],
          )
        ],
      ),
    );
  }


  Future showBrandsBottomSheet(BuildContext context) {
    return showModalBottomSheet<void>(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25), topRight: Radius.circular(25)),
      ),
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      builder: (BuildContext _) {
        return SizedBox(
          height: MediaQuery.of(context).size.height / 2,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 30),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Container(
                    height: 5,
                    width: 50,
                    decoration: BoxDecoration(
                      color: AppColors.primaryTextColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(30)
                    ),
                  ),
                  cus_size_box().sizedBox_20,
                  Text('Choose the option that best\n describes you',textAlign: TextAlign.center,style: App_style().textS16SemiboldBlue,),
                  cus_size_box().sizedBox_20,
                  Container(
                    color: AppColors.whiteColor,
                    child: ListTile(
                      onTap: (){
                        Navigator.pop(context);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const createAccountScreen(),
                            ));
                      },
                      leading: const SizedBox(
                        height: 100,
                        width: 100,
                      ),
                      title: Text('Register as Business',style: App_style().textS16SemiboldPtc,),
                      subtitle: Text('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',style: App_style().textS12RegularOpacity,),
                    ),
                  ),
                  cus_size_box().sizedBox_20,
                  Container(
                    color: AppColors.whiteColor,
                    child: ListTile(
                      onTap: (){

                        Navigator.pop(context);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const signup_screen(),
                            ));
                      },
                      leading: const SizedBox(
                        height: 100,
                        width: 100,
                      ),
                      title: Text('Register as Individual',style: App_style().textS16SemiboldPtc,),
                      subtitle: Text('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',style: App_style().textS12RegularOpacity,),
                    ),
                  ),
                  cus_size_box().sizedBox_20,
                  Text.rich(
                    overflow: TextOverflow.ellipsis,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    TextSpan(
                      text: 'Already have an account? ',
                      style: App_style().textS16SemiboldwithOpacity,
                      children: <TextSpan>[
                        TextSpan(
                            text: 'Log in',
                            recognizer: TapGestureRecognizer()..onTap = (){
                              Navigator.pop(context);
                              Navigator.push(context, MaterialPageRoute(builder: (context) => const login_screen(),));
                            } ,
                            style: App_style().textS16BoldPtc),
                      ],
                    ),
                  ),

                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
