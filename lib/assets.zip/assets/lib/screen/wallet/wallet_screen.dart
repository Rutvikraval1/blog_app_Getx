
import 'package:flutter/material.dart';
import 'package:sarfix/utils/app_locale.dart';
import 'package:sarfix/utils/app_style.dart';
import 'package:sarfix/utils/custColors.dart';
import 'package:sarfix/widget/Scaffold_widget.dart';
import 'package:sarfix/widget/asset_img/asset_image_show.dart';

import '../../widget/appbar_common.dart';
import '../../widget/button/cus_navigateBtn.dart';

class wallet_screen extends StatefulWidget {
  const wallet_screen({super.key});

  @override
  State<wallet_screen> createState() => _wallet_screenState();
}

class _wallet_screenState extends State<wallet_screen> {


  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(title_text: 'My Wallet',leading_ontap: () {
          Navigator.pop(context);
        }),
        body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
              image: DecorationImage(image: AssetImage(AppImages.poster_img),fit: BoxFit.fill),
            ),
            padding: const EdgeInsets.symmetric(vertical: 15,horizontal: 10),
            child: Column(
              children: [
                ListTile(
                  leading: Asset_imge_show().SvgPicture_asset(AppImages.wallet_img),
                  title: Text('547387654092987',style: App_style().textS24SemiboldPtcwhiteColor),
                  subtitle: Text('Available Balance',style: App_style().textS14RegularwhiteColor),
                ),
                cus_size_box().sizedBox_10,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    children: [
                      Expanded(
                          child: cus_navigateBtn(
                            backgroundColor: AppColors.primarybutton,
                            onPressed: () {
                            },
                            text: '+ Add Money',
                          )),
                    ],
                  ),
                ),
                cus_size_box().sizedBox_10,
              ],
            ),
          ),

          cus_size_box().sizedBox_10,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Transaction Details',style: App_style().textS16Semibold,),
              Text('See all',style: App_style().textS14MediumPriTextColor,),
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: 10,
              shrinkWrap: true,
              itemBuilder: (context, index) =>Column(
              children: [
                ListTile(
                  leading: Asset_imge_show().SvgPicture_asset(AppImages.tran_icon),
                  title: Text('547387654092987',style: App_style().textS14MediumPriTextColor),
                  subtitle: Row(
                    children: [
                      Text('23 April, 2024',style: App_style().textS12RegularOpacity),
                      const SizedBox(width: 5,),
                      Container(
                        width: 5,
                        height: 5,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.primaryTextColor.withOpacity(0.2)
                        ),
                      ),
                      const SizedBox(width: 5,),
                      Text('12:20 AM',style: App_style().textS12RegularOpacity),
                    ],
                  ),
                  trailing: Text('N 20.00',style: App_style().textS16SemiboldBlue),
                ),
                const Divider(thickness: 0.4,)
              ],
            ),),
          )

        ],
      ),
    ));
  }
}
