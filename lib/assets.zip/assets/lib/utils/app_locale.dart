
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'app_style.dart';
import 'custColors.dart';

class AppImages {
  //Svg image
  static const String back_arrow = 'assets/svg/back_arrow.svg';
  static const String eye_icon = 'assets/svg/eye.svg';
  static const String menu_icon = 'assets/svg/menu_icon.svg';
  static const String notification_icon = 'assets/svg/notification_icon.svg';
  static const String edit_icon = 'assets/svg/edit_icon.svg';
  static const String camare_icon = 'assets/svg/camare_icon.svg';
  static const String darkmode_icon = 'assets/svg/darkmode_icon.svg';
  static const String lang_icon = 'assets/svg/lang_icon.svg';
  static const String logout_icon = 'assets/svg/logout_icon.svg';
  static const String notifi_icon = 'assets/svg/notifi_icon.svg';
  static const String payment_icon = 'assets/svg/payment_icon.svg';
  static const String policy_icon = 'assets/svg/policy_icon.svg';
  static const String profile_icon = 'assets/svg/profile_icon.svg';
  static const String refer_icon = 'assets/svg/refer_icon.svg';
  static const String wallet_icon = 'assets/svg/wallet.svg';
  static const String referGift_icon = 'assets/svg/referGift_icon.svg';
  static const String copy_icon = 'assets/svg/copy_icon.svg';
  static const String tran_icon = 'assets/svg/tran_icon.svg';
  static const String wallet_img = 'assets/svg/wallet_img.svg';
  static const String register_success_img = 'assets/svg/register_success.svg';

  //Png image
  static const String app_logo = 'assets/png/appLogo.png';
  static const String appmainLogo = 'assets/png/appmainLogo.png';
  static const String dummyimg = 'assets/png/dummyimg.png';
  static const String poster_img = 'assets/png/poster_img.png';
  static const String splash_img = 'assets/png/splash_img.png';
  static const String shadow_img = 'assets/png/shadow_img.png';
  static const String backSplashScreen = 'assets/png/backSplashScreen.png';
  static const String chat_img = 'assets/png/chat_img.png';
  static const String home_img = 'assets/png/home_img.png';
  static const String order_img = 'assets/png/order_img.png';
  static const String profile_img = 'assets/png/profile_img.png';


}

class Common_text{
  static const String login='Login';
  static const String createAC='Create an account';
  static const String welcomeText='Welcome back! Please enter your details.';
  static const String welcomeText2='Welcome! Please enter your details.';
  static const String email='Email';
  static const String password='Password';
  static const String forgetPassword='Forgot password?';
  static const String fullName='Full Name';

}

class font_name {
  static const String SFProDisplay_Bold = 'SFProDisplay_Bold';
  static const String SFProDisplay_Medium = 'SFProDisplay_Medium';
  static const String SFProDisplay_Regular = 'SFProDisplay_Regular';
  static const String SFProDisplay_Semibold = 'SFProDisplay_Semibold';
}




class Tost_meassage{
  static const String connectInternet='Please connect internet!';
  static const String server_error='Server error';
  static const String pageNotFound='Page not found';
  static const String tryAgain='Please try again';
  static const String plsPhoneNumber='Please enter phone number';
  static const String plsValidNumber='Please enter valid number';
  static const String pls6digitOtp='Please enter 6 digit otp';
  static const String plsenter_OTP='Please enter OTP';
  static const String plsenter='Please enter';
  static const String plsselect='Please select';

}

class cus_size_box{
  SizedBox sizedBox_3= const SizedBox(height: 3);
  SizedBox sizedBox_5= const SizedBox(height: 5);
  SizedBox sizedBox_8= const SizedBox(height: 8);
  SizedBox sizedBox_10= const SizedBox(height: 10);
  SizedBox sizedBox_15= const SizedBox(height: 15);
  SizedBox sizedBox_20= const SizedBox(height: 20);
  SizedBox sizedBox_25= const SizedBox(height: 25);
  SizedBox sizedBox_30= const SizedBox(height: 30);
  SizedBox sizedBox_40= const SizedBox(height: 40);
  SizedBox sizedBox_50= const SizedBox(height: 50);
}

class CommonText_Title {
  static Widget textField_title({
    required String text,
  }) => Text(text,style: App_style().textS16MediumPtc);
}


