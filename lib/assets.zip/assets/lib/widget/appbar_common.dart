

import 'package:flutter/material.dart';

import '../utils/app_locale.dart';
import '../utils/app_style.dart';
import 'asset_img/asset_image_show.dart';


PreferredSizeWidget appbarCommon({String? title_text, Function? leading_ontap}) {
  return AppBar(
      title:title_text!=null?Text(title_text):null,
      titleSpacing: 0,
      centerTitle: true,
      titleTextStyle: App_style().textS16SemiboldPtc,
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      leadingWidth: leading_ontap!=null?65:20,
      automaticallyImplyLeading: false,
      leading: leading_ontap!=null?Padding(
        padding: const EdgeInsets.only(left: 20,top: 8),
        child: GestureDetector(
            onTap: (){
              leading_ontap();
            },
            child: Asset_imge_show().SvgPicture_asset(AppImages.back_arrow,width: 25)),
      ):const SizedBox(),
      iconTheme:  const IconThemeData(color: Colors.black),
      elevation: 0,
  );
}

PreferredSizeWidget MainAppBar({required String title,Function? leading_ontap,Function? noti_fun}) {
  return AppBar(
      titleSpacing: 0,
      title: Text(title),
      centerTitle: true,
      titleTextStyle: App_style().textS16SemiboldPtc,
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      leadingWidth: leading_ontap!=null?65:20,
      automaticallyImplyLeading: false,
      leading: leading_ontap!=null?Padding(
        padding: const EdgeInsets.only(left: 20,top: 8),
        child: Asset_imge_show().SvgPicture_asset(AppImages.menu_icon),
      ):null,
      iconTheme:  const IconThemeData(color: Colors.black),
      actions: [
        noti_fun!=null?Asset_imge_show().SvgPicture_asset(AppImages.notification_icon):const SizedBox(),
        const SizedBox(width: 12,),
      ],
      elevation: 5
  );
}
