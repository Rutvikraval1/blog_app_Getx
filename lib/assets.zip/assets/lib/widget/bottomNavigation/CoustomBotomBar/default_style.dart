import 'package:flutter/material.dart';

class DefaultCustomNavigationBarStyle {
  static final defaultHeight = kBottomNavigationBarHeight;
  static final defaultColor = Colors.blueAccent;
  static final defaultUnselectedColor = Colors.grey[600];
}
