

import 'package:flutter/material.dart';

import '../../utils/app_style.dart';
import '../../utils/custColors.dart';

class cus_navigateBtn extends StatefulWidget {
  final Function onPressed;
  final String text;
  final String? border;
  final Color? backgroundColor;
  const cus_navigateBtn({super.key,required this.onPressed, this.border,required this.text,this.backgroundColor});

  @override
  State<cus_navigateBtn> createState() => _cus_navigateBtnState();
}

class _cus_navigateBtnState extends State<cus_navigateBtn> {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ButtonStyle(
        alignment: Alignment.center,
          side: widget.border!=null?MaterialStateProperty.all(const BorderSide(
              color: AppColors.whiteColor,
              width: 0.8,
              style: BorderStyle.solid)):null,
        padding: MaterialStateProperty.all(const EdgeInsets.all(10)),
        backgroundColor: MaterialStateProperty.all(widget.backgroundColor??AppColors.primaryColorBlue),
        shape: MaterialStateProperty.all(
          const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10))),
        ),
      ),
      child: Text(
        widget.text,
        style:  App_style().textS16MediumWhite,
      ),
      onPressed: () {
        widget.onPressed();
      },
    );
  }
}
