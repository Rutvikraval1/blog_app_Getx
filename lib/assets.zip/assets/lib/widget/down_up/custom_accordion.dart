
import 'package:flutter/material.dart';
import 'package:sarfix/utils/app_style.dart';
import 'package:sarfix/utils/custColors.dart';

class CustomAccordion extends StatefulWidget {
  final String title;
  final String? trailing_icon;
  final Widget content;

  const CustomAccordion({Key? key, required this.title,this.trailing_icon, required this.content})
      : super(key: key);

  @override
  State<CustomAccordion> createState() => _CustomAccordionState();
}

class _CustomAccordionState extends State<CustomAccordion> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.whiteColor,
        border: Border.all(color: AppColors.primaryTextColor.withOpacity(0.2))
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            tileColor: Colors.transparent,
            visualDensity: VisualDensity(horizontal: 0, vertical: -4),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
            title: Text(
              widget.title,
              style:App_style().textS14MediumPriTextColor,
            ),
            trailing: widget.trailing_icon==null?Icon(
              _isExpanded ? Icons.expand_less : Icons.expand_more,
              color:AppColors.primaryTextColor.withOpacity(0.6)
            ):null,
            onTap: () {
              setState(() {
                _isExpanded = !_isExpanded;
              });
            },
          ),
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeIn,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            // height: _isExpanded ? 100 : 0,
            child: _isExpanded?widget.content:const SizedBox(),
          ),
        ],
      ),
    );
  }
}
