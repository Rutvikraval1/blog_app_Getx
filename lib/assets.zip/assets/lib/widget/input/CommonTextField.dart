
import 'package:flutter/material.dart';
import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../utils/custColors.dart';
import '../asset_img/asset_image_show.dart';
class CustomInput extends StatefulWidget {
  final String? hintText;
  final bool? suffixIcon;
  final TextEditingController controller;

  const CustomInput(
      {Key? key,
        required this.controller,this.hintText,this.suffixIcon=false})
      : super(key: key);

  @override
  State<CustomInput> createState() => _CustomInputState();
}

class _CustomInputState extends State<CustomInput> {
  bool _passwordVisible = false;
  DateTime? pickedDate;
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      maxLines:  widget.suffixIcon==null?null:1,
      // style: App_style().text_16_700_black,
      obscureText: widget.suffixIcon==null?false:!_passwordVisible,
      decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:  BorderSide(
                width: 0.8,
                color: AppColors.primaryTextColor.withOpacity(0.1)
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:  BorderSide(
                width: 0.8,
                color: AppColors.primaryTextColor.withOpacity(0.1)
              // style: BorderStyle.,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:  BorderSide(
                width: 0.8,
                color: AppColors.primaryTextColor.withOpacity(0.1)
            ),
          ),
          disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:  BorderSide(
                width: 0.8,
                color: AppColors.primaryTextColor.withOpacity(0.1)
            ),
          ),
          fillColor: AppColors.whiteColor,
          hintText: widget.hintText,
          hintStyle: App_style().textS16withOpacity,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20),
          suffixIcon: widget.suffixIcon!?Padding(
            padding: const EdgeInsets.only(right: 10),
            child: GestureDetector(
                onTap: (){
                  _passwordVisible = !_passwordVisible;
                  setState(() {});
                  },
                child: Asset_imge_show().SvgPicture_asset(AppImages.eye_icon,)),
          ):null,
          suffixIconConstraints: const BoxConstraints(minHeight: 25)
      ),
    );
  }

  bool validateEmail(String value) {
    RegExp regex = RegExp(r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$');
    return (!regex.hasMatch(value)) ? false : true;
  }

}







