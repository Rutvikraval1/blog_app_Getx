import 'dart:io';

import 'package:flutter/material.dart';
import 'package:sarfix/utils/app_locale.dart';
import 'package:sarfix/utils/app_style.dart';
import 'package:sarfix/utils/custColors.dart';
import 'package:sarfix/widget/asset_img/asset_image_show.dart';
import '../widget/Scaffold_widget.dart';
import '../widget/appbar_common.dart';
import '../widget/bottomNavigation/CoustomBotomBar/coustom_navigation_bar.dart';
import '../widget/bottomNavigation/CoustomBotomBar/custom_navigation_bar_item.dart';
import 'Profile/prifile_screen.dart';

class Main_home_screen extends StatefulWidget {
  const Main_home_screen({super.key});

  @override
  State<Main_home_screen> createState() => _Main_home_screenState();
}

class _Main_home_screenState extends State<Main_home_screen> {
  int _currentIndex = 0;
  final List<Widget> _screens = [
    const Center(child: Text('home')),
    const Center(child: Text('My order')),
     Container(),
    const Center(child: Text('chat')),
    const Profile_screen(),
  ];

  final List<String> _screensName = [
    'Home',
    'My order',
    '',
    'Chat',
    'My Profile',
  ];
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        if (_currentIndex == 0) {
          return exit(0);
        } else {
          change_route(_currentIndex);
          return Future.value(false);
        }
      },
      child: Scaffold_widget(
          appBar: MainAppBar(
              title: _screensName[_currentIndex],
              leading_ontap: () {},
              noti_fun: () {}),
          body: _screens[_currentIndex],
          floatingActionButton: FloatingActionButton(
            backgroundColor: Colors.transparent,
            elevation: 0,
            onPressed: () {},
            child: Container(
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.primarybutton,
              ),
              constraints: const BoxConstraints.expand(),
              child: const Icon(
                Icons.add,
                color: Colors.white,
              ),
            ),
          ),
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerDocked,
          bottomNavigationBar: _buildBottomBar(context)),
    );
  }

  void change_route(int value) {
    _currentIndex = 0;
    setState(() {});
  }

  Widget _buildBottomBar(BuildContext context) {
    return CustomNavigationBar(
      // bubbleCurve: Curves.bounceInOut,
      selectedColor: AppColors.whiteColor_45,
      borderRadius:const BorderRadius.only(topLeft: Radius.circular(10),topRight: Radius.circular(10)),
      elevation: 0,
      backgroundColor: AppColors.whiteColor,
      onTap: (value) {
        setState(() {
          _currentIndex = value;
        });
      },
      unSelectedColor: AppColors.primaryColorBlue.withOpacity(0.6),
      currentIndex: _currentIndex,
      items: [
        CustomNavigationBarItem(
          title: Text("Home",style: App_style().textS14RegularOpacity,),
          icon: Asset_imge_show().Img_asset(AppImages.home_img),
          selectedIcon: Asset_imge_show().Img_asset(AppImages.home_img,color_code: AppColors.primaryColorBlue),
          selectedTitle: Text("Home",style: App_style().textS14RegularBlue,),
        ),
        CustomNavigationBarItem(
          title:  Text("My order",style: App_style().textS14RegularOpacity,),
          icon: Asset_imge_show().Img_asset(AppImages.order_img),
          selectedIcon: Asset_imge_show().Img_asset(AppImages.order_img,color_code: AppColors.primaryColorBlue),
          selectedTitle: Text("My order",style: App_style().textS14RegularBlue,),
        ),
        CustomNavigationBarItem(
          title:  Text("Add",style: App_style().textS14RegularOpacity,),
          icon: Image.asset('assets/png/home.png', height: 0),
        ),
        CustomNavigationBarItem(
          title:  Text("Chat",style: App_style().textS14RegularOpacity,),
            icon: Asset_imge_show().Img_asset(AppImages.chat_img,color_code: AppColors.primaryColorBlue.withOpacity(0.6)),
            selectedIcon: Asset_imge_show().Img_asset(AppImages.chat_img,color_code: AppColors.primaryColorBlue),
        selectedTitle: Text("Chat",style: App_style().textS14RegularBlue,),
        ),
        CustomNavigationBarItem(
          title:  Text("My Profile",style: App_style().textS14RegularOpacity,),
            icon: Asset_imge_show().Img_asset(AppImages.profile_img,color_code: AppColors.primaryColorBlue.withOpacity(0.6)),
            selectedIcon: Asset_imge_show().Img_asset(AppImages.profile_img,color_code: AppColors.primaryTextColor),
          selectedTitle: Text("My Profile",style: App_style().textS14RegularBlue,),
        ),
      ],
    );
  }
}
