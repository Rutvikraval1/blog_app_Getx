import 'package:flutter/material.dart';
import 'package:sarfix/utils/app_locale.dart';
import 'package:sarfix/utils/app_style.dart';
import 'package:sarfix/widget/Scaffold_widget.dart';
import 'package:sarfix/widget/asset_img/asset_image_show.dart';

import '../../widget/button/cus_navigateBtn.dart';
import '../auth_screen/login_screen.dart';
import '../auth_screen/signup_screen.dart';

class mainSplashScreen extends StatefulWidget {
  const mainSplashScreen({super.key});

  @override
  State<mainSplashScreen> createState() => _mainSplashScreenState();
}

class _mainSplashScreenState extends State<mainSplashScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(AppImages.splash_img), fit: BoxFit.fill)),
            child: Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(AppImages.shadow_img),
                      fit: BoxFit.fill)),
              alignment: Alignment.centerRight,
            ),
          ),
          Positioned.fill(
              child: Padding(
                padding: const EdgeInsets.only(top:30),
                child: Align(
                    alignment: Alignment.topCenter,
                    child: Asset_imge_show().Img_asset(AppImages.appmainLogo)),
              )),
          Positioned(
            bottom: 20,
              width: MediaQuery.of(context).size.width,
              child: ContainerColums(context))
        ],
      ),
    );
  }

  Widget ContainerColums(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Text(
            'Get your packages delivered safely to you',
            style: App_style().textS24boldPtcwhiteColor,
          ),
          cus_size_box().sizedBox_10,
          Text(
            'We pack and ship packages from anywhere in the world to the comfort of your home',
            style: App_style().textS14RegularwhiteColor,
          ),
          cus_size_box().sizedBox_10,
          Row(
            children: [
              Expanded(
                child: cus_navigateBtn(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const login_screen(),
                        ));
                  },
                  text: 'Log in',
                ),
              ),
            ],
          ),
          cus_size_box().sizedBox_10,
          Row(
            children: [
              Expanded(
                child: cus_navigateBtn(
                  backgroundColor: Colors.transparent,
                  border: 'true',
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const signup_screen(),
                        ));
                  },
                  text: 'Create Account',
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
