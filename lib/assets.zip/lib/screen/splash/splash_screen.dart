
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sarfix/utils/custColors.dart';
import '../../service/pref_manager.dart';
import '../../utils/app_locale.dart';
import '../../widget/Scaffold_widget.dart';
import '../../widget/asset_img/asset_image_show.dart';
import '../auth_screen/login_screen.dart';
import 'main_splash_screen.dart';

class splash_screen extends StatefulWidget {
  const splash_screen({super.key});

  @override
  State<splash_screen> createState() => _splash_screenState();
}

class _splash_screenState extends State<splash_screen> {


  @override
  void initState() {
    Preferences.init();
    startTimer();
    super.initState();
  }
  startTimer() async {
    var duration = const Duration(seconds: 5);
    return Timer(duration, route);
  }

  route() {
    Navigator.pushReplacement(context,MaterialPageRoute(builder: (context) => const mainSplashScreen(),));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
      backgroundColor: AppColors.primaryColorBlue,
      body: Center(
        child: Asset_imge_show().Img_asset(AppImages.app_logo),
      ),
    );
  }
}
