
import 'package:flutter/material.dart';

import 'app_locale.dart';
import 'custColors.dart';

class App_style{
  TextStyle textS16SemiboldPtc= const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 16,
      fontFamily: font_name.SFProDisplay_Semibold
  );
  TextStyle textS16MediumPtc = const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 16,
      fontFamily: font_name.SFProDisplay_Medium
  );
  TextStyle textS16BoldPtc = const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 16,
      fontFamily: font_name.SFProDisplay_Bold
  );
  TextStyle textS24SemiboldPtc = const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 24,
      fontFamily: font_name.SFProDisplay_Semibold
  );
  TextStyle textS24SemiboldPtcwhiteColor = const TextStyle(
      color: AppColors.whiteColor,
      fontSize: 24,
      fontFamily: font_name.SFProDisplay_Semibold
  );
  TextStyle textS24boldPtcwhiteColor = const TextStyle(
      color: AppColors.whiteColor,
      fontSize: 24,
      fontFamily: font_name.SFProDisplay_Bold
  );
  TextStyle textS14SemiboldPtc =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.6),
      fontSize: 14,
      fontFamily: font_name.SFProDisplay_Semibold
  );
  TextStyle textS16SemiboldwithOpacity =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.6),
      fontSize: 16,
      fontFamily: font_name.SFProDisplay_Semibold
  );
  TextStyle textS16withOpacity =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.4),
      fontSize: 16,
      fontFamily: font_name.SFProDisplay_Regular
  );

  TextStyle textS16Medium_blue =  const TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 16,
      fontFamily: font_name.SFProDisplay_Medium,
    decoration: TextDecoration.underline,
  );

  TextStyle textS16MediumWhite =  TextStyle(
      color: AppColors.whiteColor,
      fontSize: 16,
      fontFamily: font_name.SFProDisplay_Medium
  );

  TextStyle textS14MediumPriTextColor =  TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 14,
      fontFamily: font_name.SFProDisplay_Medium
  );
  TextStyle textS14RegularwhiteColor =  TextStyle(
      color: AppColors.whiteColor.withOpacity(0.6),
      fontSize: 14,
      fontFamily: font_name.SFProDisplay_Regular
  );
  TextStyle textS16Semibold =  TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 16,
      fontFamily: font_name.SFProDisplay_Semibold
  );
  TextStyle textS16SemiboldBlue =  TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 16,
      fontFamily: font_name.SFProDisplay_Semibold
  );


  TextStyle textS20SemiboldPtc = const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 20,
      fontFamily: font_name.SFProDisplay_Semibold
  );
  TextStyle textS12RegularOpacity =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.6),
      fontSize: 12,
      fontFamily: font_name.SFProDisplay_Regular
  );

  TextStyle textS14RegularOpacity =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.6),
      fontSize: 14,
      fontFamily: font_name.SFProDisplay_Regular
  );
  TextStyle textS14RegularBlue =  TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 14,
      fontFamily: font_name.SFProDisplay_Regular
  );
}