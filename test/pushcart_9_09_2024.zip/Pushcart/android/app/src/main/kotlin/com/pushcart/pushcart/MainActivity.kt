package com.pushcart.pushcart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
