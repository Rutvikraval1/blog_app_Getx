
import 'package:get/get.dart';
import '../controller/Cart_controller.dart';
import '../controller/ChangePasswordController.dart';
import '../controller/GRN_controller.dart';
import '../controller/Home_controller.dart';
import '../controller/MyGrnController.dart';
import '../controller/MyGrnOrderDetails.dart';
import '../controller/MyPurchaseorder_controller.dart';
import '../controller/MySalesOrderController.dart';
import '../controller/MySalesOrderDetails_controller.dart';
import '../controller/MypurchaseOrderDetails.dart';
import '../controller/Notification_controller.dart';
import '../controller/PertiGrnlist_controller.dart';
import '../controller/Profile_controller.dart';
import '../controller/PurchaseOrder_controller.dart';
import '../controller/SalesCart_controller.dart';
import '../controller/SalesCustomer_controller.dart';
import '../controller/SalesOrder_controller.dart';
import '../controller/attendance_controller.dart';
import '../controller/forgotPassword_controller.dart';
import '../controller/login_controller.dart';

class DataBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => LoginController());
    Get.lazyPut(() => ForgotPasswordController());
    Get.lazyPut(() => ChangePasswordController());
    Get.lazyPut(() => ProfileController());
    Get.lazyPut(() => HomeController());
    Get.lazyPut(() => PurchaseorderController());
    Get.lazyPut(() => CartController());
    Get.lazyPut(() => GRNController());
    Get.lazyPut(() => SalesCustomerController());
    Get.lazyPut(() => SalesOrderController());
    Get.lazyPut(() => AttendanceController());
    Get.lazyPut(() => PertigrnlistController());
    Get.lazyPut(() => SalesCartController());
    Get.lazyPut(() => MyPurchaseorderController());
    Get.lazyPut(() => NotificationController());
    Get.lazyPut(() => Mysalesordercontroller());
    Get.lazyPut(() => MyGRNordercontroller());
    Get.lazyPut(() => MyPurchaseorderDetailsController());
    Get.lazyPut(() => MyGRNorderDetailsController());
    Get.lazyPut(() => MySalesorderDetailsController());
  }
}