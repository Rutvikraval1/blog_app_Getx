import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../localDB/DatabaseHelper.dart';
import '../screen/purchaseOrder/SuccessOrder/successOrder_screen.dart';
import '../service/Get_GPS_Location.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../widget/AlertDialog/ResponseMessageShow.dart';
import '../widget/Date_Time/Date_time.dart';
import '../widget/Flutter_toast_mes.dart';

class CartController extends GetxController with StateMixin<dynamic> {
  List lst = [];
  List<TextEditingController>? inputText = [];
  double totalamount = 0.0;
  double totalamount_round = 0.0;
  double NetAmt = 0.0;
  double total_Rate = 0.0;
  double CGST_Tax = 0;
  double SGST_Tax = 0;


  @override
  void onInit() {
    // TODO: implement onInit
    String currentTime = Date_Time().TimeCurrent();
    print("currentTime");
    print(currentTime);
    getLocation();
    Preferences.init();
    TotalCart();
    super.onInit();
  }
String  lat="";
String  long="";
String  Address="";
  Future<void> getLocation() async {
   var data= await Get_GPS_Location().determinePosition();
   if(data!=null){
     lat=data['lat'].toString();
     long=data['long'].toString();
     Address=data['address'];
     update();
   }
   print("Get_GPS_Location : data");
   print(data);
  }

  TotalCart({bool isloader=false,BuildContext? context}) async {
    inputText = [];
    lst = await DBHelper().GetTotalPurchaseCart();
    for (int i = 0; i < lst.length; i++) {
      inputText?.add(TextEditingController(text: lst[i]['Qty']));

    }
    await totalAmount();
    // bool isload=await GetTaxDetails(isloder: isloader);
    // print("isload");
    // print(isload);
    // if(isload){
    //   Get.back();
    // }
    if (lst.isNotEmpty) {
      // if(isloader){
      //   if(isload){
      //     Get.back();
      //   }
      // }
      change(lst, status: RxStatus.success());
    } else {
      // if(isloader){
      //   Get.back();
      // }
      change(lst, status: RxStatus.empty());
    }
  }

  Future<void> totalAmount() async {
    NetAmt = 00.0;
    totalamount = 00.0;
    CGST_Tax = 00.0;
    SGST_Tax = 00.0;
  final data = await DBHelper().GetTotalPurchaseCart();
  if (data!.isNotEmpty) {
    for (var i = 0; i < data.length; i++) {
      print(data[i]);
      double currentRate = double.parse(data[i]['rate']);
      int current_qty = int.parse(data[i]['Qty']);
      double total = current_qty * currentRate;
      NetAmt += total;
      // calu Tax
      double taxAmount = double.parse(data[i]['taxAmount']);
      double GstTax=current_qty*taxAmount/2;
      CGST_Tax += GstTax;
      SGST_Tax += GstTax;
      //Total amount
      double amount=total+taxAmount*current_qty;
      totalamount+=amount;
    }
  } else {
    NetAmt = 00.0;
    totalamount= 00.0;
    CGST_Tax =00.0;
    SGST_Tax =00.0;

  }
  update();
}

  String particular_Total_rate({String cur_rate = '', String totalQty = ''}) {
    double currentRate = double.parse(cur_rate);
    int current_qty = int.parse(totalQty);
    double total = current_qty * currentRate;
    return total.toStringAsFixed(2);
  }

  Future<void> updateQty({String materialNo = '', String Qty = '',context}) async {
    final data = await DBHelper()
        .Update_PurchaseOrderCart(material_No: materialNo, updateQty: Qty);
    if (data != '') {
      await totalAmount();
      // bool isload= await GetTaxDetails(isloder: true);
      // print("isload");
      // print(isload);
      // if(isload){
      //   Get.back();
      // }
      update();
      Flutter_toast_mes().Error_Message("Successfully update to cart");
    } else {
      Flutter_toast_mes().Error_Message("Please try again");
    }
  }

  Future<void> deleteCartValue({String materialNo = '',context}) async {
    final data = await DBHelper().RowDeletecart(material_No: materialNo);
    if (data != '') {
      Flutter_toast_mes().Error_Message("Successfully Deleted");
    } else {
      Flutter_toast_mes().Error_Message("Please try again");
    }
  }

  Future<void> CartSubmitData(context) async {
    String createOrderID = CreateOrderId();
    String currentDate = Date_Time().DateTimeCurrent();
    String currentTime = Date_Time().TimeCurrent();
    List sellOrderlist = [];
    final data = await DBHelper().GetTotalPurchaseCart();
    if (data!.isNotEmpty) {
      for (var i = 0; i < data.length; i++) {
        String materialNo = data[i]['materialNo'];
        double currentRate = double.parse(data[i]['rate']);
        int current_qty = int.parse(data[i]['Qty']);
        double total = current_qty * currentRate;
        var orderItem = {
          "CompanyNo": int.parse(Preferences.getStringValuesSF(Preferences.companyNo)),
          "PlantNo": int.parse(Preferences.getStringValuesSF(Preferences.supPlantNo)),
          "DivisionNo": int.parse(Preferences.getStringValuesSF(Preferences.divisionNo)),
          "vOrderNo": createOrderID,
          "OrderDate": currentDate,
          "OrderTime": currentTime,
          "ModifyOn": currentDate,
          "Usercode": Preferences.getStringValuesSF(Preferences.userCode),
          "mRate": currentRate.round(),
          "mAmount": total,
          "MaterialNo": materialNo,
          "iQty": current_qty,
          "iPendQty": current_qty,
          "CustSupNo": int.parse(Preferences.getStringValuesSF(Preferences.custSupNO)),
          //default value
          "iTransferQty": 0,
          "RID": -1,
          "OrderNo": -1,
          "iSrNo": 1,
          "BatchNo": "",
          "iPurgeQty": 0,
          "Status": "N",
          "ReplicaFlag": "N"
        };
        sellOrderlist.add(orderItem);
      }
      var mapdata = {
        "CompanyNo":
        int.parse(Preferences.getStringValuesSF(Preferences.companyNo)),
        "UserCode": Preferences.getStringValuesSF(Preferences.userCode),
        "PSRCode": Preferences.getStringValuesSF(Preferences.userCode),
        "PlantNo": int.parse(Preferences.getStringValuesSF(Preferences.supPlantNo)),
        "vOrderNo": createOrderID,
        "OrderDate": currentDate,
        "OrderTime": currentTime,
        "ModifyOn": currentDate,
        "CustSupNo":
        int.parse(Preferences.getStringValuesSF(Preferences.custSupNO)),
        //default value
        "DivisionNo":
        int.parse(Preferences.getStringValuesSF(Preferences.divisionNo)),
        "OrderNo": -1,
        "ReasonNo": 0,
        "ErrorLog": "",
        "Remarks": "",
        "DefreezeNo": "",
        "COMSRemeaks": "",
        "QRSkipReason": "",
        "ReplicaFlag": "N",
        "Status": "N",
        "Longitude": long,
        "Latitude": lat,
        "Address": Address,
        "onlineMSellOrderDtls": sellOrderlist,
        "onlineMSellOrderDefreezeDtls": []
      };
      final cartData = await Provider().addCartData(mapdata);
      print("cartData");
      print(cartData);
      if (cartData != '') {
        print("step 1");
        if (cartData['responseCode'] == Common_text.RESPONSE_OK) {
          String order_id=cartData['orderNo'].toString();
          print("step 2");
          // CusReponseMess().DialogBox(reposMess: cartData['message'].toString());
          // Flutter_toast_mes().Error_Message(cartData['message'].toString());
          final data = await DBHelper().AllRowDeletecart();
          if (data != '') {
            print('Delete data');
          } else {
            print('not Delete data');
          }
          Get.back();
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => SuccessorderScreen(
                  OrderNo: order_id,
                  TotalPaymnet: totalamount.round().toString(),
                ),
              ));
        }else{
          Get.back();
          CusReponseMess().DialogBox(reposMess: cartData['message'].toString(),errorType: true);
        }
      } else {
        print("step 2");
        print("Failed");
        Get.back();
        CusReponseMess().DialogBox(reposMess: "Failed".toString(),errorType: true);
        // Flutter_toast_mes().Error_Message('Failed', error_code: true);
        // Get.back();
      }
    }else{
      print("Failed");
      Flutter_toast_mes().Error_Message('No Data', error_code: true);
      Get.back();
    }

  }

  String CreateOrderId(){
   var dt = DateFormat('yyyyMMddHHmmssSSS').format(DateTime.now());
   String plantNo=Preferences.getStringValuesSF(Preferences.plantNo);
   String custSupNO=Preferences.getStringValuesSF(Preferences.custSupNO);

   String finalCreateId=plantNo+custSupNO+dt.toString();

   return finalCreateId;
  }

  // Future<dynamic> GetTaxDetails({bool isloder=false}) async {
  //   total_Rate = 00.0;
  //   totalamount = 00.0;
  //   CGST_Tax = 00.0;
  //   SGST_Tax = 00.0;
  //   if(isloder){
  //     LoaderAlert().ShowLoader();
  //   }
  //   List salesSchemeDtls = [];
  //   final data = await DBHelper().GetTotalPurchaseCart();
  //   if (data!.isNotEmpty) {
  //     for (var i = 0; i < data.length; i++) {
  //       double currentRate = double.parse(data[i]['rate']);
  //       int materialNo = int.parse(data[i]['materialNo']);
  //       int iQty = int.parse(data[i]['Qty']);
  //       double total = iQty * currentRate;
  //       total_Rate += currentRate;
  //       var mapData = {
  //         "CompanyNo": int.parse(Preferences.getStringValuesSF(Preferences.companyNo)),
  //         "PlantNo": int.parse(Preferences.getStringValuesSF(Preferences.supPlantNo)),
  //         "DivisionNo": int.parse(Preferences.getStringValuesSF(Preferences.divisionNo)),
  //         "CustSupNo": int.parse(Preferences.getStringValuesSF(Preferences.custSupNO)),
  //         "MaterialNo": materialNo,
  //         "iQty":iQty,
  //         "Rate": currentRate,
  //         "GrossAmount": total
  //       };
  //       salesSchemeDtls.add(mapData);
  //     }
  //     var finalmapdata = {
  //       "Plantno": int.parse(
  //           Preferences.getStringValuesSF(Preferences.supPlantNo)), //supPlantNo
  //       "DivisionNo":
  //           int.parse(Preferences.getStringValuesSF(Preferences.divisionNo)),
  //       "CustSupNo":
  //           int.parse(Preferences.getStringValuesSF(Preferences.custSupNO)),
  //       "TotalNetAmt": total_Rate, // rate
  //       "discperc": 0, //0
  //       "salesSchemeDtls":salesSchemeDtls
  //     };
  //     try{
  //       final getTaxData = await Provider().GetTaxDetails(finalmapdata);
  //       if (getTaxData != '') {
  //         if (getTaxData['responseCode'] == Common_text.RESPONSE_OK) {
  //           List taxDetails = getTaxData['taxDetails']['applicableTaxDetails'];
  //           if (taxDetails.isNotEmpty) {
  //             taxDetails.forEach((element) {
  //               if (element['vTaxTypeCode'] == 'CGST') {
  //                 CGST_Tax = element['taxAmt'];
  //                 totalamount = element['totalTaxableAmt'];
  //                 totalamount_round=totalamount-totalamount.round();
  //               } else if (element['vTaxTypeCode'] == 'SGST') {
  //                 SGST_Tax = element['taxAmt'];
  //               }
  //             });
  //           }
  //           update();
  //           // if(isloder){
  //           //   Get.back();
  //           // }
  //           return true;
  //         }else{
  //           // if(isloder){
  //           //   Get.back();
  //           // }
  //
  //           return false;
  //         }
  //       }else{
  //         // if(isloder){
  //         //   Get.back();
  //         // }
  //         return false;
  //       }
  //     }catch(e){
  //       print("sdsdssd");
  //       print(e);
  //       return false;
  //     }
  //
  //   }
  //   else{
  //     return true;
  //   }
  // }



// Future<void> totalAmount() async {
//   totalamount = 00.0;
//   total_Rate = 00.0;
//   final data = await DBHelper().GetTotalPurchaseCart();
//   if (data!.isNotEmpty) {
//     for (var i = 0; i < data.length; i++) {
//       double currentRate = double.parse(data[i]['rate']);
//       total_Rate += currentRate;
//       int current_qty = int.parse(data[i]['Qty']);
//       int total = current_qty * currentRate.round();
//       totalamount += total;
//     }
//   } else {
//     totalamount = 00.0;
//   }
//   update();
// }
}
