


import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../pages/page_route_name.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../widget/AlertDialog/ResponseMessageShow.dart';
import '../widget/Flutter_toast_mes.dart';


class ChangePasswordController extends GetxController
    with StateMixin<dynamic> {
  TextEditingController Oldpassword=TextEditingController();
  TextEditingController NewPassword=TextEditingController();
  TextEditingController NewConfirmPassword=TextEditingController();

  @override
  void onInit() {
    Oldpassword.clear();
    NewPassword.clear();
    NewConfirmPassword.clear();
    // TODO: implement onInit
    super.onInit();
  }



  Future<void> ChangePassword() async {
    var mapdata = {
      "username": Preferences.getStringValuesSF(Preferences.userName),
      "password":Oldpassword.text,
      "NewPassword":NewConfirmPassword.text
    };
    final getData = await Provider().changePassword(mapdata);
    if (getData != '') {
      if (getData['responseCode'] == Common_text.RESPONSE_OK) {

        Flutter_toast_mes().Error_Message(getData['message'].toString());
        Oldpassword.clear();
        NewPassword.clear();
        NewConfirmPassword.clear();
        Preferences.clearAllValuesSF();
        Get.back();
        // CusReponseMess().DialogBox(reposMess: getData['message'].toString());
        Get.toNamed(route_loginScreen);
      }else{
        Flutter_toast_mes().Error_Message(getData['message'].toString());
        Get.back();
        // CusReponseMess().DialogBox(reposMess: getData['message'].toString(),errorType: true);
      }
    } else {
      print("Failed");
      Get.back();
      CusReponseMess().DialogBox(reposMess: "Failed",errorType: true);
      // Flutter_toast_mes().Error_Message('Failed', error_code: true);

    }
  }

}