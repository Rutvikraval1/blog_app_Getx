

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../model/GrnModel.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';


List<GoodsReceiptNote> GrnList = [];

class GRNController extends GetxController with StateMixin<dynamic> {
  TextEditingController SearchFilterText = TextEditingController();
  List? ref_documentNo = [];
  List? re_lrNo = [];


  List<GrnDocumentNoModel>? GrnDocumentNo= [];
  List<GrnDocumentNoModel>?  dummy_documentNo = [];

  @override
  void onInit() {
    // TODO: implement onInit
    getGRNList();
    super.onInit();
  }

  void SearchFilter(String value) {
    GrnDocumentNo=[];
    if (value.isEmpty) {
      GrnDocumentNo = dummy_documentNo;
    } else {
      GrnDocumentNo = dummy_documentNo?.where((data) {
        return data.documentNo
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    update();
  }


  Future<void> getGRNList() async {
    re_lrNo=[];
    GrnDocumentNo=[];
    print("re_lrNo");
    print(re_lrNo);
    print(GrnDocumentNo);
    var mapdata = {
      "PlantCustomerNo": Preferences.getStringValuesSF(Preferences.custSupNO),
    };
    GrnModel getGRNlist = await Provider().getGRNList(mapdata);
    if (getGRNlist.responseCode == Common_text.RESPONSE_OK) {
      GrnList = getGRNlist.goodsReceiptNote ?? [];
      if (GrnList.isNotEmpty) {
        for (int i = 0; i < GrnList.length; i++) {
          if (!re_lrNo!.contains(GrnList[i].lrNo)) {
            var mapData={
              'documentNo':GrnList[i].documentNo,
              'lrNo':GrnList[i].lrNo,
              'comsRefNo':GrnList[i].comsRefNo,
            };
            re_lrNo?.add(GrnList[i].lrNo);
            GrnDocumentNo?.add(GrnDocumentNoModel.fromJson(mapData));
          }
          dummy_documentNo=GrnDocumentNo;
        }
        change(GrnList, status: RxStatus.success());
      }
      else {
        change(GrnList, status: RxStatus.empty());
      }
    } else {
      print("Failed");
      if(getGRNlist.goodsReceiptNote!.isEmpty){
        change(GrnList, status: RxStatus.empty());
      }else{
        change(GrnList, status: RxStatus.error(getGRNlist.message.toString()));
      }
    }
  }



}

class GrnDocumentNoModel {
  String? documentNo;
  String? lrNo;
  String? comsRefNo;

  GrnDocumentNoModel({
    this.documentNo,
    this.lrNo,
    this.comsRefNo,
  });

  factory GrnDocumentNoModel.fromJson(Map<String, dynamic> json) =>
      GrnDocumentNoModel(
        documentNo: json["documentNo"],
        lrNo: json["lrNo"],
        comsRefNo: json["comsRefNo"],

      );

  Map<String, dynamic> toJson() =>
      {
        "documentNo": documentNo,
        "lrNo": lrNo,
        "comsRefNo": comsRefNo,
      };
}