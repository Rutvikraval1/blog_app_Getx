


import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pushcart/service/Get_GPS_Location.dart';

import '../model/MyPurchaseOrdersModel.dart';
import '../service/Network.dart';
import '../service/app_permission.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../service/versionCode.dart';
import '../utils/app_locale.dart';
import '../utils/app_style.dart';
import '../widget/AlertDialog/AppUpdateDialogBox.dart';
import '../widget/Date_Time/Date_time.dart';
import '../widget/loader/alertBoxLoader.dart';

class HomeController extends GetxController
    with StateMixin<dynamic> {
  List<MyPurchaseOrder>? mypurchseList = [];
  int Itemcount=0;
  String buildNumber="";
  @override
  void onInit() {
    // TODO: implement onInit

    getMypurchaseList();
    getLocation();
    super.onInit();
  }

  Future<void> getLocation() async {
    // versionCode
    buildNumber=await VersionCode().versionCodeName();
    AppPermission().requestInstallAPK();
    print("version");
    print(buildNumber);


    update();
    // var data= await Get_GPS_Location().determinePosition();
    // if(data!=null){
    //   var locationAddress=data['Address']??'';
    //   print("locationAddress");
    //   print(locationAddress);
    // }
  }






  Future<void> getMypurchaseList() async {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      LoaderAlert().ShowLoader();
    });
    DateTime formDate=DateTime.now().add(const Duration(days:-28));
    var mapdata = {
      "CustSUpNo":Preferences.getStringValuesSF(Preferences.custSupNO),
      "DivisionNo":Preferences.getStringValuesSF(Preferences.divisionNo),
      "FromDate": Date_Time().ShowDateDDMMMY(dateTime: formDate),
      "ToDate":Date_Time().ShowDateDDMMMY(),
    };
    try{
      MyPurchaseOrdersModel getMyPurchaselist =  await Provider().getMyPurchaseOrderList(mapdata);
      if (getMyPurchaselist.responseCode == Common_text.RESPONSE_OK) {
        print("responseCode");
        mypurchseList = getMyPurchaselist.myPurchaseOrders ?? [];
        if(mypurchseList!.isNotEmpty){
          if(mypurchseList?.length == 1){
            Itemcount = 1;
          } else if(mypurchseList?.length == 2){
            Itemcount = 2;
          } else if(mypurchseList?.length == 3){
            Itemcount = 3;
          }else{
            Itemcount=mypurchseList!.take(3).length;
          }
        }
        print("Itemcount");
        print(Itemcount);
        update();
        Get.back();

      } else {
        Itemcount=0;
        update();
        Get.back();
        // Flutter_toast_mes().Error_Message(getMyPurchaselist.message.toString(),error_code: true);
        // change(mypurchseList,
        //     status: RxStatus.error(getMyPurchaselist.message.toString()));
      }
    }catch(e){
      print(e);
      Get.back();
    }
    GetAppVersionMst();

  }
  Future<void> GetAppVersionMst() async {
    var mapdata={
      "CompanyNo":Preferences.getStringValuesSF(Preferences.companyNo),
      "DeviceType":Platform.isIOS?"I":"A",
      "AppName":Common_text.PushCart
    };
    try{
      var data= await Provider().GetAppVersionMst(mapdata);
      print("data");
      print(data);
      if(data!=null){
        if (data['responseCode'] == Common_text.RESPONSE_OK) {
          List appVersionDetail=data['appVersionDetail'];
          String appVersion=appVersionDetail.first['appVersion'];
          double codeVersion=double.parse(appVersionDetail.first['codeVersion']);
          if(buildNumber!=""){
            double appBuildCode=double.parse(buildNumber);
            print("appVersion");
            print(appBuildCode);
            print(codeVersion);
            if (codeVersion > appBuildCode) {
              UpdateApp().DialogBox(updateLink: "${Network.base_url}/${Common_text.APK}/${Common_text.PushCartAPK}");
            }
          }

        }
      }
    }catch(e){
      print("update app api error");
      print(e);
    }

  }


  TextStyle StatusChange(statusCode){
    switch(statusCode){
      case 'H':
        return App_style().textS14SemiboldGreen;
      case 'N':
        return App_style().textS14SemiboldlOrgeng;
      case 'X':
        return App_style().textS14Semiboldred;
      default:
        return App_style().text14SemiboldPtc;
    }
  }
}