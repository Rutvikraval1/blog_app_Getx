


import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../model/MyGRNOrderModel.dart';
import '../service/Network.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../widget/Date_Time/Date_time.dart';
import '../widget/Flutter_toast_mes.dart';

class MyGRNordercontroller extends GetxController with StateMixin<dynamic> {
  List<GoodsReceiptNotes>? myGRNList = [];
  List<GoodsReceiptNotes>? OrderList = [];
  TextEditingController SearchFilterText = TextEditingController();
  TextEditingController startDate = TextEditingController();
  TextEditingController currentstartDate = TextEditingController();
  TextEditingController toDate = TextEditingController();


  @override
  void onInit() {
    // TODO: implement onInit
    DateTime formDate=DateTime.now().add(const Duration(days:-3));
    startDate.text=Date_Time().ShowDateDDMMMY(dateTime: formDate);
        toDate.text=Date_Time().ShowDateDDMMMY();
    getMyGRNList(
        FromDate: Date_Time().ShowDateDDMMMY(dateTime: formDate),
        ToDate: Date_Time().ShowDateDDMMMY()
    );
    super.onInit();
  }

  DateTime addDateTime(String Date){
    var inputFormat = DateFormat("dd-MMM-y");
    var inputDate = inputFormat.parse(Date);
    return inputDate;
  }

  void SearchFilter(String value) {
    if (value.isEmpty) {
      myGRNList = OrderList;
    } else {
      myGRNList = OrderList?.where((data) {
        return data.documentNo
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase())|| data.orderType
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    update();
  }

String  reportformDate='';
String  reportToDate='';
  Future<void> getMyGRNList({String FromDate='',String ToDate='',bool isloader=false}) async {
    if(isloader){
      change(myGRNList, status: RxStatus.loading());
    }


    var mapdata = {
      "PlantNo":Preferences.getStringValuesSF(Preferences.plantNo),
      "DivisionNo":Preferences.getStringValuesSF(Preferences.divisionNo),
      "FromDate": FromDate,
      "ToDate":ToDate,
    };
    MyGoodsReceiptNotesModel getMyGRNlist =  await Provider().GetMyGoodsReceiptNotesList(mapdata);
    if (getMyGRNlist.responseCode == Common_text.RESPONSE_OK) {
      print("responseCode");
      OrderList = getMyGRNlist.myGoodsReceiptNotes ?? [];
      myGRNList=OrderList;
      if (myGRNList!.isNotEmpty) {
        change(myGRNList, status: RxStatus.success());
      } else {
        change(myGRNList, status: RxStatus.empty());
      }
    } else {
      if(getMyGRNlist.myGoodsReceiptNotes!.isEmpty){
        change(myGRNList, status: RxStatus.empty());
      }else{
        change(myGRNList,
            status: RxStatus.error(getMyGRNlist.message.toString()));
      }

    }
  }


  Future<void> ReportDownLoad(ReportType) async {
    var mapdata = {
      "PlantNo":Preferences.getStringValuesSF(Preferences.plantNo),
      "ReportType":ReportType,
      "FromDate": startDate.text,
      "ToDate":toDate.text,
    };
    try{
      var getReport =  await Provider().GetAllReportDownload(mapdata: mapdata,pageName: "GetGRNDumpReport");
      if (getReport['responseCode'] == Common_text.RESPONSE_OK) {
        print("responseCode");
        print(getReport);
        if (getReport["reportPath"]!="") {
          Get.back();
          _launchUrl(getReport["reportPath"]);
        }else {
          Get.back();
          Flutter_toast_mes().Error_Message("report Path is Empty",error_code: true);
        }
      } else {
        Get.back();
        Flutter_toast_mes().Error_Message(getReport["message"],error_code: true);
      }
    }catch(e){
      print(e);
      Get.back();
    }

  }
  Future<void> _launchUrl(reportPath) async {
    final Uri _url = Uri.parse('${Network.base_url}/${Common_text.Report_FilesFolder}/$reportPath');
    print("_url");
    print(_url);
    if (!await launchUrl(_url)) {
      throw Exception('Could not launch $_url');
    }
  }




}