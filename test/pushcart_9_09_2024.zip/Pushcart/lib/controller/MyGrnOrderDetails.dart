


import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../model/GrnOrderDetailsModel.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';

class MyGRNorderDetailsController extends GetxController with StateMixin<dynamic> {
  TextEditingController SearchFilterText = TextEditingController();
  List<GrnDetail>? resultList = [];
  List<GrnDetail>? OrderList = [];
  String documentId='';
  @override
  void onInit() {
    // TODO: implement onInit
    documentId=Get.arguments;
    getMyGrnDetailsList(documentId);
    super.onInit();
  }

  void SearchFilter(String value) {
    if (value.isEmpty) {
      resultList = OrderList;
    } else {
      resultList = OrderList?.where((data) {
        return data.materialCode
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase())|| data.materialName
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    update();
  }


  Future<void> getMyGrnDetailsList(orderId) async {
    var mapdata = {
      "OrderNo":orderId,
      "plantNo":Preferences.getStringValuesSF(Preferences.plantNo)
    };
    GrnOrderDetailsModel getMydetailslist =  await Provider().getMyGrnDetailsOrderList(mapdata);
    if (getMydetailslist.responseCode == Common_text.RESPONSE_OK) {
      print("responseCode");
      OrderList = getMydetailslist.grnDetails ?? [];
      resultList=OrderList;
      if (resultList!.isNotEmpty) {
        change(resultList, status: RxStatus.success());
      } else {
        change(resultList, status: RxStatus.empty());
      }
    } else {
      if(getMydetailslist.grnDetails!.isEmpty){
        change(resultList, status: RxStatus.empty());
      }else{
        change(resultList,
            status: RxStatus.error(getMydetailslist.message.toString()));
      }

    }
  }
}