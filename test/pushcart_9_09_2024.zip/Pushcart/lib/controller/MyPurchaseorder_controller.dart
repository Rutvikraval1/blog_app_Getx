
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../model/MyPurchaseOrdersModel.dart';
import '../service/Network.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../utils/app_style.dart';
import '../widget/Date_Time/Date_time.dart';
import '../widget/Flutter_toast_mes.dart';

class MyPurchaseorderController extends GetxController with StateMixin<dynamic> {
  List<MyPurchaseOrder>? mypurchseList = [];
  List<MyPurchaseOrder>? OrderList = [];
  TextEditingController SearchFilterText = TextEditingController();
  TextEditingController startDate = TextEditingController();
  TextEditingController currentstartDate = TextEditingController();
  TextEditingController toDate = TextEditingController();


  @override
  void onInit() {
    // TODO: implement onInit
    DateTime formDate=DateTime.now().add(const Duration(days:-3));
    startDate.text=Date_Time().ShowDateDDMMMY(dateTime: formDate);
    toDate.text=Date_Time().ShowDateDDMMMY();
    getMypurchaseList(
      FromDate: Date_Time().ShowDateDDMMMY(dateTime: formDate),
      ToDate: Date_Time().ShowDateDDMMMY()
    );
    super.onInit();
  }

  DateTime addDateTime(String Date){
    var inputFormat = DateFormat("dd-MMM-y");
    var inputDate = inputFormat.parse(Date);
    return inputDate;
  }

  void SearchFilter(String value) {
    if (value.isEmpty) {
      mypurchseList = OrderList;
    } else {
      mypurchseList = OrderList?.where((data) {
        return data.transactionNo
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase())|| data.orderType
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    update();
  }


  Future<void> getMypurchaseList({String FromDate='',String ToDate='',bool isloader=false}) async {
    if(isloader){
      change(mypurchseList, status: RxStatus.loading());
    }
    var mapdata = {
      "CustSUpNo":Preferences.getStringValuesSF(Preferences.custSupNO),
      "DivisionNo":Preferences.getStringValuesSF(Preferences.divisionNo),
      "FromDate": FromDate,
      "ToDate":ToDate,
    };
    MyPurchaseOrdersModel getMyPurchaselist =  await Provider().getMyPurchaseOrderList(mapdata);
    if (getMyPurchaselist.responseCode == Common_text.RESPONSE_OK) {
      print("responseCode");
      OrderList = getMyPurchaselist.myPurchaseOrders ?? [];
      mypurchseList=OrderList;
      if (mypurchseList!.isNotEmpty) {
        change(mypurchseList, status: RxStatus.success());
      } else {
        change(mypurchseList, status: RxStatus.empty());
      }
    } else {
      if(getMyPurchaselist.myPurchaseOrders!.isEmpty){
        change(mypurchseList, status: RxStatus.empty());
      }else{
        change(mypurchseList,
            status: RxStatus.error(getMyPurchaselist.message.toString()));
      }

    }
  }




  TextStyle StatusChange(statusCode){
    switch(statusCode){
      case 'H':
        return App_style().textS14SemiboldGreen;
      case 'N':
        return App_style().textS14SemiboldlOrgeng;
      case 'X':
        return App_style().textS14Semiboldred;
      default:
        return App_style().text14SemiboldPtc;
    }
   }


  Future<void> ReportDownLoad() async {
    var mapdata = {
      "PlantNo":Preferences.getStringValuesSF(Preferences.supPlantNo),
      "CustSupNo":Preferences.getStringValuesSF(Preferences.custSupNO),
      "DivisionNo":Preferences.getStringValuesSF(Preferences.divisionNo),
      "FromDate": startDate.text,
      "ToDate":toDate.text,
    };
    try{
      var getReport =  await Provider().GetAllReportDownload(mapdata: mapdata,pageName: "GetPORegisterReport");
      if (getReport['responseCode'] == Common_text.RESPONSE_OK) {
        print("responseCode");
        print(getReport);
        if (getReport["reportPath"]!="") {
          Get.back();
          _launchUrl(getReport["reportPath"]);
        }else {
          Get.back();
          Flutter_toast_mes().Error_Message("report Path is Empty",error_code: true);
        }
      } else {
        Get.back();
        Flutter_toast_mes().Error_Message(getReport["message"],error_code: true);
      }
    }catch(e){
      print(e);
      Get.back();
    }

  }
  Future<void> _launchUrl(reportPath) async {
    final Uri _url = Uri.parse('${Network.base_url}/${Common_text.Report_FilesFolder}/$reportPath');
    print("_url");
    print(_url);
    if (!await launchUrl(_url)) {
      throw Exception('Could not launch $_url');
    }
  }
}