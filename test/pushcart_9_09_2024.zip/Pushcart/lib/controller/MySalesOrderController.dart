

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../model/MySalesOrderModel.dart';
import '../service/Network.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../widget/Date_Time/Date_time.dart';
import '../widget/Flutter_toast_mes.dart';

class Mysalesordercontroller extends GetxController with StateMixin<dynamic> {
  List<MySalesOrders>? mySalesOrderList = [];
  List<MySalesOrders>? OrderList = [];
  TextEditingController SearchFilterText = TextEditingController();
  TextEditingController startDate = TextEditingController();
  TextEditingController currentstartDate = TextEditingController();
  TextEditingController toDate = TextEditingController();


  @override
  void onInit() {
    // TODO: implement onInit
    DateTime formDate=DateTime.now().add(const Duration(days:-3));
    startDate.text=Date_Time().ShowDateDDMMMY(dateTime: formDate);
    toDate.text=Date_Time().ShowDateDDMMMY();
    getMySalesList(
        FromDate: Date_Time().ShowDateDDMMMY(dateTime: formDate),
        ToDate: Date_Time().ShowDateDDMMMY()
    );
    super.onInit();
  }

  DateTime addDateTime(String Date){
    var inputFormat = DateFormat("dd-MMM-y");
    var inputDate = inputFormat.parse(Date);
    return inputDate;
  }

  void SearchFilter(String value) {
    if (value.isEmpty) {
      mySalesOrderList = OrderList;
    } else {
      mySalesOrderList = OrderList?.where((data) {
        return data.documentNo
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase())|| data.orderType
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    update();
  }


  Future<void> getMySalesList({String FromDate='',String ToDate='',bool isloader=false}) async {
    if(isloader){
      change(mySalesOrderList, status: RxStatus.loading());
    }
    var mapdata = {
      "PlantNo":Preferences.getStringValuesSF(Preferences.plantNo),
      "DivisionNo":Preferences.getStringValuesSF(Preferences.divisionNo),
      "FromDate": FromDate,
      "ToDate":ToDate,
    };
    MySalesModel getMySaleslist =  await Provider().GetMySalesOrdersList(mapdata);
    if (getMySaleslist.responseCode == Common_text.RESPONSE_OK) {
      print("responseCode");
      OrderList = getMySaleslist.mySalesOrders ?? [];
      mySalesOrderList=OrderList;
      if (mySalesOrderList!.isNotEmpty) {
        change(mySalesOrderList, status: RxStatus.success());
      } else {
        change(mySalesOrderList, status: RxStatus.empty());
      }
    } else {
      if(getMySaleslist.mySalesOrders!.isEmpty){
        change(mySalesOrderList, status: RxStatus.empty());
      }else{
        change(mySalesOrderList,
            status: RxStatus.error(getMySaleslist.message.toString()));
      }

    }
  }

  Future<void> ReportDownLoad(String ReportType) async {
    var mapdata = {
      "PlantNo":Preferences.getStringValuesSF(Preferences.plantNo),
      "DivisionNo":Preferences.getStringValuesSF(Preferences.divisionNo),
      "ReportType":ReportType,
      "FromDate": startDate.text,
      "ToDate":toDate.text,
    };
    try{
      var getReport =  await Provider().GetAllReportDownload(mapdata: mapdata,pageName: "GetPushCartSalesRegisterSummaryReport");
      if (getReport['responseCode'] == Common_text.RESPONSE_OK) {
        print("responseCode");
        print(getReport);
        if (getReport["reportPath"]!="") {
          Get.back();
          _launchUrl(getReport["reportPath"]);
        }else {
          Get.back();
          Flutter_toast_mes().Error_Message("report Path is Empty",error_code: true);
        }
      } else {
        Get.back();
        Flutter_toast_mes().Error_Message(getReport["message"],error_code: true);
      }
    }catch(e){
      print(e);
      Get.back();
    }

  }
  Future<void> _launchUrl(reportPath) async {
    final Uri _url = Uri.parse('${Network.base_url}/${Common_text.Report_FilesFolder}/$reportPath');
    print("_url");
    print(_url);
    if (!await launchUrl(_url)) {
      throw Exception('Could not launch $_url');
    }
  }




}