



import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

import '../model/SalesOrderDetailsModel.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';

class MySalesorderDetailsController extends GetxController with StateMixin<dynamic> {
  TextEditingController SearchFilterText = TextEditingController();
  List<SalesOrderDetail>? resultList = [];
  List<SalesOrderDetail>? OrderList = [];
  String documentId='';
  @override
  void onInit() {
    // TODO: implement onInit
    documentId=Get.arguments;
    getMySalesDetailsList(documentId);
    super.onInit();
  }

  void SearchFilter(String value) {
    if (value.isEmpty) {
      resultList = OrderList;
    } else {
      resultList = OrderList?.where((data) {
        return data.materialCode
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase())|| data.materialName
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    update();
  }


  Future<void> getMySalesDetailsList(orderId) async {
    var mapdata = {
      "OrderNo":orderId,
      "plantNo":Preferences.getStringValuesSF(Preferences.plantNo)
    };
    SalesOrderDetailsModel getMydetailslist =  await Provider().getMySalesDetailsOrderList(mapdata);
    if (getMydetailslist.responseCode == Common_text.RESPONSE_OK) {
      print("responseCode");
      OrderList = getMydetailslist.salesOrderDetails ?? [];
      resultList=OrderList;
      if (resultList!.isNotEmpty) {
        change(resultList, status: RxStatus.success());
      } else {
        change(resultList, status: RxStatus.empty());
      }
    } else {
      if(getMydetailslist.salesOrderDetails!.isEmpty){
        change(resultList, status: RxStatus.empty());
      }else{
        change(resultList,
            status: RxStatus.error(getMydetailslist.message.toString()));
      }

    }
  }
}