
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../model/PurchaseOrderDetailsModel.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';

class MyPurchaseorderDetailsController extends GetxController with StateMixin<dynamic> {
  TextEditingController SearchFilterText = TextEditingController();
  List<PurchaseOrderDetail>? resultList = [];
  List<PurchaseOrderDetail>? OrderList = [];
  String orderId='';
  String documentId='';
  @override
  void onInit() {
    // TODO: implement onInit
    orderId=Get.arguments[0];
    documentId=Get.arguments[1];
    getMypurchaseDetailsList(orderId);
    super.onInit();
  }

  void SearchFilter(String value) {
    if (value.isEmpty) {
      resultList = OrderList;
    } else {
      resultList = OrderList?.where((data) {
        return data.materialCode
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase())|| data.materialName
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    update();
  }


  Future<void> getMypurchaseDetailsList(orderId) async {
    var mapdata = {
      "OrderNo":orderId,
      "plantNo":Preferences.getStringValuesSF(Preferences.supPlantNo)
    };
    PurchaseOrderDetailsModel getMydetailslist =  await Provider().getMyPurchaseDetailsOrderList(mapdata);
    if (getMydetailslist.responseCode == Common_text.RESPONSE_OK) {
      print("responseCode");
      OrderList = getMydetailslist.purchaseOrderDetails ?? [];
      resultList=OrderList;
      if (resultList!.isNotEmpty) {
        change(resultList, status: RxStatus.success());
      } else {
        change(resultList, status: RxStatus.empty());
      }
    } else {
      if(getMydetailslist.purchaseOrderDetails!.isEmpty){
        change(resultList, status: RxStatus.empty());
      }else{
        change(resultList,
            status: RxStatus.error(getMydetailslist.message.toString()));
      }

    }
  }
}