

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pushcart/controller/GRN_controller.dart';

import '../model/GrnModel.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../widget/AlertDialog/ResponseMessageShow.dart';
import '../widget/Date_Time/Date_time.dart';

class PertigrnlistController extends GetxController with StateMixin<dynamic> {
  TextEditingController SearchFilterText = TextEditingController();
  TextEditingController TextController = TextEditingController();
  int total_qty=0;
  double total_dis=0;
  double total_netAmt=0;
  double total_Amt=0;
  double round_off=0;
  double total_tax=0;
  // List<TextEditingController> inputRemarks = [];
  List<GoodsReceiptNote>? parti_GrnList = [];
  List<GoodsReceiptNote>? dummyGrnList = [];
  String titleName='';
  @override
  void onInit() {
    // TODO: implement onInit
    titleName=Get.arguments[1];
    getGRNList(Get.arguments[0]);
    super.onInit();
  }

  void SearchFilter(String value) {
    // inputRemarks = [];
    if (value.isEmpty) {
      parti_GrnList = dummyGrnList;
    } else {
      parti_GrnList = dummyGrnList?.where((data) {
        return data.materialName
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase())||data.materialCode
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    // for (int i = 0; i < parti_GrnList.length; i++) {
    //   inputRemarks.add(TextEditingController());
    // }
    update();
  }

  void remarkSubmit(index, value){
    parti_GrnList?[index].remark=value;
    update();

  }

  Future<void> getGRNList(String grnno) async {
    if (GrnList.isNotEmpty) {
      for (int i = 0; i < GrnList.length; i++) {
        if (grnno==GrnList[i].lrNo) {
          // inputRemarks.add(TextEditingController());
          parti_GrnList?.add(GrnList[i]);
          total_qty+=GrnList[i].qtyInBox??0;
          total_dis+=GrnList[i].discAmt??0;
          total_netAmt+=GrnList[i].netAmt??0;
          total_Amt+=GrnList[i].totalAmt??0;
          total_tax+=GrnList[i].totalTaxAmt??0;
        }
      }
      print("total_tax");
      print(total_tax);


      round_off=total_Amt-total_Amt.round();
      dummyGrnList=parti_GrnList;
      change(GrnList, status: RxStatus.success());
    } else {
      change(GrnList, status: RxStatus.empty());
    }
  }

  Future<void> SaveGRNData() async {

    String currentDate = Date_Time().DateTimeCurrent();
    List TransactionDtls = [];
    List TaxdetailsList = [];
    double TotalGrossAmt = 0;
    double TotalDiscAmt = 0;
    double TotalTaxAmt = 0;
    double netAmt = 0;
    double totalAmt = 0;
    double roundOffAmt = 0;
    double mrpAmt = 0;
    int transactionNo = 0;
    String transactionDate = '';
    String lrNo = '';
    String lrDate = '';
    for (int i = 0; i < dummyGrnList!.length; i++) {
      transactionNo = dummyGrnList?[i].transactionNo ?? 0;
      transactionDate = dummyGrnList?[i].transactionDate ?? '';
      lrNo = dummyGrnList?[i].lrNo ?? '';
      lrDate = dummyGrnList?[i].lrDate ?? '';
      netAmt += dummyGrnList?[i].netAmt ?? 0;
      totalAmt += dummyGrnList?[i].totalAmt ?? 0;
      mrpAmt += dummyGrnList?[i].mrpAmt ?? 0;
      double grossTotal = dummyGrnList?[i].grossTotal ?? 0;
      double totalTaxAmt = dummyGrnList?[i].totalTaxAmt ?? 0;
      double discAmt = dummyGrnList?[i].discAmt ?? 0;
      TotalGrossAmt += grossTotal;
      TotalDiscAmt += discAmt;
      TotalTaxAmt += totalTaxAmt;


      var transactionMap = {
        "companyNo":
        int.parse(Preferences.getStringValuesSF(Preferences.companyNo)),
        "plantNo":
        int.parse(Preferences.getStringValuesSF(Preferences.plantNo)),
        "divisionNo":
        int.parse(Preferences.getStringValuesSF(Preferences.divisionNo)),
        "srNo": i + 1, //0 i++
        "materialNo": dummyGrnList?[i].materialNo,
        "batchNo": dummyGrnList?[i].batchNo,
        "qty": dummyGrnList?[i].receiveQtyInPcs,
        "batchRate": dummyGrnList?[i].batchRate, //batchRate
        "zpts": dummyGrnList?[i].batchRate, //batchRate
        "zptr": dummyGrnList?[i].batchRate, //batchRate
        "mrp": dummyGrnList?[i].batchRate, //batchRate
        "userCode": Preferences.getStringValuesSF(Preferences.userCode),
        "grossTotal": dummyGrnList?[i].grossTotal, //grossTotal add
        "discAmt": dummyGrnList?[i].discAmt, //discAmt add
        "netAmt": dummyGrnList?[i].netAmt, // netAmt add
        "totalTaxAmt": dummyGrnList?[i].totalTaxAmt, // add totalTaxAmt
        "totalAmt": dummyGrnList?[i].totalAmt, //totalAmt add
        "schemeDiscAmt": dummyGrnList?[i].batchRate, //batchRate
        "mrpAmt": dummyGrnList?[i].batchRate, //batchRate
        "remark": dummyGrnList?[i].remark, //Enter value  add
        "locationNo": int.parse(Preferences.getStringValuesSF(Preferences.locationNo)), //storageNo add
        "modifyOn": currentDate,
        //static variable
        "transactionDtlNo": -1, // static
        "transactionNo": -1, // static
        "freeFlag": "N",
        "exciseValue": 0,
        "documentNo": '',
        "refTransactionNo": 0,
        "zCostPrice": 0,
        "zPurchasePrice": 0,
        "accessibleValue": 0,
        "tradeDiscAmt": 0,
        "cashDiscAmt": 0,
        "schemeCode": "",
        "reasonNo": 0,
        "claimedQty": 0,
        "receivedQty": 0,
        "rejectedQty": 0,
        "returnQty": 0,
        "invCount": "N",
        "returnRate": 0,
        "sourceMaterialNo": 0,
        "addSub": "A",
        "refLocationNo": 0,
        "replicaFlag": "N",
        "totalExciseAmt": 0,
        "assesableAmt": 0,
        "assayPer": 0,
        "templateType": '',
        "tenderTemplateNo": 0,
        "basketRangeMatrixNo": 0,
        "basketDiscPer": 0,
        "basketDiscAmt": 0,
        "hsnCode": ''
      };
      TransactionDtls.add(transactionMap);
      double per_taxTotal = (dummyGrnList?[i].totalTaxAmt ?? 0) / 2;
      double percent = (totalTaxAmt.round() / grossTotal.round()) * 100;
      double taxtypePerc = percent.round() / 2;
      for (int j = 0; j < Common_text.TotalGST_CUT.length; j++) {
        int srNo= i + 1;
        int condSeqNo= j + 1;
        var taxdetailsMap = {
          "companyNo":
          int.parse(Preferences.getStringValuesSF(Preferences.companyNo)),
          "plantNo":
          int.parse(Preferences.getStringValuesSF(Preferences.plantNo)),
          "divisionNo":
          int.parse(Preferences.getStringValuesSF(Preferences.divisionNo)),
          "taxtypeCode": Common_text.TotalGST_CUT[j] == 'C_Gst'
              ? "6"
              : "5", // c GST type and S Gst
          "userCode": Preferences.getStringValuesSF(Preferences.userCode),
          "modifyOn": currentDate,
          "srNo":srNo,
          "taxableAmt": grossTotal, // gross total (9 % tax)
          "tax": per_taxTotal, // totalTaxAmt
          "taxtypePerc": taxtypePerc.round(), //  cal per ( taxableAmt and tax diffent per)
          //static variable
          "transactionTaxDtlNo": -1,
          "transactionNo": -1,
          "documentNo": '',
          "flgFree": "O",
          "condSeqNo": condSeqNo,
          "taxtypeAmt": 0,
          "addSub": "A",
          "calcTaxable": "Y",
          "rebatementPerc": 0,
          "rebatementvalue": 0,
          "replicaFlag": "N"
        };
        TaxdetailsList.add(taxdetailsMap);
      }
    }
    roundOffAmt= totalAmt-totalAmt.round();
    var Final_Map = {
      "companyNo": int.parse(Preferences.getStringValuesSF(Preferences.companyNo)),
      "plantNo": int.parse(Preferences.getStringValuesSF(Preferences.plantNo)),
      "divisionNo":
      int.parse(Preferences.getStringValuesSF(Preferences.divisionNo)),
      "transactionDate": currentDate,
      "docLockDate": currentDate,
      "docDueDate": currentDate,
      "docTypeCode": Common_text.GrnCode, // static
      "custSupNo":
      int.parse(Preferences.getStringValuesSF(Preferences.custSupNO)),
      "finYear": Date_Time.currentYear,
      "remark": Common_text.GrnCodeRemark, // static
      "receiptDate": currentDate,
      "refDocNo": transactionNo, //transactionNo add
      "refDocDate": transactionDate, //transactionDate add
      "lrNo": lrNo, // lrNo add
      "lrDate": lrDate, //lrDate add
      "userCode": Preferences.getStringValuesSF(Preferences.userCode),
      "modifyOn": currentDate,
      //total view
      "grossTotal": TotalGrossAmt,
      "discountAmt": TotalDiscAmt,
      "totalTaxAmt": TotalTaxAmt,
      "netInvoiceAmt": netAmt, // net amount total
      "totalDocAmt": totalAmt.round(),   //total amount
      "roundOffAmt": roundOffAmt,
      "balanceInvoiceAmt": TotalGrossAmt, //total amount
      // static variable
      "totalMRPAmt":mrpAmt, //mrpAmt
      "period": 0,
      "transporterNo": 0,
      "deliveryModeNo": 0,
      "paymentTermNo": 0,
      "cancelFlag": 'N',
      "documentNo": '',
      "refMemoNo": '',
      "transactionNo": -1,
      "reasonNo": 0,
      "orderType": '',
      "bankNo": 0, //0
      "instrumentNo": '',
      "discountCode": '',
      "authorizeFlag": "N",
      "customerRefNo": '',
      "addSub": "A", // static
      "insuranceFlag": "N", // N
      "bounceIndi": 'N',
      "cases": 0,
      "exciseCode": '',
      "getPassCode": '',
      "replicaFlag": "N",
      "exciseRuleNo": 0,
      "sisterConcernNo": 0,
      "materialTypeNo": 0,
      "arNo": '',
      "batchConfirm": 'N',
      "basketRangeMatrixNo": 0,
      "basketDiscPer": 0,
      "basketDiscAmt": 0,
      "receivedCrates": 0,
      "returnCrates": 0,
      "billToAddressNo": 0,
      "shipToAddressNo": 0,
      "boxes": 0,
      "totalQty": 0,
      "totalQtyinLTR": 0,
      "comsRefNo": '',
      "tcsAmt": 0,
      "totalAmtBeforeTCSAmt": 0,
      "tcsTaxPer": 0,
      "tcsTaxableAmt": 0,
      "onlineTransactionDtls": TransactionDtls,
      "onlineTransactionTaxDtls": TaxdetailsList,
    };
    Get.log('Final_Map');
    Get.log(json.encode(Final_Map));
    final saveData = await Provider().SaveGRNData(Final_Map);
    if (saveData != '') {
      if (saveData['responseCode'] == Common_text.RESPONSE_OK) {
        Get.back();
        Get.back();
        CusReponseMess().DialogBox(reposMess: saveData['message'].toString());
        // Flutter_toast_mes().Error_Message(saveData['message'].toString());

      }else{
        Get.back();
        CusReponseMess().DialogBox(reposMess: saveData['message'].toString(),errorType: true);
      }
    } else {
      print("step 2");
      print("Failed");
      Get.back();
      CusReponseMess().DialogBox(reposMess: "Failed",errorType: true);
      // Flutter_toast_mes().Error_Message('Failed', error_code: true);
      // Get.back();
    }
  }
}
