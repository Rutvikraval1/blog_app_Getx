
import 'package:get/get.dart';


class ProfileController extends GetxController
    with StateMixin<dynamic> {

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }




}