import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../localDB/DatabaseHelper.dart';
import '../service/pref_manager.dart';
import '../model/PurchaseOrderModel.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../widget/Flutter_toast_mes.dart';

class PurchaseorderController extends GetxController with StateMixin<dynamic> {
  TextEditingController SearchFilterText = TextEditingController();

  List<MaterialMst>? materialMst = [];
  List<MaterialMst>? purchseList = [];
  List<MaterialMst>? category_list=[];
  List<TextEditingController>? inputText = [];
  int seleted_cate_id=0;
  List? materialCategoryNo=[];
  List? materialCategoryName=[];
  @override
  void onInit() {
    // TODO: implement onInit
    getpurchaseList();
    super.onInit();
  }

  Future<void> getpurchaseList({bool isloader=false}) async {
    if(isloader){
      change(materialMst, status: RxStatus.loading());
      inputText=[];
      materialCategoryNo=[];
      materialCategoryName=[];
    }
    var mapdata = {
      "CustSUpNo":Preferences.getStringValuesSF(Preferences.custSupNO),
      "PlantNo":Preferences.getStringValuesSF(Preferences.plantNo),
    };
    PurchaseOrderModel getPurchaselist =
        await Provider().getPurchaseOrderList(mapdata);
    if (getPurchaselist.responseCode == Common_text.RESPONSE_OK) {
      print("responseCode");
      purchseList = getPurchaselist.materials ?? [];
      materialMst = purchseList;
      if (materialMst!.isNotEmpty) {
        seleted_cate_id=0;
        materialCategoryNo=[0];
        materialCategoryName=['All'];
        for (int i = 0; i < materialMst!.length; i++) {
          inputText?.add(TextEditingController());
          if(!materialCategoryNo!.contains(materialMst?[i].materialCategoryNo)){
            materialCategoryNo?.add(materialMst?[i].materialCategoryNo);
            materialCategoryName?.add(materialMst?[i].materialCategoryName);
          }
        }
        change(materialMst, status: RxStatus.success());
      } else {
        change(materialMst, status: RxStatus.empty());
      }
    } else {
      print("Failed");
      if(getPurchaselist.materials!.isEmpty){
        change(materialMst, status: RxStatus.empty());
      }else{
        change(materialMst,
            status: RxStatus.error(getPurchaselist.message.toString()));
      }
    }
  }

  Future<bool> checklocalDb({String materialNo=''}) async {
    final CheckRow = await DBHelper().CheckROWPurchase(
      material_No: materialNo,
    );
    return CheckRow;
  }


  void clearTextValue(){
    inputText=[];
    if (purchseList!.isNotEmpty) {
      for (int i = 0; i < purchseList!.length; i++) {
        inputText?.add(TextEditingController());
      }
    update();
    }
  }

  Future<void> addChart({
    String materialNo = '',
    String rate = '',
    String materialCategoryName = '',
    String materialCategoryNo = '',
    String materialCode = '',
    String materialName = '',
    String mrp = '',
    String Qty = '',
    String stateWiseTaxPerc = '',
    String taxAmount = '',
  }) async {
    // Check row
    final CheckRow = await checklocalDb(materialNo:materialNo );
    if (CheckRow) {
      // Update row
      final data = await DBHelper()
          .Update_PurchaseOrderCart(material_No: materialNo, updateQty: Qty);
      if (data != '') {
        Flutter_toast_mes().Error_Message("Successfully update to cart");
      } else {
        Flutter_toast_mes().Error_Message("Please try again");
      }
    } else {
      // Insert row
      final data = await DBHelper().Insert_PurchaseOrderChart({
        DBHelper.materialNo: materialNo,
        DBHelper.rate: rate,
        DBHelper.materialCategoryName: materialCategoryName,
        DBHelper.materialCategoryNo: materialCategoryNo,
        DBHelper.materialCode: materialCode,
        DBHelper.materialName: materialName,
        DBHelper.mrp: materialName,
        DBHelper.Qty: Qty,
        DBHelper.stateWiseTaxPerc: stateWiseTaxPerc,
        DBHelper.taxAmount: taxAmount,
      });
      if (data != '') {
        Flutter_toast_mes().Error_Message("Successfully added to cart");
      } else {
        Flutter_toast_mes().Error_Message("Please try again");
      }
    }
  }

  void SearchFilter(String value) {
    if (value.isEmpty) {
      materialMst = purchseList;
    } else {
      materialMst = purchseList?.where((data) {
        return data.materialName
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase())||data.materialCode
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    inputText=[];
    for (int i = 0; i < materialMst!.length; i++) {
      inputText?.add(TextEditingController());
    }
    update();
  }

  void CategoryOnTap(int cate_id){
    seleted_cate_id=cate_id;
   if(cate_id==0){
     materialMst=purchseList;
     inputText=[];
     for (int i = 0; i < materialMst!.length; i++) {
       inputText?.add(TextEditingController());
     }
   }
   else{
     inputText=[];
     category_list=[];
     for (int i = 0; i < purchseList!.length; i++) {
       if(purchseList?[i].materialCategoryNo==cate_id){
         inputText?.add(TextEditingController());
         category_list?.add(purchseList![i]);
       }
     }
     materialMst=category_list;
   }
   update();
  }
}
