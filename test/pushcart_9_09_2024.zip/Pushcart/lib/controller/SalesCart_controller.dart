
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../localDB/DatabaseHelper.dart';
import '../screen/purchaseOrder/SuccessOrder/successOrder_screen.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../widget/AlertDialog/ResponseMessageShow.dart';
import '../widget/Date_Time/Date_time.dart';
import '../widget/Flutter_toast_mes.dart';
class SalesCartController extends GetxController with StateMixin<dynamic> {
  List? lst = [];
  List<TextEditingController>? inputText = [];
  double totalamount = 0.0;
  double totalamtRoundOff = 0.0;
  double NetAmt = 0.0;
  double total_Rate = 0.0;
  double CGST_Tax = 0;
  double SGST_Tax = 0;
  String custId='';
  String CustSupTypeNo='';
  String divisionNo='';
  String billto='';
  String shipto='';
  // User Details
  String CustomerName='';
  String CustomerCode='';
  @override
  void onInit() {
    Preferences.init();
    divisionNo=Get.arguments[1];
    billto=Get.arguments[2];
    shipto=Get.arguments[3];
    CustSupTypeNo=Get.arguments[4];
    SalesTotalCart();
    // TODO: implement onInit
    super.onInit();
  }

  String particular_Total_rate({String cur_rate = '', String totalQty = ''}) {
    double currentRate = double.parse(cur_rate);
    int current_qty = int.parse(totalQty);
    double total = current_qty * currentRate;
    return total.toStringAsFixed(2);
  }

  SalesTotalCart({bool isloader=false,BuildContext? context}) async {
    custId=Get.arguments[0];
    inputText = [];
    lst = await DBHelper().GetTotalSalesOrder(custId);
    for (int i = 0; i < lst!.length; i++) {
      CustomerName=lst?[i]['CustomerName'];
      CustomerCode=lst?[i]['vendorCode'];
      inputText?.add(TextEditingController(text: lst?[i]['Qty']));
    }
    // bool isload=await GetTaxDetails(isloder: isloader);
    await totalAmount();
    if (lst!.isNotEmpty) {
    //   if(isloader){
    //     if(isload){
    //       Get.back();
    //     }
    //   }
      change(lst, status: RxStatus.success());
    } else {
      // if(isloader){
      //   Get.back();
      // }
      change(lst, status: RxStatus.empty());
    }
  }


  Future<void> totalAmount() async {
    NetAmt = 00.0;
    totalamount = 00.0;
    CGST_Tax = 00.0;
    SGST_Tax = 00.0;
    final data = await DBHelper().GetTotalSalesOrder(custId);
    if (data!.isNotEmpty) {
      for (var i = 0; i < data.length; i++) {
        print(data[i]);
        double currentRate = double.parse(data[i]['rate']);
        int current_qty = int.parse(data[i]['Qty']);
        double total = current_qty * currentRate;
        NetAmt += total;
        // calu Tax
        double taxAmount = double.parse(data[i]['taxAmount']);
        double GstTax=current_qty*taxAmount/2;
        CGST_Tax += GstTax;
        SGST_Tax += GstTax;
        //Total amount
        double amount=total+taxAmount*current_qty;
        totalamount+=amount;
      }
      print("totalamount");
      print(totalamount);
      totalamtRoundOff=totalamount.round()-totalamount;
    } else {
      NetAmt = 00.0;
      totalamount= 00.0;
      CGST_Tax =00.0;
      SGST_Tax =00.0;
      totalamtRoundOff =00.0;
    }
    update();
  }


  Future<void> salesCartUpdateQty({String materialNo = '', String Qty = '',context}) async {
    final data = await DBHelper()
        .Update_SalesOrderCart(material_No: materialNo, updateQty: Qty,CustomerID: custId);
    if (data != '') {
      await totalAmount();
      // bool isload= await GetTaxDetails(isloder: true);
      // if(isload){
      //   Get.back();
      // }
      update();
      Flutter_toast_mes().Error_Message("Successfully update to cart");
    } else {
      Flutter_toast_mes().Error_Message("Please try again");
    }
  }

  Future<void> deleteCartValue({String materialNo = '',context}) async {
    final data = await DBHelper().RowDeleteSalesOrder(material_No: materialNo,CustomerID: custId);
    if (data != '') {
      Flutter_toast_mes().Error_Message("Successfully Deleted");
    } else {
      Flutter_toast_mes().Error_Message("Please try again");
    }
  }

  // Future<dynamic> GetTaxDetails({bool isloder=false}) async {
  //   total_Rate = 00.0;
  //   totalamount = 00.0;
  //   CGST_Tax = 00.0;
  //   SGST_Tax = 00.0;
  //   totalamount_round = 00.0;
  //   if(isloder){
  //     LoaderAlert().ShowLoader();
  //   }
  //   List salesSchemeDtls = [];
  //   final data = await DBHelper().GetTotalSalesOrder(custId);
  //   if (data!.isNotEmpty) {
  //     for (var i = 0; i < data.length; i++) {
  //       double currentRate = double.parse(data[i]['rate']);
  //       int materialNo = int.parse(data[i]['materialNo']);
  //       int iQty = int.parse(data[i]['Qty']);
  //       double total = iQty * currentRate;
  //       total_Rate += currentRate;
  //       var mapData = {
  //         "CompanyNo": int.parse(Preferences.getStringValuesSF(Preferences.companyNo)),
  //         "PlantNo": int.parse(Preferences.getStringValuesSF(Preferences.supPlantNo)),
  //         "DivisionNo": int.parse(Preferences.getStringValuesSF(Preferences.divisionNo)),
  //         "CustSupNo": int.parse(Preferences.getStringValuesSF(Preferences.custSupNO)),
  //         "MaterialNo": materialNo,
  //         "iQty":iQty,
  //         "Rate": currentRate,
  //         "GrossAmount": total
  //       };
  //       salesSchemeDtls.add(mapData);
  //     }
  //     var finalmapdata = {
  //       "Plantno": int.parse(
  //           Preferences.getStringValuesSF(Preferences.supPlantNo)), //supPlantNo
  //       "DivisionNo":
  //       int.parse(Preferences.getStringValuesSF(Preferences.divisionNo)),
  //       "CustSupNo":
  //       int.parse(Preferences.getStringValuesSF(Preferences.custSupNO)),
  //       "TotalNetAmt": total_Rate, // rate
  //       "discperc": 0, //0
  //       "salesSchemeDtls":salesSchemeDtls
  //     };
  //     try{
  //       final getTaxData = await Provider().GetTaxDetails(finalmapdata);
  //       if (getTaxData != '') {
  //         if (getTaxData['responseCode'] == Common_text.RESPONSE_OK) {
  //           List taxDetails = getTaxData['taxDetails']['applicableTaxDetails'];
  //           if (taxDetails.isNotEmpty) {
  //             taxDetails.forEach((element) {
  //               if (element['vTaxTypeCode'] == 'CGST') {
  //                 CGST_Tax = element['taxAmt'];
  //                 totalamount = element['totalTaxableAmt'];
  //                 print("totalamount");
  //                 print(totalamount);
  //                 print(totalamount.round());
  //                 totalamount_round=totalamount-totalamount.round();
  //               } else if (element['vTaxTypeCode'] == 'SGST') {
  //                 SGST_Tax = element['taxAmt'];
  //               }
  //             });
  //           }
  //           update();
  //           return true;
  //           // if(isloder){
  //           //   Get.back();
  //           // }
  //           print("CGST_Tax");
  //           print(CGST_Tax);
  //           print(SGST_Tax);
  //         }else{
  //           // if(isloder){
  //           //   Get.back();
  //           // }
  //           return false;
  //         }
  //       }else{
  //         // if(isloder){
  //         //   Get.back();
  //         // }
  //         return false;
  //       }
  //     }catch(e){
  //       print("sds");
  //       print(e);
  //       return false;
  //     }
  //
  //   }else{
  //     return true;
  //   }
  // }


  Future<void> SalesCartSubmitData(context) async {
    String currentDate = Date_Time().DateTimeCurrent();
    List sellOrderlist = [];
    final data = await DBHelper().GetTotalSalesOrder(custId);
    if (data!.isNotEmpty) {
      for (var i = 0; i < data.length; i++) {
        double currentRate = double.parse(data[i]['rate']);
        int current_qty = int.parse(data[i]['Qty']);
        double Amount = current_qty * currentRate;
        var salesOrderItem = {
          "MaterialName": data[i]['materialName'],
          "MaterialNo": data[i]['materialNo'],
          "StorageNo": int.parse(Preferences.getStringValuesSF(Preferences.locationNo)),
          "Quantity": current_qty,
          "OfferRate": currentRate,
          "Value": current_qty.toString(),
          "BatchNo": data[i]['BatchNo'],
          "Amount": Amount,
          "HSNCode":data[i]['HSNCode']
        };
        sellOrderlist.add(salesOrderItem);
      }

      var mapdata = {
        "CustSupTypeNo": int.parse(CustSupTypeNo),
        "CustmerNo": custId,
        "DivisionNo": int.parse(divisionNo),
        "CompanyNo": int.parse(Preferences.getStringValuesSF(Preferences.companyNo)),
        "PlantNo": int.parse(Preferences.getStringValuesSF((Preferences.plantNo))),
        "UserCode": Preferences.getStringValuesSF(Preferences.userCode),
        "CustSupOrderDate": currentDate,
        "DispatchDate":currentDate,
        "DocTypeCode": Common_text.SalesOrderCode,// ZOD1
        "ordermode": Common_text.SalesOrdermode, // 1
        "DocumentNo": "",
        "FinalAmount": totalamount,
        "BillToAddressNo": int.parse(billto),
        "ShipToAddressNo": int.parse(shipto),
        "MSLNo": 0,
        "CustRefNo": "0",
        "CommonRefNo": "",
        "CurrencyNo": 0,
        "AddressNo": 0,
        "DivisionName": "",
        "Remark": "",
        "AuthorizedFlag": "N",
        "CashDiscount": 0,
        "SumQuantity": 0,
        "InstrumentNo": "",
        "CashTransaction": "N",
        "orderDtl":sellOrderlist,
      };
      // Get.back();
      Get.log('Final_Map');
      Get.log(json.encode(mapdata));

      final cartData = await Provider().addSalesCartData(mapdata);
      if (cartData != '') {
        print("cartData");
        print(cartData);
        if (cartData['responseCode'] == Common_text.RESPONSE_OK) {
          String order_id=cartData['orderID'].toString();
          // CusReponseMess().DialogBox(reposMess: cartData['message'].toString());
          // Flutter_toast_mes().Error_Message(cartData['message'].toString());
          final data = await DBHelper().AllRowDeleteSalesOrder(CustomerID: custId);
          if (data != '') {
            print('Delete data');
          }else {
            print('not Delete data');
          }
          Get.back();
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => SuccessorderScreen(
                  OrderNo: order_id,
                  TotalPaymnet: totalamount.round().toString(),
                  customerCode: CustomerCode,
                  customerName: CustomerName,
                ),
              ));
        }else{
          Get.back();
          CusReponseMess().DialogBox(reposMess: cartData['message'].toString(),errorType: true);
        }
      } else {
        print("step 2");
        Get.back();
        CusReponseMess().DialogBox(reposMess: "Failed",errorType: true);
        // Flutter_toast_mes().Error_Message('Failed', error_code: true);
        // Get.back();
      }
    }else{
      print("Failed");
      Flutter_toast_mes().Error_Message('No Data', error_code: true);
      Get.back();
    }

  }
}