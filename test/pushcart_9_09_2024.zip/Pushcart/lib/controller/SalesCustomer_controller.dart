

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../model/AttendanceModel.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';

class SalesCustomerController extends GetxController with StateMixin<dynamic> {
  TextEditingController SearchFilterText = TextEditingController();
  List<VendorAttandance>? CustomerList = [];
  List<VendorAttandance>? getCustomerdata = [];
  @override
  void onInit() {
    // TODO: implement onInit
    getCustomerList();
    super.onInit();
  }
  void SearchFilter(String value) {
    if (value.isEmpty) {
      getCustomerdata = CustomerList;
    } else {
      getCustomerdata = CustomerList?.where((data) {
        return data.custSupName
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase())||data.custSupCode
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    update();
  }
  Future<void> getCustomerList() async {
    var mapdata = {
      "plantNo": Preferences.getStringValuesSF(Preferences.plantNo),
    };
    AttandanceModel getttendancelist =
    await Provider().getAttendanceList(mapdata);
    if (getttendancelist.responseCode == Common_text.RESPONSE_OK) {
      print("responseCode");
      CustomerList = getttendancelist.vendorAttandance ?? [];
      getCustomerdata = CustomerList;
      if (getCustomerdata!.isNotEmpty) {
        change(getCustomerdata, status: RxStatus.success());
      } else {
        change(getCustomerdata, status: RxStatus.empty());
      }
    } else {
      if(getttendancelist.vendorAttandance!.isEmpty){
        change(getCustomerdata, status: RxStatus.empty());
      }else {
        print("Failed");
        change(getCustomerdata,
            status: RxStatus.error(getttendancelist.message));
      }
    }
  }
}
