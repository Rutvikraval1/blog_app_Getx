
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../localDB/DatabaseHelper.dart';
import '../model/SalesOrderModel.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../widget/Flutter_toast_mes.dart';

class SalesOrderController extends GetxController with StateMixin<dynamic> {
  TextEditingController SearchFilterText = TextEditingController();
  List materialCategoryNo=[0];
  List materialCategoryName=['All'];
  List<MaterialForSalesOrder>? materialMst = [];
  List<MaterialForSalesOrder>? salesOredrList = [];
  List<TextEditingController>? inputText = [];
  List <MaterialForSalesOrder>? category_list=[];

  String custName = '';
  //
  String custID = '';
  String vendorCode = '';
  String divisionNo = '';
  String billto = '';
  String shipto = '';
  String custSupTypeNo = '';
  @override
  void onInit() {
    // TODO: implement onInit
    custName=Get.arguments[0];
    getSalesOrderList();
    super.onInit();
  }
  void clearTextValue(){
    // inputText=[];
    seleted_cate_id=0;
    SearchFilter('');
  }

  void SearchFilter(String value) {
    if (value.isEmpty) {
      materialMst = salesOredrList;
    } else {
      materialMst = salesOredrList?.where((data) {
        return data.materialName
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase())||data.materialCode
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    inputText=[];
    for (int i = 0; i < materialMst!.length; i++) {
      inputText?.add(TextEditingController());
    }
    update();
  }

  Future<void> getSalesOrderList() async {
    custID=Get.arguments[1];
    divisionNo=Get.arguments[2];
    billto=Get.arguments[3];
    shipto=Get.arguments[4];
    custSupTypeNo=Get.arguments[5];
    vendorCode=Get.arguments[6];
    var mapdata = {
      "CustSupNo":custID,
      "DivisionNo":divisionNo,
      "plantNo":Preferences.getStringValuesSF(Preferences.plantNo),
      "UserCode":Preferences.getStringValuesSF(Preferences.userCode),
    };
    print('sdsd');
    print(mapdata);
    SalesOrderModel getSalesOrderlist = await Provider().getSalesOrderList(mapdata);
    if (getSalesOrderlist.responseCode == Common_text.RESPONSE_OK) {
      print("responseCode");
      salesOredrList = getSalesOrderlist.materialForSalesOrder??[];
      materialMst = salesOredrList;
      if (materialMst!.isNotEmpty) {
        seleted_cate_id=0;
        materialCategoryNo=[0];
        materialCategoryName=['All'];
        for (int i = 0; i < materialMst!.length; i++) {
          inputText?.add(TextEditingController());
          if(!materialCategoryNo.contains(materialMst?[i].materialCategoryNo)){
            materialCategoryNo.add(materialMst?[i].materialCategoryNo);
            materialCategoryName.add(materialMst?[i].materialCategoryName);
          }
        }
        change(materialMst, status: RxStatus.success());
      } else {
        change(materialMst, status: RxStatus.empty());
      }
    } else {
      if(getSalesOrderlist.materialForSalesOrder!.isEmpty){
        change(materialMst, status: RxStatus.empty());
      }else {
        change(materialMst,
            status: RxStatus.error(getSalesOrderlist.message.toString()));
      }
    }
  }


  int seleted_cate_id=0;
  void CategoryOnTap(int cate_id){
    seleted_cate_id=cate_id;
    if(cate_id==0){
      materialMst=salesOredrList;
      inputText=[];
      for (int i = 0; i < materialMst!.length; i++) {
        inputText?.add(TextEditingController());
      }
    }
    else{
      inputText=[];
      category_list=[];
      for (int i = 0; i < salesOredrList!.length; i++) {
        if(salesOredrList?[i].materialCategoryNo==cate_id){
          inputText?.add(TextEditingController());
          category_list?.add(salesOredrList![i]);
        }
      }
      materialMst=category_list;
    }
    update();
  }

  Future<bool> checkSalesDb({String materialNo=''}) async {
    final CheckRow = await DBHelper().CheckROWSalesOrder(
      material_No: materialNo,CustomerID: custID
    );
    return CheckRow;
  }


  Future<void> addChart({
    String materialNo = '',
    String rate = '',
    String materialCode = '',
    String materialName = '',
    String Qty = '',
    String BatchNo = '',
    String stock = '',
    String HSNCode = '',
    String stateWiseTaxPerc = '',
    String taxAmount = '',
  }) async {
    // Check row
    final CheckRow = await checkSalesDb(materialNo:materialNo);
    if (CheckRow) {
      // Update row
      final data = await DBHelper()
          .Update_SalesOrderCart(material_No: materialNo, updateQty: Qty,CustomerID:custID );
      if (data != '') {
        Flutter_toast_mes().Error_Message("Successfully update to cart");
      } else {
        Flutter_toast_mes().Error_Message("Please try again");
      }
    } else {
      // Insert row
      final data = await DBHelper().Insert_SalesOrderChart({
        DBHelper.materialNo: materialNo,
        DBHelper.rate: rate,
        DBHelper.materialCode: materialCode,
        DBHelper.materialName: materialName,
        DBHelper.Qty: Qty,
        DBHelper.BatchNo: BatchNo,
        DBHelper.stock: stock,
        DBHelper.HSNCode: HSNCode,
        DBHelper.CustId: custID ,
        DBHelper.vendorCode: vendorCode ,
        DBHelper.CustomerName: custName ,
        DBHelper.stateWiseTaxPerc: stateWiseTaxPerc,
        DBHelper.taxAmount: taxAmount,
      });
      if (data != '') {
        Flutter_toast_mes().Error_Message("Successfully added to cart");
      } else {
        Flutter_toast_mes().Error_Message("Please try again");
      }
    }
  }
}