import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../model/AttendanceModel.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../widget/AlertDialog/ResponseMessageShow.dart';
import '../widget/Date_Time/Date_time.dart';
import '../widget/Flutter_toast_mes.dart';

class AttendanceController extends GetxController with StateMixin<dynamic> {
  TextEditingController SearchFilterText = TextEditingController();
  List<VendorAttandance>? AttandanceList = [];
  List<VendorAttandance>? getAttandancedata = [];
  List<bool>? AttandancecheckBox = [];
  bool CheckAll = false;
  bool isButtombarCheck = true;
  String SelectedDate = '';
  bool Selecte_IsLeave = false;
  String maxAttendaceDate = '';
  @override
  void onInit() {
    getAttendanceList();
    // TODO: implement onInit
    super.onInit();
  }

  void SearchFilter(String value) {
    CheckAll = false;
    if (value.isEmpty) {
      getAttandancedata = AttandanceList;
    } else {
      getAttandancedata = AttandanceList?.where((data) {
        return data.custSupName
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase());
      }).toList();
    }
    AttandancecheckBox = List.filled(getAttandancedata!.length, false);
    update();
  }

  void checkBoxValue(index, value) {
    AttandancecheckBox?[index] = value;
    update();
  }

  void CheckBoxAll(value) {
    if (value) {
      print("CheckAll");
      print(value);
      CheckAll = true;
      AttandancecheckBox = List.filled(getAttandancedata!.length, true);
    } else {
      CheckAll = false;
      AttandancecheckBox = List.filled(getAttandancedata!.length, false);
    }
    update();
  }

  Future<void> getAttendanceList() async {
    SelectedDate = Date_Time().ShowDateTime();
    var mapdata = {
      "plantNo": Preferences.getStringValuesSF(Preferences.plantNo),
    };
    AttandanceModel getttendancelist =
        await Provider().getAttendanceList(mapdata);
    if (getttendancelist.responseCode == Common_text.RESPONSE_OK) {
      print("responseCode");
      AttandanceList = getttendancelist.vendorAttandance ?? [];
      getAttandancedata = AttandanceList;
      if (getAttandancedata!.isNotEmpty) {
        AttandancecheckBox = List.filled(getAttandancedata!.length, false);
        change(getAttandancedata, status: RxStatus.success());
      } else {
        change(getAttandancedata, status: RxStatus.empty());
      }
    } else {
      if (getttendancelist.vendorAttandance!.isEmpty) {
        change(getAttandancedata, status: RxStatus.empty());
      } else {
        print("Failed");
        change(getttendancelist,
            status: RxStatus.error(getttendancelist.message));
      }
    }
  }

  Future<void> DateChange(String date, bool IsLeave) async {
    SelectedDate = date;
    Selecte_IsLeave = IsLeave;
    update();
  }

  Future<bool> getMaxAttendaceDate(SelectedDate) async {
    print("SelectedDate");
    print(SelectedDate);
    var mapdata = {
      "plantNo": Preferences.getStringValuesSF(Preferences.plantNo),
    };
    final response = await Provider().GetMaxAttendaceDate(mapdata);
    if (response != '') {
      if (response['responseCode'] == Common_text.RESPONSE_OK) {
        maxAttendaceDate = DateYYYY_MM_DD(response['maxAttendaceDate']);
        String selectDate = Date_Time().DateYYYY_MM_DD(SelectedDate);
        bool isCheckDate = Date_Time()
            .DateComparison(apiDate: maxAttendaceDate, seletedDate: selectDate);
        if (isCheckDate) {
          if (maxAttendaceDate != selectDate) {
            Flutter_toast_mes().Error_Message(
                'Requesting To Enter Attendance For $maxAttendaceDate',
                error_code: true);
            // Flutter_toast_mes().Error_Message('Please feel $maxAttendaceDate date', error_code: true);
            return false;
          } else {
            return true;
          }
        } else {
          Flutter_toast_mes()
              .Error_Message('Attendance already summited', error_code: true);
          return false;
        }
      } else {
        Get.back();
        Flutter_toast_mes()
            .Error_Message(response['message'], error_code: true);
        return false;
      }
    } else {
      print("Failed");
      Flutter_toast_mes().Error_Message('Failed', error_code: true);
      Get.back();
      return false;
    }
  }

  String DateYYYY_MM_DD(String current_date) {
    try {
      if (current_date != '') {
        var inputFormat = DateFormat("yyyy-MM-dd'T'HH:mm:ssz");
        var inputDate =
            inputFormat.parse(current_date).add(const Duration(days: 1));
        var outputFormat = DateFormat('yyyy-MM-dd');
        var DDMMY = outputFormat.format(inputDate);
        return DDMMY;
      } else {
        return '';
      }
    } catch (e) {
      return '';
    }
  }

  Future<void> SaveVendorAttandaceData({bool IsconfirmHoliday = false}) async {
    String currentDate = Date_Time().DateYYYY_MM_DD(SelectedDate);
    List dummyList = [];
    List VendorAttandances = [];
    if (!IsconfirmHoliday) {
      for (int i = 0; i < AttandancecheckBox!.length; i++) {
        // if (AttandancecheckBox[i]) {
        dummyList.add(i);
        // }
      }
      if (dummyList.isNotEmpty) {
        for (int i = 0; i < dummyList.length; i++) {
          var jsonMap = {
            "VendorAttandanceDtlNo": -1,
            "VendorAttandanceNo": -1,
            "custSupNo": getAttandancedata?[dummyList[i]].custSupNo,
            "isPresent": AttandancecheckBox?[dummyList[i]],
            "approvalFlag": "N"
          };
          VendorAttandances.add(jsonMap);
        }
        var Final_Map = {
          "VendorAttandanceNo": -1,
          "plantNo":
              int.parse(Preferences.getStringValuesSF(Preferences.plantNo)),
          "AttandanceDate": currentDate,
          "IsLeave": Selecte_IsLeave,
          "remark": '',
          "vendorAttandanceDtls": VendorAttandances
        };

        Get.log('Final_Map');
        Get.log(json.encode(Final_Map));
        final saveData = await Provider().SaveVendorAttandaceData(Final_Map);
        if (saveData != '') {
          if (saveData['responseCode'] == Common_text.RESPONSE_OK) {

            // Flutter_toast_mes().Error_Message(saveData['message'].toString());
            Get.back();
            Get.back();
            CusReponseMess().DialogBox(reposMess: saveData['message'].toString());
          }else{
            Get.back();
            CusReponseMess().DialogBox(reposMess: saveData['message'].toString(),errorType: true);
          }
        } else {
          print("step 2");
          Get.back();
          CusReponseMess().DialogBox(reposMess: "Failed",errorType: true);
          // Flutter_toast_mes().Error_Message('Failed', error_code: true);
          // Get.back();
        }
      } else {
        Flutter_toast_mes()
            .Error_Message('"Please fill Attendance', error_code: true);
        Get.back();
      }
    } else {
      var Final_Map = {
        "VendorAttandanceNo": -1,
        "plantNo":
            int.parse(Preferences.getStringValuesSF(Preferences.plantNo)),
        "AttandanceDate": currentDate,
        "IsLeave": Selecte_IsLeave,
        "remark": '',
        "vendorAttandanceDtls": VendorAttandances
      };
      Get.log('Final_Map');
      Get.log(json.encode(Final_Map));
      final saveData = await Provider().SaveVendorAttandaceData(Final_Map);
      if (saveData != '') {
        if (saveData['responseCode'] == Common_text.RESPONSE_OK) {
          Flutter_toast_mes().Error_Message(saveData['message'].toString());
          Get.back();
          Get.back();
        }
      } else {
        print("Failed");
        Flutter_toast_mes().Error_Message('Failed', error_code: true);
        Get.back();
      }
    }
  }
}
