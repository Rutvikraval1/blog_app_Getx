
import 'package:get/get.dart';

import '../localDB/DatabaseHelper.dart';

class CartCounter extends GetxController {
  List? lst = [];
  @override
  void onInit() {
    // TODO: implement onInit
    TotalCart();
    super.onInit();
  }
  TotalCart()async{
    lst=(await DBHelper().GetTotalPurchaseCart())!.cast<dynamic>();
    update();
  }

  del(int index) {
    lst?.removeAt(index);
    update();
  }
}

class SalesCartCounter extends GetxController {
  List? lst = [];
  String CustId='';
  SalesCartCounter({
    required this.CustId
});
  @override
  void onInit() {
    // TODO: implement onInit
    TotalCart(CustId);
    super.onInit();
  }
  TotalCart(String custId)async{
    lst=(await DBHelper().GetTotalSalesOrder(custId))!.cast<dynamic>();
    update();
  }

  del(int index) {
    lst?.removeAt(index);
    update();
  }
}


