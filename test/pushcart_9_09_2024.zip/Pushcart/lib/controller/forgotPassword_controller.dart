
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../service/provider/provider.dart';
import '../utils/app_locale.dart';
import '../widget/Flutter_toast_mes.dart';


class ForgotPasswordController extends GetxController
    with StateMixin<dynamic> {
  TextEditingController Username=TextEditingController();
  TextEditingController Oldpassword=TextEditingController();
  TextEditingController NewPassword=TextEditingController();
  TextEditingController NewConfirmPassword=TextEditingController();




  Future<void> ForotPassword() async {
    var mapdata = {
      "username": Username.text,
      "password":Oldpassword.text,
      "NewPassword":NewConfirmPassword.text
    };
    final getData = await Provider().ForotPassword(mapdata);
    if (getData != '') {
      if (getData['responseCode'] == Common_text.RESPONSE_OK) {
        Flutter_toast_mes().Error_Message(getData['message'].toString());
        Get.back();
        Get.back();
      }else{
        Flutter_toast_mes().Error_Message(getData['message'].toString());
        Get.back();
      }
    } else {
      print("Failed");
      Flutter_toast_mes().Error_Message('Failed', error_code: true);
      Get.back();
    }
  }

}