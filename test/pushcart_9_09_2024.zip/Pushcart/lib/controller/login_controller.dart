

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pushcart/model/loginModel.dart';
import 'package:pushcart/pages/page_route_name.dart';
import '../../../utils/app_locale.dart';
import '../../../widget/Flutter_toast_mes.dart';
import '../service/app_permission.dart';
import '../service/pref_manager.dart';
import '../service/provider/provider.dart';
import '../service/versionCode.dart';

class LoginController extends GetxController
    with StateMixin<dynamic> {
  TextEditingController uesrname=TextEditingController();
  TextEditingController password=TextEditingController();
  String versionName="";

  @override
  void onInit() {
    // TODO: implement onInit
    Preferences.init();
    AppPermission().requestInstallAPK();
    super.onInit();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  Future<void> login_api() async {
      LoginModel loginModel = await Provider().getLoginDetails(
        username: uesrname.text,
        password: password.text
      );
      if(loginModel.responseCode==Common_text.RESPONSE_OK){
        print("responseCode");
        final userdata=loginModel.userData??[];
        if(userdata.isNotEmpty){
          print("success");
          VersionCode().versionCodeName();
          Preferences.addDataToSF(Preferences.userName, userdata.first.userName.toString());
          Preferences.addDataToSF(Preferences.divisionNo, userdata.first.divisionNo.toString());
          Preferences.addDataToSF(Preferences.companyNo, userdata.first.companyNo.toString());
          Preferences.addDataToSF(Preferences.custSupNO, userdata.first.custSupNO.toString());
          Preferences.addDataToSF(Preferences.plantNo, userdata.first.plantNo.toString());
          Preferences.addDataToSF(Preferences.roleNo, userdata.first.roleNo.toString());
          Preferences.addDataToSF(Preferences.plantName, userdata.first.plantName.toString());
          Preferences.addDataToSF(Preferences.user_active, true);
          Preferences.addDataToSF(Preferences.userCode, userdata.first.userCode.toString());
          Preferences.addDataToSF(Preferences.userNo, userdata.first.userNo.toString());
          Preferences.addDataToSF(Preferences.supPlantNo, userdata.first.supPlantNo.toString());
          Preferences.addDataToSF(Preferences.locationNo, userdata.first.locationNo.toString());

          uesrname.clear();
          password.clear();
          Get.back();
          Get.toNamed(route_main_dashboard);
        }
      }else{
        print("Failed");
        Get.back();
        Flutter_toast_mes().Error_Message(loginModel.message.toString(),error_code: true);
      }
  }


}