// ignore_for_file: file_names, avoid_print

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DBHelper {
  static Database? _db;
  int dbVersion = 1;
  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await initDatabase();
    return _db!;
  }
  Future<Database> getdb() async {
    if (_db != null) {
      return _db!;
    }
    _db = await initDatabase();
    return _db!;
  }

  initDatabase() async {
    var documentDirectory = await getDatabasesPath();
    String path = join(documentDirectory, 'pushcart.db');
    var db = await openDatabase(path, version: dbVersion, onCreate: _onCreate);
    return db;
  }

  _onCreate(Database db, int version) async {
    try {
      await db.execute(PurchaseOrderChart_table);
      await db.execute(salesOrderchart_table);
      await db.execute(logAPI_table);
    } catch (e) {
      print(e);
    }
  }


  //--------------------------------------------------- start table name

  static String PurchaseOrderChart_tableName='PurchaseOrderChart';
  static String SalesOrderChart_tableName='SalesOrderChart';
  static String logAPI_tableName='logAPI';


  //--------------------------------------------------- close table name


  //--------------------------------------------------- start column name

  static String CustomerName='CustomerName';
  static String vendorCode='vendorCode';
  static String CustId='CustId';
  static String materialNo='materialNo';
  static String rate='rate';
  static String mrp='mrp';
  static String materialCode='materialCode';
  static String materialName='materialName';
  static String Qty='Qty';
  static String materialCategoryNo='materialCategoryNo';
  static String materialCategoryName='materialCategoryName';
  static String BatchNo='BatchNo';
  static String HSNCode='HSNCode';
  static String stock='stock';
  static String stateWiseTaxPerc='stateWiseTaxPerc';
  static String taxAmount='taxAmount';

  //--------------------------------------------------- close column name





  ///-------------------------------------create AllNonStudyPatient table

  static String PurchaseOrderChart_table = '''
  CREATE TABLE $PurchaseOrderChart_tableName(
      $materialNo TEXT,
      $rate TEXT,
      $mrp TEXT,
      $materialCode TEXT,
      $materialName TEXT,
      $Qty TEXT,
      $materialCategoryNo TEXT,
      $taxAmount TEXT,
      $stateWiseTaxPerc TEXT,
      $materialCategoryName TEXT)''';




  Future<dynamic> Insert_PurchaseOrderChart(Map<String, dynamic> row) async {
    try{
      _db = await getdb();
      return await _db?.insert(PurchaseOrderChart_tableName, row);
    }catch(e){
      return '';
    }
  }


  Future<dynamic> Update_PurchaseOrderCart({String updateQty='',String material_No=''}) async {
    try{
      _db = await getdb();
      String update_query='UPDATE $PurchaseOrderChart_tableName SET $Qty = ? WHERE $materialNo = ? ';
      return await _db?.rawUpdate(update_query,[updateQty, material_No]);
    }catch(e){
      return '';
    }
  }

  Future<bool> CheckROWPurchase({String material_No=''}) async {
    try{
      _db = await getdb();
      String query='SELECT * FROM $PurchaseOrderChart_tableName WHERE $materialNo = ? ';
      var getList =  await _db?.rawQuery(query,[material_No]);
      print("getList");
      print(getList);
      if(getList!.isNotEmpty){
        return true;
      }else{
        return false;
      }
    }catch(e){
      return false;
    }
  }

  Future<dynamic> GetTotalPurchaseCart() async {
    _db = await getdb();
    var getList = await _db?.query(PurchaseOrderChart_tableName);
    return getList?.toList();
  }

  Future<dynamic> RowDeletecart({String material_No=''}) async {
    try{
      _db = await getdb();
      String delete_query='DELETE FROM $PurchaseOrderChart_tableName WHERE $materialNo = ?';
      return await _db?.rawDelete(delete_query,[material_No]);
    }catch(e){
      return '';
    }
  }

  Future<dynamic> AllRowDeletecart() async {
    try{
      _db = await getdb();
      String delete_query='DELETE FROM $PurchaseOrderChart_tableName';
      return await _db?.rawDelete(delete_query);
    }catch(e){
      return '';
    }
  }


  //------------------------ Sales Order cart
  static String salesOrderchart_table = '''
  CREATE TABLE $SalesOrderChart_tableName(
      $materialNo TEXT,
      $CustomerName TEXT,
      $stateWiseTaxPerc TEXT,
      $taxAmount TEXT,
      $CustId TEXT,
      $vendorCode TEXT,
      $rate TEXT,
      $materialCode TEXT,
      $materialName TEXT,
      $Qty TEXT,
      $BatchNo TEXT,
      $stock TEXT,
      $HSNCode TEXT)''';


  Future<dynamic> Insert_SalesOrderChart(Map<String, dynamic> row) async {
    try{
      _db = await getdb();
      return await _db?.insert(SalesOrderChart_tableName, row);
    }catch(e){
      return '';
    }
  }

  Future<dynamic> Update_SalesOrderCart({String updateQty='',String material_No='',String CustomerID=''}) async {
    try{
      _db = await getdb();
      String update_query='UPDATE $SalesOrderChart_tableName SET $Qty = ? WHERE $materialNo = ? AND $CustId = ?';
      return await _db?.rawUpdate(update_query,[updateQty, material_No,CustomerID]);
    }catch(e){
      return '';
    }
  }

  Future<bool> CheckROWSalesOrder({String material_No='',String CustomerID=''}) async {
    try{
      _db = await getdb();
      String query='SELECT * FROM $SalesOrderChart_tableName WHERE $materialNo = ? AND $CustId = ?';
      var getList =  await _db?.rawQuery(query,[material_No,CustomerID]);
      print("getList");
      print(getList);
      if(getList!.isNotEmpty){
        return true;
      }else{
        return false;
      }
    }catch(e){
      return false;
    }
  }

  Future<dynamic> GetTotalSalesOrder(String custID) async {
   print("custID");
   print(custID);
    _db = await getdb();
   String query='SELECT * FROM $SalesOrderChart_tableName WHERE $CustId = ?';
   var getList =  await _db?.rawQuery(query,[custID]);
    return getList?.toList();
  }

  Future<dynamic> RowDeleteSalesOrder({String material_No='',String CustomerID=''}) async {
    try{
      _db = await getdb();
      String delete_query='DELETE FROM $SalesOrderChart_tableName WHERE $materialNo = ? AND $CustId = ?';
      return await _db?.rawDelete(delete_query,[material_No,CustomerID]);
    }catch(e){
      return '';
    }
  }

  Future<dynamic> AllRowDeleteSalesOrder({String CustomerID=''}) async {
    try{
      _db = await getdb();
      String delete_query='DELETE FROM $SalesOrderChart_tableName WHERE $CustId = ?';
      return await _db?.rawDelete(delete_query,[CustomerID]);
    }catch(e){
      return '';
    }
  }




  ///-------------------------------------create log api  table

  //--------------------------------------------------- start column name

  static String log_id='Id';
  static String log_MethodName='MethodName';
  static String log_Parameter='Parameter';
  static String log_Response='Response';
  static String log_Time='Time';
  static String log_Date='Date';
  static String log_IsError='IsError';

  //--------------------------------------------------- close column name

  static String logAPI_table = '''
  CREATE TABLE $logAPI_tableName(
      $log_id INTEGER PRIMARY KEY,
      $log_MethodName TEXT,
      $log_Parameter TEXT,
      $log_Response TEXT,
      $log_Time TEXT,
      $log_Date TEXT,
      $log_IsError BOOL )''';


  Future<dynamic> insertLogAPI(Map<String, dynamic> row) async {
    try{
      _db = await getdb();
      return await _db?.insert(logAPI_tableName, row);
    }catch(e){
      return '';
    }
  }

  Future<dynamic> deleteLogAPI() async {
    try{
      _db = await getdb();
      String delete_query='DELETE  FROM $logAPI_tableName';
      return await _db?.rawDelete(delete_query);
    }catch(e){
      return '';
    }
  }

}
