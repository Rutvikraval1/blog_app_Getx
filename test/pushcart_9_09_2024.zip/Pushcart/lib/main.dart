import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:pushcart/pages/page_route.dart';
import 'package:pushcart/pages/page_route_name.dart';
import 'package:pushcart/service/pref_manager.dart';
import 'package:pushcart/service/versionCode.dart';
import 'package:pushcart/utils/custColors.dart';

import 'localDB/DatabaseHelper.dart';

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DBHelper().getdb();
  await Preferences.init();
  HttpOverrides.global = MyHttpOverrides();
  VersionCode().versionCodeName();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
        title: 'Pushcart',
        debugShowCheckedModeBanner: false,
        useInheritedMediaQuery: true,
        theme: ThemeData(
          colorScheme:
              ColorScheme.fromSeed(seedColor: AppColors.primaryColorBlue),
          useMaterial3: true,
        ),
        initialRoute: route_splashScreen,
        getPages: AppPages.pages,
        builder: (context, child) {
          return MediaQuery(
              data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
              child: child!);
        }
        );
  }
}
