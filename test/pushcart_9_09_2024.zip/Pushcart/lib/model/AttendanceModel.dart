
import 'dart:convert';

AttandanceModel attandanceModelFromJson(String str) => AttandanceModel.fromJson(json.decode(str));

String attandanceModelToJson(AttandanceModel data) => json.encode(data.toJson());

class AttandanceModel {
  String? responseCode;
  String? message;
  List<VendorAttandance>? vendorAttandance;

  AttandanceModel({
     this.responseCode,
     this.message,
     this.vendorAttandance,
  });

  factory AttandanceModel.fromJson(Map<String, dynamic> json) => AttandanceModel(
    responseCode: json["responseCode"]??'',
    message: json["message"]??'',
    vendorAttandance: List<VendorAttandance>.from(json["vendorAttandance"].map((x) => VendorAttandance.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "vendorAttandance": List<dynamic>.from(vendorAttandance!.map((x) => x.toJson())),
  };
}

class VendorAttandance {
  int? custSupNo;
  String? custSupCode;
  String? custSupName;
  int? divisionNo;
  int? billto;
  int? shipto;
  int? custSupTypeNo;

  VendorAttandance({
     this.custSupNo,
     this.custSupCode,
     this.custSupName,
     this.divisionNo,
     this.billto,
     this.shipto,
     this.custSupTypeNo,
  });

  factory VendorAttandance.fromJson(Map<String, dynamic> json) => VendorAttandance(
    custSupNo: json["custSupNo"]??0,
    custSupCode: json["custSupCode"]??'',
    custSupName: json["custSupName"]??'',
    divisionNo: json["divisionNo"]??0,
    billto: json["billto"]??0,
    custSupTypeNo: json["custSupTypeNo"]??0,
    shipto: json["shipto"]??0,
  );

  Map<String, dynamic> toJson() => {
    "custSupNo": custSupNo,
    "custSupCode": custSupCode,
    "custSupName": custSupName,
    "divisionNo": divisionNo,
    "billto": billto,
    "custSupTypeNo": custSupTypeNo,
    "shipto": shipto,
  };
}
