
// To parse this JSON data, do
//
//     final grnModel = grnModelFromJson(jsonString);

import 'dart:convert';

GrnModel grnModelFromJson(String str) => GrnModel.fromJson(json.decode(str));

String grnModelToJson(GrnModel data) => json.encode(data.toJson());

class GrnModel {
  String? responseCode;
  String? message;
  List<GoodsReceiptNote>? goodsReceiptNote;

  GrnModel({
     this.responseCode,
     this.message,
     this.goodsReceiptNote,
  });

  factory GrnModel.fromJson(Map<String, dynamic> json) => GrnModel(
    responseCode: json["responseCode"]??'',
    message: json["message"]??'',
    goodsReceiptNote: List<GoodsReceiptNote>.from(json["goodsReceiptNote"].map((x) => GoodsReceiptNote.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "goodsReceiptNote": List<dynamic>.from(goodsReceiptNote!.map((x) => x.toJson())),
  };
}

class GoodsReceiptNote {
  int? srNo;
  int? plantNo;
  String? plantName;
  String? remark;
  int? divisionNo;
  int? custSupNo;
  String? custSupName;
  String? documentNo;
  int? transactionNo;
  String? transactionDate;
  int? transporterNo;
  String? lrNo;
  String? lrDate;
  String? comsRefNo;
  double? cases;
  String? materialName;
  String? materialCode;
  int? materialNo;
  String? batchNo;
  int? qtyInBox;
  int? receiveQtyInPcs;
  double? batchRate;
  double? grossTotal;
  double? discAmt;
  double? mrpAmt;
  double? netAmt;
  double? totalTaxAmt;
  double? totalAmt;
  double? invoiceCrates;
  int? storageNo;
  double? tcsPer;
  double? tcsAssessableValue;
  double? tcsValue;



  GoodsReceiptNote({
   this.srNo,
   this.plantNo,
   this.plantName,
   this.remark,
   this.divisionNo,
   this.custSupNo,
   this.comsRefNo,
   this.custSupName,
   this.documentNo,
   this.transactionNo,
   this.transactionDate,
   this.transporterNo,
   this.lrNo,
   this.lrDate,
   this.cases,
   this.materialName,
   this.materialCode,
   this.materialNo,
   this.batchNo,
   this.mrpAmt,
   this.qtyInBox,
   this.receiveQtyInPcs,
   this.batchRate,
   this.grossTotal,
   this.discAmt,
   this.netAmt,
   this.totalTaxAmt,
   this.totalAmt,
   this.invoiceCrates,
   this.storageNo,
   this.tcsPer,
   this.tcsAssessableValue,
   this.tcsValue,
  });

  factory GoodsReceiptNote.fromJson(Map<String, dynamic> json) => GoodsReceiptNote(
    srNo: json["srNo"],
    plantNo: json["plantNo"],
    plantName: json["plantName"],
    remark: '',
    divisionNo: json["divisionNo"],
    custSupNo: json["custSupNo"],
    custSupName: json["custSupName"],
    documentNo:json["documentNo"],
    transactionNo: json["transactionNo"],
    transactionDate:json["transactionDate"],
    transporterNo: json["transporterNo"],
    lrNo: json["lrNo"],
    lrDate: json["lrDate"],
    cases: json["cases"],
    comsRefNo: json["comsRefNo"],
    materialName: json["materialName"],
    materialCode: json["materialCode"],
    materialNo: json["materialNo"],
    batchNo: json["batchNo"],
    qtyInBox: json["qtyInBox"],
    receiveQtyInPcs: json["receiveQtyInPcs"],
    batchRate: json["batchRate"],
    grossTotal: json["grossTotal"],
    discAmt: json["discAmt"],
    mrpAmt: json["mrpAmt"],
    netAmt: json["netAmt"],
    totalTaxAmt: json["totalTaxAmt"],
    totalAmt: json["totalAmt"],
    invoiceCrates: json["invoiceCrates"],
    storageNo: json["storageNo"],
    tcsPer: json["tcsPer"],
    tcsAssessableValue: json["tcsAssessableValue"],
    tcsValue: json["tcsValue"],
  );

  Map<String, dynamic> toJson() => {
    "srNo": srNo,
    "plantNo": plantNo,
    "plantName": plantName,
    "remark": remark,
    "divisionNo": divisionNo,
    "custSupNo": custSupNo,
    "custSupName": custSupName,
    "comsRefNo": comsRefNo,
    "documentNo":documentNo,
    "transactionNo": transactionNo,
    "transactionDate": transactionDate,
    "transporterNo": transporterNo,
    "lrNo": lrNo,
    "lrDate":lrDate,
    "cases": cases,
    "materialName": materialName,
    "materialCode": materialCode,
    "materialNo": materialNo,
    "batchNo": batchNo,
    "qtyInBox": qtyInBox,
    "receiveQtyInPcs": receiveQtyInPcs,
    "batchRate": batchRate,
    "grossTotal": grossTotal,
    "discAmt": discAmt,
    "netAmt": netAmt,
    "mrpAmt": mrpAmt,
    "totalTaxAmt": totalTaxAmt,
    "totalAmt": totalAmt,
    "invoiceCrates": invoiceCrates,
    "storageNo": storageNo,
    "tcsPer": tcsPer,
    "tcsAssessableValue": tcsAssessableValue,
    "tcsValue": tcsValue,
  };
}