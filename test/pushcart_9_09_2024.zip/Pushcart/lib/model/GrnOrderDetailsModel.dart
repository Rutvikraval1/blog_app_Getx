// To parse this JSON data, do
//
//     final grnOrderDetailsModel = grnOrderDetailsModelFromJson(jsonString);

import 'dart:convert';

GrnOrderDetailsModel grnOrderDetailsModelFromJson(String str) => GrnOrderDetailsModel.fromJson(json.decode(str));

String grnOrderDetailsModelToJson(GrnOrderDetailsModel data) => json.encode(data.toJson());

class GrnOrderDetailsModel {
  String? responseCode;
  String? message;
  List<GrnDetail>? grnDetails;

  GrnOrderDetailsModel({
     this.responseCode,
     this.message,
     this.grnDetails,
  });

  factory GrnOrderDetailsModel.fromJson(Map<String, dynamic> json) => GrnOrderDetailsModel(
    responseCode: json["responseCode"],
    message: json["message"],
    grnDetails: List<GrnDetail>.from(json["grnDetails"].map((x) => GrnDetail.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "grnDetails": List<dynamic>.from(grnDetails!.map((x) => x.toJson())),
  };
}

class GrnDetail {
  String? materialCode;
  String? materialName;
  int? srNo;
  double? rate;
  double? amount;
  double? totalTaxAmt;
  double? discAmt;
  double? netAmt;
  int? qty;
  GrnDetail({
     this.materialCode,
     this.materialName,
     this.srNo,
     this.rate,
     this.amount,
     this.totalTaxAmt,
     this.discAmt,
     this.netAmt,
    this.qty,
  });

  factory GrnDetail.fromJson(Map<String, dynamic> json) => GrnDetail(
    materialCode: json["materialCode"]??'',
    materialName: json["materialName"]??'',
    srNo: json["srNo"]??0,
    rate: json["rate"]?.toDouble(),
    amount: json["amount"]?.toDouble(),
    totalTaxAmt: json["totalTaxAmt"]?.toDouble(),
    discAmt: json["discAmt"]?.toDouble(),
    netAmt: json["netAmt"]?.toDouble(),
    qty: json["qty"]??0,
  );

  Map<String, dynamic> toJson() => {
    "materialCode": materialCode,
    "materialName": materialName,
    "srNo": srNo,
    "rate": rate,
    "amount": amount,
    "totalTaxAmt": totalTaxAmt,
    "discAmt": discAmt,
    "netAmt": netAmt,
    "qty": qty,
  };
}
