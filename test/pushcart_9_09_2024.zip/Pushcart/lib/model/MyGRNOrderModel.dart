

import 'dart:convert';

MyGoodsReceiptNotesModel myGENModelFromJson(String str) => MyGoodsReceiptNotesModel.fromJson(json.decode(str));

String myGENOrdersModelToJson(MyGoodsReceiptNotesModel data) => json.encode(data.toJson());

class MyGoodsReceiptNotesModel {
  String? responseCode;
  String? message;
  List<GoodsReceiptNotes>? myGoodsReceiptNotes;

  MyGoodsReceiptNotesModel({
    this.responseCode,
    this.message,
    this.myGoodsReceiptNotes,
  });

  factory MyGoodsReceiptNotesModel.fromJson(Map<String, dynamic> json) => MyGoodsReceiptNotesModel(
    responseCode: json["responseCode"]??'',
    message: json["message"]??'',
    myGoodsReceiptNotes: List<GoodsReceiptNotes>.from(json["myGoodsReceiptNotes"].map((x) => GoodsReceiptNotes.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "myGoodsReceiptNotes": List<dynamic>.from(myGoodsReceiptNotes!.map((x) => x.toJson())),
  };
}

class GoodsReceiptNotes {
  int? plantNo;
  String? plantCode;
  String? plantName;
  int? divisionNo;
  String? divisionName;
  int? custSupNo;
  String? custSupCode;
  String? transactionNo;
  String? documentNo;
  String? transactionDate;
  double? grossTotal;
  double? discountAmt;
  double? netInvoiceAmt;
  double? totalTaxAmt;
  String? orderStatusFlag;
  String? orderStatusDescription;
  String? refOrderNo;
  String? orderType;
  String? custSupName;

  GoodsReceiptNotes({
    this.plantNo,
    this.plantCode,
    this.plantName,
    this.divisionNo,
    this.divisionName,
    this.custSupNo,
    this.custSupCode,
    this.transactionNo,
    this.documentNo,
    this.transactionDate,
    this.grossTotal,
    this.discountAmt,
    this.netInvoiceAmt,
    this.totalTaxAmt,
    this.orderStatusFlag,
    this.orderStatusDescription,
    this.refOrderNo,
    this.orderType,
    this.custSupName,
  });

  factory GoodsReceiptNotes.fromJson(Map<String, dynamic> json) => GoodsReceiptNotes(
    plantNo: json["plantNo"]??0,
    plantCode: json["plantCode"]??'',
    plantName: json["plantName"]??'',
    divisionNo: json["divisionNo"]??0,
    divisionName: json["divisionName"]??'',
    custSupNo: json["custSupNo"]??0,
    custSupCode: json["custSupCode"]??'',
    transactionNo: json["transactionNo"]??'',
    documentNo: json["documentNo"]??'',
    transactionDate:json["transactionDate"]??'',
    grossTotal: double.parse(json["grossTotal"].toString()),
    discountAmt: double.parse(json["discountAmt"].toString()),
    netInvoiceAmt: double.parse(json["netInvoiceAmt"].toString()),
    totalTaxAmt: double.parse(json["totalTaxAmt"].toString()),
    orderStatusFlag: json["orderStatusFlag"]??'',
    orderStatusDescription: json["orderStatusDescription"]??'',
    refOrderNo: json["refOrderNo"]??'',
    orderType: json["orderType"]??'',
    custSupName:json["custSupName"]??'',
  );

  Map<String, dynamic> toJson() => {
    "plantNo": plantNo,
    "plantCode": plantCode,
    "plantName": plantName,
    "divisionNo": divisionNo,
    "divisionName": divisionName,
    "custSupNo": custSupNo,
    "custSupCode": custSupCode,
    "transactionNo": transactionNo,
    "documentNo": documentNo,
    "transactionDate": transactionDate,
    "grossTotal": grossTotal,
    "discountAmt": discountAmt,
    "netInvoiceAmt": netInvoiceAmt,
    "totalTaxAmt": totalTaxAmt,
    "orderStatusFlag": orderStatusFlag,
    "orderStatusDescription": orderStatusDescription,
    "refOrderNo": refOrderNo,
    "orderType": orderType,
    "custSupName": orderType,
  };
}
