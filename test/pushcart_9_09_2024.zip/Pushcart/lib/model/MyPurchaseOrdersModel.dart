
import 'dart:convert';

MyPurchaseOrdersModel myPurchaseOrdersModelFromJson(String str) => MyPurchaseOrdersModel.fromJson(json.decode(str));

String myPurchaseOrdersModelToJson(MyPurchaseOrdersModel data) => json.encode(data.toJson());

class MyPurchaseOrdersModel {
  String? responseCode;
  String? message;
  List<MyPurchaseOrder>? myPurchaseOrders;

  MyPurchaseOrdersModel({
   this.responseCode,
   this.message,
   this.myPurchaseOrders,
  });

  factory MyPurchaseOrdersModel.fromJson(Map<String, dynamic> json) => MyPurchaseOrdersModel(
    responseCode: json["responseCode"]??'',
    message: json["message"]??'',
    myPurchaseOrders: List<MyPurchaseOrder>.from(json["myPurchaseOrders"].map((x) => MyPurchaseOrder.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "myPurchaseOrders": List<dynamic>.from(myPurchaseOrders!.map((x) => x.toJson())),
  };
}

class MyPurchaseOrder {
  int? plantNo;
  String? plantCode;
  String? plantName;
  int? divisionNo;
  String? divisionName;
  int? custSupNo;
  String? custSupCode;
  String? transactionNo;
  String? documentNo;
  String? transactionDate;
  double? grossTotal;
  double? discountAmt;
  double? netInvoiceAmt;
  double? totalTaxAmt;
  String? orderStatusFlag;
  String? orderStatusDescription;
  String? refOrderNo;
  String? orderType;
  String? custSupName;

  MyPurchaseOrder({
     this.plantNo,
     this.plantCode,
     this.plantName,
     this.divisionNo,
     this.divisionName,
     this.custSupNo,
     this.custSupCode,
     this.transactionNo,
     this.documentNo,
     this.transactionDate,
     this.grossTotal,
     this.discountAmt,
     this.netInvoiceAmt,
     this.totalTaxAmt,
     this.orderStatusFlag,
     this.orderStatusDescription,
     this.refOrderNo,
    this.orderType,
    this.custSupName,
  });

  factory MyPurchaseOrder.fromJson(Map<String, dynamic> json) => MyPurchaseOrder(
    plantNo: json["plantNo"]??0,
    plantCode: json["plantCode"]??'',
    plantName: json["plantName"]??'',
    divisionNo: json["divisionNo"]??0,
    divisionName: json["divisionName"]??'',
    custSupNo: json["custSupNo"]??0,
    custSupCode: json["custSupCode"]??'',
    transactionNo: json["transactionNo"]??'',
    documentNo: json["documentNo"]??'',
    transactionDate:json["transactionDate"]??'',
    grossTotal: double.parse(json["grossTotal"].toString()),
    discountAmt: double.parse(json["discountAmt"].toString()),
    netInvoiceAmt: double.parse(json["netInvoiceAmt"].toString()),
    totalTaxAmt: double.parse(json["totalTaxAmt"].toString()),
    orderStatusFlag: json["orderStatusFlag"]??'',
    orderStatusDescription: json["orderStatusDescription"]??'',
    refOrderNo: json["refOrderNo"]??'',
    orderType: json["orderType"]??'',
    custSupName:json["custSupName"]??'',
  );

  Map<String, dynamic> toJson() => {
    "plantNo": plantNo,
    "plantCode": plantCode,
    "plantName": plantName,
    "divisionNo": divisionNo,
    "divisionName": divisionName,
    "custSupNo": custSupNo,
    "custSupCode": custSupCode,
    "transactionNo": transactionNo,
    "documentNo": documentNo,
    "transactionDate": transactionDate,
    "grossTotal": grossTotal,
    "discountAmt": discountAmt,
    "netInvoiceAmt": netInvoiceAmt,
    "totalTaxAmt": totalTaxAmt,
    "orderStatusFlag": orderStatusFlag,
    "orderStatusDescription": orderStatusDescription,
    "refOrderNo": refOrderNo,
    "orderType": orderType,
    "custSupName": orderType,
  };
}
