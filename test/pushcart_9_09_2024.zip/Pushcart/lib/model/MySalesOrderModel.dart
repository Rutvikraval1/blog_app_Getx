


import 'dart:convert';

MySalesModel mySalesodelFromJson(String str) => MySalesModel.fromJson(json.decode(str));

String mySalesOrdersModelToJson(MySalesModel data) => json.encode(data.toJson());

class MySalesModel {
  String? responseCode;
  String? message;
  List<MySalesOrders>? mySalesOrders;

  MySalesModel({
    this.responseCode,
    this.message,
    this.mySalesOrders,
  });

  factory MySalesModel.fromJson(Map<String, dynamic> json) => MySalesModel(
    responseCode: json["responseCode"]??'',
    message: json["message"]??'',
    mySalesOrders: List<MySalesOrders>.from(json["mySalesOrders"].map((x) => MySalesOrders.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "mySalesOrders": List<dynamic>.from(mySalesOrders!.map((x) => x.toJson())),
  };
}

class MySalesOrders {
  int? plantNo;
  String? plantCode;
  String? plantName;
  int? divisionNo;
  String? divisionName;
  int? custSupNo;
  String? custSupCode;
  String? transactionNo;
  String? documentNo;
  String? transactionDate;
  double? grossTotal;
  double? discountAmt;
  double? netInvoiceAmt;
  double? totalTaxAmt;
  String? orderStatusFlag;
  String? orderStatusDescription;
  String? refOrderNo;
  String? orderType;
  String? custSupName;

  MySalesOrders({
    this.plantNo,
    this.plantCode,
    this.plantName,
    this.divisionNo,
    this.divisionName,
    this.custSupNo,
    this.custSupCode,
    this.transactionNo,
    this.documentNo,
    this.transactionDate,
    this.grossTotal,
    this.discountAmt,
    this.netInvoiceAmt,
    this.totalTaxAmt,
    this.orderStatusFlag,
    this.orderStatusDescription,
    this.refOrderNo,
    this.orderType,
    this.custSupName,
  });

  factory MySalesOrders.fromJson(Map<String, dynamic> json) => MySalesOrders(
    plantNo: json["plantNo"]??0,
    plantCode: json["plantCode"]??'',
    plantName: json["plantName"]??'',
    divisionNo: json["divisionNo"]??0,
    divisionName: json["divisionName"]??'',
    custSupNo: json["custSupNo"]??0,
    custSupCode: json["custSupCode"]??'',
    transactionNo: json["transactionNo"]??'',
    documentNo: json["documentNo"]??'',
    transactionDate:json["transactionDate"]??'',
    grossTotal: double.parse(json["grossTotal"].toString()),
    discountAmt: double.parse(json["discountAmt"].toString()),
    netInvoiceAmt: double.parse(json["netInvoiceAmt"].toString()),
    totalTaxAmt: double.parse(json["totalTaxAmt"].toString()),
    orderStatusFlag: json["orderStatusFlag"]??'',
    orderStatusDescription: json["orderStatusDescription"]??'',
    refOrderNo: json["refOrderNo"]??'',
    orderType: json["orderType"]??'',
    custSupName:json["custSupName"]??'',
  );

  Map<String, dynamic> toJson() => {
    "plantNo": plantNo,
    "plantCode": plantCode,
    "plantName": plantName,
    "divisionNo": divisionNo,
    "divisionName": divisionName,
    "custSupNo": custSupNo,
    "custSupCode": custSupCode,
    "transactionNo": transactionNo,
    "documentNo": documentNo,
    "transactionDate": transactionDate,
    "grossTotal": grossTotal,
    "discountAmt": discountAmt,
    "netInvoiceAmt": netInvoiceAmt,
    "totalTaxAmt": totalTaxAmt,
    "orderStatusFlag": orderStatusFlag,
    "orderStatusDescription": orderStatusDescription,
    "refOrderNo": refOrderNo,
    "orderType": orderType,
    "custSupName": orderType,
  };
}
