
import 'dart:convert';

PurchaseOrderDetailsModel purchaseOrderDetailsModelFromJson(String str) => PurchaseOrderDetailsModel.fromJson(json.decode(str));

String purchaseOrderDetailsModelToJson(PurchaseOrderDetailsModel data) => json.encode(data.toJson());

class PurchaseOrderDetailsModel {
  String? responseCode;
  String? message;
  List<PurchaseOrderDetail>? purchaseOrderDetails;

  PurchaseOrderDetailsModel({
         this.responseCode,
         this.message,
         this.purchaseOrderDetails,
  });

  factory PurchaseOrderDetailsModel.fromJson(Map<String, dynamic> json) => PurchaseOrderDetailsModel(
    responseCode: json["responseCode"],
    message: json["message"],
    purchaseOrderDetails: List<PurchaseOrderDetail>.from(json["purchaseOrderDetails"].map((x) => PurchaseOrderDetail.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "purchaseOrderDetails": List<dynamic>.from(purchaseOrderDetails!.map((x) => x.toJson())),
  };
}

class PurchaseOrderDetail {
  String? materialCode;
  String? materialName;
  int? srNo;
  double? rate;
  double? amount;
  double? totalTaxAmt;
  double? discAmt;
  double? netAmt;
  int? qty;

  PurchaseOrderDetail({
    this.materialCode,
    this.materialName,
    this.srNo,
    this.rate,
    this.amount,
    this.totalTaxAmt,
    this.discAmt,
    this.netAmt,
    this.qty,
  });

  factory PurchaseOrderDetail.fromJson(Map<String, dynamic> json) => PurchaseOrderDetail(
    materialCode: json["materialCode"]??'',
    materialName: json["materialName"]??'',
    srNo: json["srNo"]??0,
    rate: json["rate"]?.toDouble(),
    amount: json["amount"]?.toDouble(),
    totalTaxAmt: json["totalTaxAmt"]?.toDouble(),
    discAmt: json["discAmt"]?.toDouble(),
    netAmt: json["netAmt"]?.toDouble(),
    qty: json["qty"]??0,
  );

  Map<String, dynamic> toJson() => {
    "materialCode": materialCode,
    "materialName": materialName,
    "srNo": srNo,
    "rate": rate,
    "amount": amount,
    "totalTaxAmt": totalTaxAmt,
    "discAmt": discAmt,
    "netAmt": netAmt,
    "qty": qty,
  };
}
