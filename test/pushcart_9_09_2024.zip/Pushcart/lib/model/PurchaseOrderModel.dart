
import 'dart:convert';

PurchaseOrderModel purchaseOrderModelFromJson(String str) => PurchaseOrderModel.fromJson(json.decode(str));

String purchaseOrderModelToJson(PurchaseOrderModel data) => json.encode(data.toJson());

class PurchaseOrderModel {
  String? responseCode;
  String? message;
  List<MaterialMst>? materials;

  PurchaseOrderModel({
     this.responseCode,
     this.message,
     this.materials,
  });

  factory PurchaseOrderModel.fromJson(Map<String, dynamic> json) => PurchaseOrderModel(
    responseCode: json["responseCode"],
    message: json["message"],
    materials: List<MaterialMst>.from(json["materials"].map((x) => MaterialMst.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "materials": List<dynamic>.from(materials!.map((x) => x.toJson())),
  };
}

class MaterialMst {
  int? materialNo;
  String? materialCode;
  String? materialName;
  String? isFlavourOfTheMonth;
  int? materialCategoryNo;
  String? materialCategoryName;
  double? rate;
  double? mrp;
  int? pIndex;
  String? flag;
  dynamic stock;
  String? soSchemeFlag;
  int? isSchemeExclude;
  int? isSchemeExcludeMaterial;
  String? hsnCode;
  String? fomImagePath;
  String? isStockDisplay;
  String? isComs;
  int? soq;
  int? sr;
  double? stateWiseTaxPerc;
  double? taxAmount;


  MaterialMst({
    this.materialNo,
    this.materialCode,
    this.materialName,
    this.isFlavourOfTheMonth,
    this.materialCategoryNo,
    this.materialCategoryName,
    this.rate,
    this.mrp,
    this.pIndex,
    this.flag,
    this.stock,
    this.soSchemeFlag,
    this.isSchemeExclude,
    this.isSchemeExcludeMaterial,
    this.hsnCode,
    this.fomImagePath,
    this.isStockDisplay,
    this.isComs,
    this.soq,
    this.sr,
    this.stateWiseTaxPerc,
    this.taxAmount
  });

  factory MaterialMst.fromJson(Map<String, dynamic> json) => (MaterialMst(
    materialNo: json["materialNo"],
    materialCode: json["materialCode"],
    materialName: json["materialName"],
    isFlavourOfTheMonth: json["isFlavourOfTheMonth"],
    materialCategoryNo: json["materialCategoryNo"],
    materialCategoryName: json["materialCategoryName"],
    rate: json["rate"]?.toDouble(),
    mrp: json["mrp"],
    pIndex: json["pIndex"],
    flag: json["flag"],
    stock: json["stock"],
    soSchemeFlag: json["soSchemeFlag"],
    isSchemeExclude: json["isSchemeExclude"],
    isSchemeExcludeMaterial: json["isSchemeExcludeMaterial"],
    hsnCode: json["hsnCode"],
    fomImagePath: json["fomImagePath"]??'',
    isStockDisplay: json["isStockDisplay"],
    isComs: json["isCOMS"],
    soq: json["soq"],
    sr: json["sr"],
    stateWiseTaxPerc: json["stateWiseTaxPerc"],
    taxAmount: json["taxAmount"],
  ));

  Map<String, dynamic> toJson() => {
    "materialNo": materialNo,
    "materialCode": materialCode,
    "materialName": materialName,
    "isFlavourOfTheMonth": isFlavourOfTheMonth,
    "materialCategoryNo": materialCategoryNo,
    "materialCategoryName": materialCategoryName,
    "rate": rate,
    "mrp": mrp,
    "pIndex": pIndex,
    "flag":flag,
    "stock": stock,
    "soSchemeFlag": soSchemeFlag,
    "isSchemeExclude": isSchemeExclude,
    "isSchemeExcludeMaterial": isSchemeExcludeMaterial,
    "hsnCode": hsnCode,
    "fomImagePath": fomImagePath,
    "isStockDisplay": isStockDisplay,
    "isCOMS": isComs,
    "soq": soq,
    "sr": sr,
    "stateWiseTaxPerc": stateWiseTaxPerc,
    "taxAmount": taxAmount,
  };
}