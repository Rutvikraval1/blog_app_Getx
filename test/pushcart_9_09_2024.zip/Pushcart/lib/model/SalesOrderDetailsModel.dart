
import 'dart:convert';

SalesOrderDetailsModel salesOrderDetailsModelFromJson(String str) => SalesOrderDetailsModel.fromJson(json.decode(str));

String salesOrderDetailsModelToJson(SalesOrderDetailsModel data) => json.encode(data.toJson());

class SalesOrderDetailsModel {
  String? responseCode;
  String? message;
  List<SalesOrderDetail>? salesOrderDetails;

  SalesOrderDetailsModel({
     this.responseCode,
     this.message,
     this.salesOrderDetails,
  });

  factory SalesOrderDetailsModel.fromJson(Map<String, dynamic> json) => SalesOrderDetailsModel(
    responseCode: json["responseCode"],
    message: json["message"],
    salesOrderDetails: List<SalesOrderDetail>.from(json["salesOrderDetails"].map((x) => SalesOrderDetail.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "salesOrderDetails": List<dynamic>.from(salesOrderDetails!.map((x) => x.toJson())),
  };
}

class SalesOrderDetail {
  String? materialCode;
  String? materialName;
  int? srNo;
  double? rate;
  double? amount;
  double? totalTaxAmt;
  double? discAmt;
  double? netAmt;
  int? qty;

  SalesOrderDetail({
    this.materialCode,
    this.materialName,
    this.srNo,
    this.rate,
    this.amount,
    this.totalTaxAmt,
    this.discAmt,
    this.netAmt,
    this.qty,
  });

  factory SalesOrderDetail.fromJson(Map<String, dynamic> json) => SalesOrderDetail(
    materialCode: json["materialCode"]??'',
    materialName: json["materialName"]??'',
    srNo: json["srNo"]??0,
    rate: json["rate"]?.toDouble(),
    amount: json["amount"]?.toDouble(),
    totalTaxAmt: json["totalTaxAmt"]?.toDouble(),
    discAmt: json["discAmt"]?.toDouble(),
    netAmt: json["netAmt"]?.toDouble(),
    qty: json["qty"]??0,
  );

  Map<String, dynamic> toJson() => {
    "materialCode": materialCode,
    "materialName": materialName,
    "srNo": srNo,
    "rate": rate,
    "amount": amount,
    "totalTaxAmt": totalTaxAmt,
    "discAmt": discAmt,
    "netAmt": netAmt,
    "qty": qty,
  };
}
