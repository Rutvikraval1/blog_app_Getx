
import 'dart:convert';

SalesOrderModel salesOrderModelFromJson(String str) => SalesOrderModel.fromJson(json.decode(str));

String salesOrderModelToJson(SalesOrderModel data) => json.encode(data.toJson());

class SalesOrderModel {
  String? responseCode;
  String? message;
  List<MaterialForSalesOrder>? materialForSalesOrder;

  SalesOrderModel({
    this.responseCode,
    this.message,
    this.materialForSalesOrder,
  });

  factory SalesOrderModel.fromJson(Map<String, dynamic> json) => SalesOrderModel(
    responseCode: json["responseCode"]??'',
    message: json["message"]??'',
    materialForSalesOrder: List<MaterialForSalesOrder>.from(json["materialForSalesOrder"].map((x) => MaterialForSalesOrder.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "materialForSalesOrder": List<dynamic>.from(materialForSalesOrder!.map((x) => x.toJson())),
  };
}

class MaterialForSalesOrder {
  int? materialNo;
  String? materialCode;
  String? materialName;
  String? materialCategoryName;
  int? materialCategoryNo;
  double? rate;
  String? batchNo;
  int? qty;
  double? amount;
  int? stock;
  String? remark;
  String? soSchemeFlag;
  String? hsnCode;
  int? billToAddressNo;
  int? shipToAddressNo;
  String? custRefNo;
  String? custRefDate;
  String? comsRemarks;
  String? schemeRemarks;
  String? comsRefNo;
  double? stateWiseTaxPerc;
  double? taxAmount;
  MaterialForSalesOrder({
    this.materialNo,
    this.materialCode,
    this.stateWiseTaxPerc,
    this.taxAmount,
    this.materialName,
    this.materialCategoryName,
    this.materialCategoryNo,
    this.rate,
    this.batchNo,
    this.qty,
    this.amount,
    this.stock,
    this.remark,
    this.soSchemeFlag,
    this.hsnCode,
    this.billToAddressNo,
    this.shipToAddressNo,
    this.custRefNo,
    this.custRefDate,
    this.comsRemarks,
    this.schemeRemarks,
    this.comsRefNo,
  });

  factory MaterialForSalesOrder.fromJson(Map<String, dynamic> json) => MaterialForSalesOrder(
    materialNo: json["materialNo"]??0,
    materialCode: json["materialCode"]??'',
    materialName: json["materialName"]??'',
    materialCategoryName: json["materialCategoryName"]??'',
    materialCategoryNo: json["materialCategoryNo"]??0,
    rate: json["rate"]??0,
    batchNo: json["batchNo"]??'',
    qty: json["qty"]??0,
    amount: json["amount"]??0,
    stock: json["stock"]??0,
    remark: json["remark"]??'',
    soSchemeFlag: json["soSchemeFlag"]??'',
    hsnCode: json["hsnCode"]??'',
    billToAddressNo: json["billToAddressNo"]??0,
    shipToAddressNo: json["shipToAddressNo"]??0,
    custRefNo: json["custRefNo"]??'',
    custRefDate: json["custRefDate"]??'',
    comsRemarks: json["comsRemarks"]??'',
    schemeRemarks: json["schemeRemarks"]??'',
    comsRefNo: json["comsRefNo"]??'',
    taxAmount: json["taxAmount"]??0,
    stateWiseTaxPerc: json["stateWiseTaxPerc"]??0,
  );

  Map<String, dynamic> toJson() => {
    "materialNo": materialNo,
    "materialCode": materialCode,
    "materialName": materialName,
    "materialCategoryName": materialCategoryName,
    "materialCategoryNo": materialCategoryNo,
    "rate": rate,
    "batchNo": batchNo,
    "qty": qty,
    "amount": amount,
    "stock": stock,
    "remark": remark,
    "soSchemeFlag": soSchemeFlag,
    "hsnCode": hsnCode,
    "billToAddressNo": billToAddressNo,
    "shipToAddressNo": shipToAddressNo,
    "custRefNo": custRefNo,
    "custRefDate": custRefDate,
    "comsRemarks": comsRemarks,
    "schemeRemarks": schemeRemarks,
    "comsRefNo": comsRefNo,
    "taxAmount": taxAmount,
    "stateWiseTaxPerc": stateWiseTaxPerc,
  };
}
