
import 'dart:convert';

LoginModel loginModelFromJson(String str) => LoginModel.fromJson(json.decode(str));

String loginModelToJson(LoginModel data) => json.encode(data.toJson());

class LoginModel {
  String? responseCode;
  String? message;
  List<UserDatum>? userData;

  LoginModel({
     this.responseCode,
     this.message,
     this.userData,
  });

  factory LoginModel.fromJson(Map<String, dynamic> json) => LoginModel(
    responseCode: json["responseCode"]??'',
    message: json["message"]??'',
    userData:List<UserDatum>.from(json["userData"].map((x) => UserDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "responseCode": responseCode,
    "message": message,
    "userData": List<dynamic>.from(userData!.map((x) => x.toJson())),
  };
}

class UserDatum {
  int? companyNo;
  int? plantNo;
  String? plantName;
  String? userCode;
  int? divisionNo;
  int? custSupNO;
  int? supPlantNo;
  int? userNo;
  int? roleNo;
  int? stateNo;
  int? locationNo;
  String? userName;
  String? firstName;
  String? lastName;
  String? contactNo;

  UserDatum({
    this.companyNo,
    this.plantNo,
    this.plantName,
    this.userCode,
    this.divisionNo,
    this.userNo,
    this.roleNo,
    this.stateNo,
    this.supPlantNo,
    this.userName,
    this.custSupNO,
    this.locationNo,
    this.firstName,
    this.lastName,
    this.contactNo,
  });

  factory UserDatum.fromJson(Map<String, dynamic> json) => UserDatum(
    companyNo: json["companyNo"]??0,
    plantNo: json["plantNo"]??0,
    plantName: json["plantName"]??'',
    userCode: json["userCode"]??'',
    userNo: json["userNo"]??0,
    divisionNo: json["divisionNo"]??0,
    roleNo: json["roleNo"]??0,
    stateNo: json["stateNo"]??0,
    supPlantNo: json["supPlantNo"]??0,
    userName: json["userName"]??'',
    firstName: json["firstName"]??'',
    custSupNO: json["custSupNO"]??0,
    locationNo: json["locationNo"]??0,
    lastName: json["lastName"]??'',
    contactNo: json["contactNo"]??'',
  );

  Map<String, dynamic> toJson() => {
    "companyNo": companyNo,
    "plantNo": plantNo,
    "plantName": plantName,
    "userCode": userCode,
    "divisionNo": divisionNo,
    "userNo": userNo,
    "roleNo": roleNo,
    "custSupNO": custSupNO,
    "locationNo": locationNo,
    "stateNo": stateNo,
    "supPlantNo": supPlantNo,
    "userName": userName,
    "firstName": firstName,
    "lastName": lastName,
    "contactNo": contactNo,
  };
}
