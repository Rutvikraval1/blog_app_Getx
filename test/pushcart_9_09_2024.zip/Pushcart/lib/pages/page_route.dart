



import 'package:get/get.dart';
import 'package:pushcart/screen/main_home_screen.dart';
import 'package:pushcart/pages/page_route_name.dart';
import 'package:pushcart/screen/Auth/login_screen.dart';
import '../binding/binding_pages.dart';
import '../screen/GRN/grn_screen.dart';
import '../screen/GRN/perti_GrnList.dart';
import '../screen/Home/home_screen.dart';
import '../screen/MyOrder/MyGrn/MyGRN_orderDetails.dart';
import '../screen/MyOrder/MyGrn/MyGrnOrder.dart';
import '../screen/MyOrder/MyPurchaseOrder/MypurchaseOrderDetails.dart';
import '../screen/MyOrder/MyPurchaseOrder/myPurchaseOrder.dart';
import '../screen/MyOrder/MySalesOrder/mySalesOrder.dart';
import '../screen/MyOrder/MySalesOrder/mySalesOrderDetails.dart';
import '../screen/Notification/notification_screen.dart';
import '../screen/attendance/attendance_screen.dart';
import '../screen/auth/forgotPassword.dart';
import '../screen/profile/changePassword.dart';
import '../screen/profile/profile_screen.dart';
import '../screen/purchaseOrder/Cart/cart_screen.dart';
import '../screen/purchaseOrder/purchase_order.dart';
import '../screen/salesOrder/salesCart/salesCart_screen.dart';
import '../screen/salesOrder/salesCustomer_screen.dart';
import '../screen/salesOrder/salesOrder_screen.dart';
import '../screen/splash/splash_screen.dart';
import '../widget/downloadAPK/downloadAPK.dart';


class AppPages {
  static final List<GetPage> pages = [
    GetPage(name: route_splashScreen,
        page: () => const splash_screen(),
        binding: DataBinding()),
    GetPage(name: route_loginScreen,
        page: () => login_screen(),
        binding: DataBinding()),
    GetPage(name: route_forgotScreen,
        page: () => const ForgotPasswordscreen(),
        binding: DataBinding()),
    GetPage(name: route_main_dashboard,
        page: () => const Main_home_screen(),
        binding: DataBinding()),
    GetPage(name: route_profile,
        page: () => const Profile_screen(),
        binding: DataBinding()),
    GetPage(name: route_home,
        page: () => const Home_screen(),
        binding: DataBinding()),
    GetPage(name: route_purchase_order,
        page: () => const PurchaseOrder(),
        binding: DataBinding()),
    GetPage(name: route_cart_screen,
        page: () => const Cart_screen(),
        binding: DataBinding()),
    GetPage(name: route_grn_screen,
        page: () => const GrnScreen(),
        binding: DataBinding()),
    GetPage(name: route_salesCustomer,
        page: () => const SalesCustomerScreen(),
        binding: DataBinding()),
    GetPage(name: route_sales_order,
        page: () => const SalesorderScreen(),
        binding: DataBinding()),
    GetPage(name: route_attendance,
        page: () => const attendance_screen(),
        binding: DataBinding()),
    GetPage(name: route_perti_Grn,
        page: () => const PertiGrnlistScreen(),
        binding: DataBinding()),
    GetPage(name: route_sales_cart,
        page: () => const SalesCart_screen(),
        binding: DataBinding()),
    GetPage(name: route_Mypurchase_order,
        page: () => const Mypurchaseorder(),
        binding: DataBinding()),
    GetPage(name: route_notification,
        page: () => const NotificationScreen(),
        binding: DataBinding()),

    GetPage(name: route_MySalesorder,
        page: () => const MySalesorder(),
        binding: DataBinding()),
    GetPage(name: route_MyGRN_order,
        page: () => const MyGRNsorder(),
        binding: DataBinding()),


    GetPage(name: route_MyPurchase_Details,
        page: () => const MypurchaseorderDetails(),
        binding: DataBinding()),

    GetPage(name: route_MyGRN_order_Details,
        page: () => const MyGRN_orderDetails(),
        binding: DataBinding()),

    GetPage(name: route_MySales_order_details,
        page: () => const MySalesOrderDetails(),
        binding: DataBinding()),
    GetPage(name: route_changePassword,
        page: () => const ChangePasswordScreen(),
        binding: DataBinding()),




  ];
}