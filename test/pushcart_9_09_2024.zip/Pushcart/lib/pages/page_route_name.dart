

/*PAGE ROUTER*/
const route_splashScreen = '/splash';
const route_loginScreen = '/login_screen';
const route_forgotScreen = '/forgot_screen';
const route_changePassword = '/changePassword_screen';
const route_main_dashboard = '/main_dashboard';
const route_profile= '/profile_screen';
const route_home= '/home_screen';
const route_purchase_order= '/purchase_order';
const route_cart_screen= '/cart_screen';
const route_grn_screen ='/grn_screen';
const route_salesCustomer ='/salesCustomer';
const route_sales_order ='/sales_order';
const route_attendance='/attendance';
const route_perti_Grn='/perti_Grn';
const route_sales_cart='/sales_cart';
const route_Mypurchase_order='/mypurchase_order';
const route_notification='/notification';
const route_MySalesorder='/MySales_order';
const route_MyGRN_order='/MyGRN_order';
const route_MyGRN_order_Details='/MyGRN_order_Details';
const route_MySales_order_details='/MySales_order_Details';
const route_MyPurchase_Details='/MyPurchase_Details';
