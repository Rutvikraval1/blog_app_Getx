import 'package:flutter/material.dart';
import 'package:flutter_bounceable/flutter_bounceable.dart';
import 'package:get/get.dart';
import 'package:pushcart/pages/page_route_name.dart';
import 'package:pushcart/widget/Scaffold_widget.dart';
import '../../controller/GRN_controller.dart';
import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../utils/custColors.dart';
import '../../widget/appbar_common.dart';
import '../../widget/emptyScreen/ErrorScreen.dart';
import '../../widget/emptyScreen/emptyScreen.dart';
import '../../widget/input/SearchInput.dart';
import '../../widget/loader/loader.dart';

class GrnScreen extends GetView<GRNController> {
  const GrnScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(
          title_text: 'Good Receipt Note',
          leading_ontap: () {
            Navigator.pop(context);
          },
        ),
        body: controller.obx(
          (data) => Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            child: Column(
              children: [
                cus_size_box().sizedBox_10,
                SizedBox(
                  height: 50,
                  child: SearchInput(
                    onChanged: (value) => controller.SearchFilter(value),
                    textcontroller: controller.SearchFilterText,
                    hintText: 'Search With materials / Code',
                  ),
                ),
                cus_size_box().sizedBox_10,
                Expanded(
                  child: ListView.builder(
                    itemCount: controller.GrnDocumentNo?.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index) => Column(
                      children: [
                        Bounceable(
                          onTap: () {
                            Get.toNamed(route_perti_Grn, arguments: [
                              controller.GrnDocumentNo?[index].lrNo.toString(),
                              controller.GrnDocumentNo?[index].documentNo
                                  .toString()])?.then(
                              (value) => controller.getGRNList(),
                            );
                          },
                          child: Card(
                            surfaceTintColor: AppColors.whiteColor,
                            color: AppColors.whiteColor,
                            elevation: 2,
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        height: 25,
                                        width: 35,
                                        alignment: Alignment.center,
                                        child: Text('${index + 1}'),
                                      ),
                                      Expanded(
                                          child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                              controller.GrnDocumentNo![index]
                                                  .documentNo
                                                  .toString(),
                                              style:
                                                  App_style().textS16MediumPtc),
                                          Text(
                                              'Order no : (${controller.GrnDocumentNo?[index].comsRefNo})',
                                              style: App_style()
                                                  .textS16withOpacity),
                                        ],
                                      )),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        cus_size_box().sizedBox_3
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          onLoading: Center(child: Loader()),
          onEmpty: const Emptyscreen(),
          onError: (error) => Errorscreen(
            ErrorMessage: error.toString(),
          ),
        ));
  }
}
