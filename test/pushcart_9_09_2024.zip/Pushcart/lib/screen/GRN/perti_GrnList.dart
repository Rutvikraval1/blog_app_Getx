import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controller/PertiGrnlist_controller.dart';
import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../utils/custColors.dart';
import '../../widget/AlertDialog/Custom_AlertDialog.dart';
import '../../widget/Scaffold_widget.dart';
import '../../widget/appbar_common.dart';
import '../../widget/button/cus_navigateBtn.dart';
import '../../widget/input/CommonTextField.dart';
import '../../widget/input/SearchInput.dart';
import '../../widget/loader/alertBoxLoader.dart';
import '../../widget/loader/loader.dart';

class PertiGrnlistScreen extends GetView<PertigrnlistController> {
  const PertiGrnlistScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(
          title_text: controller.titleName,
          leading_ontap: () {
            Navigator.pop(context);
          },
        ),
        body: controller.obx(
            (data) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Column(
                    children: [
                      cus_size_box().sizedBox_10,
                      SizedBox(
                        height: 50,
                        child: SearchInput(
                          onChanged: (value) => controller.SearchFilter(value),
                          textcontroller: controller.SearchFilterText,
                          hintText: 'Search With materials / Code',
                        ),
                      ),
                      cus_size_box().sizedBox_10,
                      Expanded(
                        child: ListView.builder(
                          itemCount: controller.parti_GrnList?.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index) => Column(
                            children: [
                              Card(
                                surfaceTintColor: AppColors.whiteColor,
                                color: AppColors.whiteColor,
                                elevation: 2,
                                child: Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          Container(
                                            height: 25,
                                            width: 30,
                                            alignment: Alignment.center,
                                            child: Text('${index + 1}'),
                                          ),
                                          Expanded(
                                              child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                  controller
                                                          .parti_GrnList?[index]
                                                          .materialName ??
                                                      '',
                                                  style: App_style()
                                                      .textS16MediumPtc),
                                              Text(
                                                  '(${controller.parti_GrnList?[index].materialCode}) (${controller.parti_GrnList?[index].batchNo})',
                                                  style: App_style()
                                                      .textS16withOpacity),
                                            ],
                                          )),
                                        ],
                                      ),
                                      Divider(
                                        color: AppColors.grey.shade300,
                                        thickness: 1,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Flexible(
                                            flex: 2,
                                            fit: FlexFit.tight,
                                            child: Column(
                                              children: [
                                                Text(
                                                  'Rate',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularOpacity,
                                                ),
                                                Text(
                                                  controller
                                                      .parti_GrnList![index]
                                                      .batchRate
                                                      .toString(),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularBlue,
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                              height: 50,
                                              child: VerticalDivider(
                                                  color:
                                                      AppColors.grey.shade300)),
                                          Flexible(
                                            flex: 2,
                                            fit: FlexFit.tight,
                                            child: Column(
                                              children: [
                                                Text(
                                                  'Inv Qty',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularOpacity,
                                                ),
                                                Text(
                                                  controller
                                                      .parti_GrnList![index]
                                                      .qtyInBox
                                                      .toString(),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularBlue,
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                              height: 50,
                                              child: VerticalDivider(
                                                  color:
                                                      AppColors.grey.shade300)),

                                          /// pedning
                                          Flexible(
                                            flex: 3,
                                            fit: FlexFit.tight,
                                            child: Column(
                                              children: [
                                                Text(
                                                  'Basic Rate',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularOpacity,
                                                ),
                                                Text(
                                                  controller
                                                      .parti_GrnList![index]
                                                      .grossTotal
                                                      .toString(),
                                                  style: App_style()
                                                      .textS14RegularBlue,
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                              height: 50,
                                              child: VerticalDivider(
                                                  color:
                                                      AppColors.grey.shade300)),
                                          Flexible(
                                            flex: 3,
                                            fit: FlexFit.tight,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'Disc Amt',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularOpacity,
                                                ),
                                                Text(
                                                  controller
                                                      .parti_GrnList![index]
                                                      .discAmt
                                                      .toString(),
                                                  style: App_style()
                                                      .textS14RegularBlue,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      Divider(
                                        color: AppColors.grey.shade300,
                                        thickness: 1,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Flexible(
                                            flex: 2,
                                            fit: FlexFit.tight,
                                            child: Column(
                                              children: [
                                                Text(
                                                  'Net Amt',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularOpacity,
                                                ),
                                                Text(
                                                  controller
                                                      .parti_GrnList![index]
                                                      .netAmt
                                                      .toString(),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularBlue,
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                              height: 50,
                                              child: VerticalDivider(
                                                  color:
                                                      AppColors.grey.shade300)),
                                          Flexible(
                                            flex: 2,
                                            fit: FlexFit.tight,
                                            child: Column(
                                              children: [
                                                Text(
                                                  'Tax Amt',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularOpacity,
                                                ),
                                                Text(
                                                  controller
                                                      .parti_GrnList![index]
                                                      .totalTaxAmt
                                                      .toString(),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularBlue,
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                              height: 50,
                                              child: VerticalDivider(
                                                  color:
                                                      AppColors.grey.shade300)),
                                          Flexible(
                                            flex: 3,
                                            fit: FlexFit.tight,
                                            child: Column(
                                              children: [
                                                Text(
                                                  'Total Amt',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularOpacity,
                                                ),
                                                Text(
                                                  controller
                                                      .parti_GrnList![index]
                                                      .totalAmt
                                                      .toString(),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: App_style()
                                                      .textS14RegularBlue,
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                              height: 50,
                                              child: VerticalDivider(
                                                  color:
                                                      AppColors.grey.shade300)),
                                          Flexible(
                                            flex: 3,
                                            fit: FlexFit.tight,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                    height: 40,
                                                    child: cus_navigateBtn(
                                                      onPressed: () {
                                                        ReviewShowDialog(
                                                            context,
                                                            controller
                                                                .parti_GrnList![
                                                                    index]
                                                                .remark
                                                                .toString(),
                                                            index);
                                                      },
                                                      text: 'Remarks',
                                                    ))
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              cus_size_box().sizedBox_3
                            ],
                          ),
                        ),
                      ),
                      cus_size_box().sizedBox_5,
                      controller.parti_GrnList!.isNotEmpty
                          ? Card(
                              surfaceTintColor: AppColors.whiteColor,
                              color: AppColors.black.withOpacity(0.1),
                              elevation: 0,
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Row(
                                            children: [
                                              Text(
                                                'Tot Qty: ',
                                                style: App_style()
                                                    .textS14Regulargrey,
                                              ),
                                              Text(
                                                controller.total_qty
                                                    .toStringAsFixed(2),
                                                style: App_style()
                                                    .textS14RegularBlue,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Expanded(
                                          child: Row(
                                            children: [
                                              Text('Tot Net Amt: ',
                                                  style: App_style()
                                                      .textS14Regulargrey),
                                              Expanded(
                                                  child: Text(
                                                controller.total_netAmt
                                                    .toStringAsFixed(2),
                                                    overflow: TextOverflow.ellipsis,maxLines: 1, style: App_style()
                                                    .textS14RegularBlue,
                                              )),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                    cus_size_box().sizedBox_5,
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Row(
                                            children: [
                                              Text('Tot Discount: ',
                                                  style: App_style()
                                                      .textS14Regulargrey),
                                              Text(
                                                controller.total_dis
                                                    .toStringAsFixed(2),
                                                style: App_style()
                                                    .textS14RegularBlue,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Expanded(
                                          child: Row(
                                            children: [
                                              Text('Tot Tax: ',
                                                  style: App_style()
                                                      .textS14Regulargrey),
                                              Expanded(
                                                  child: Text(
                                                controller.total_tax
                                                    .toStringAsFixed(2),
                                                    overflow: TextOverflow.ellipsis,maxLines: 1,  style: App_style()
                                                    .textS14RegularBlue,
                                              )),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                    cus_size_box().sizedBox_5,
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Row(
                                            children: [
                                              Text('Round off: ',
                                                  style: App_style()
                                                      .textS14Regulargrey),
                                              Text(
                                                controller.round_off
                                                    .toStringAsFixed(2),
                                                style: App_style()
                                                    .textS14RegularBlue,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Expanded(
                                          child: Row(
                                            children: [
                                              Text('Total Amt: ',
                                                  style: App_style()
                                                      .textS14Semiboldred),
                                              Expanded(
                                                  child: Text(
                                                controller.total_Amt
                                                    .round()
                                                    .toString(),
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 1,
                                                style: App_style()
                                                    .text14SemiboldPtc,
                                              )),
                                            ],
                                          ),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                              ))
                          : const SizedBox()
                    ],
                  ),
                ),
            onLoading: Center(child: Loader())),
        bottomNavigationBar: Container(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: BottomAppBar(
            elevation: 0,
            padding: const EdgeInsets.only(left: 20, right: 20),
            color: Colors.transparent,
            child: Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                  onPressed: () {
                    FocusScope.of(context).requestFocus(FocusNode());
                    LoaderAlert().ShowLoader();
                    controller.SaveGRNData();
                  },
                  text: 'Submit',
                )),
              ],
            ),
          ),
        ));
  }

  // FilterShowDialog(BuildContext context) {
  //   Custom_AlertDialog().AlertDialogBox(
  //     context: context,
  //     title: 'Filter',
  //     content: SingleChildScrollView(
  //       child: Column(
  //         crossAxisAlignment: CrossAxisAlignment.start,
  //         children: [
  //           Text('Ref Document', style: App_style().textS16withOpacity),
  //           cus_size_box().sizedBox_8,
  //           Custom_DropDown(
  //             hintText: 'Select Ref Document',
  //             itemsValue: controller.ref_documentNo,
  //             onChanged: (value) {
  //               FocusScope.of(context).requestFocus(FocusNode());
  //               controller.seletcDropDowm(value);
  //             },
  //           ),
  //           cus_size_box().sizedBox_20,
  //           Text('Receipt No./Gatepass',style: App_style().textS16withOpacity),
  //           cus_size_box().sizedBox_8,
  //           CustomInput(
  //               controller: controller.Receipt_No,
  //               hintText: 'Receipt No.'),
  //           cus_size_box().sizedBox_20,
  //           Row(
  //             children: [
  //               Expanded(
  //                   child: cus_navigateBtn(
  //                     onPressed: () {
  //                       Navigator.pop(context);
  //                     },
  //                     text: 'Cancel',
  //                     backgroundColor: AppColors.lightorgeng,
  //                   )),
  //               const SizedBox(
  //                 width: 20,
  //               ),
  //               Expanded(
  //                   child: cus_navigateBtn(
  //                     onPressed: () {
  //                       FocusScope.of(context).requestFocus(FocusNode());
  //                       Get.back();
  //                       LoaderAlert().ShowLoader(context: context);
  //                       controller.Search_documentNo();
  //                     },
  //                     text: 'Search',
  //                   )),
  //             ],
  //           ),
  //           cus_size_box().sizedBox_10,
  //         ],
  //       ),
  //     ),
  //   );
  // }

  ReviewShowDialog(BuildContext context, String remark, int index) {
    controller.TextController.text = remark;
    Custom_AlertDialog().AlertDialogBox(
      context: context,
      title: 'Remarks',
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            cus_size_box().sizedBox_8,
            CustomInput(
                controller: controller.TextController,
                maxLines: 5,
                hintText: 'Enter Remarks'),
            cus_size_box().sizedBox_20,
            Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                  onPressed: () {
                    FocusScope.of(context).requestFocus(FocusNode());
                    controller.TextController.clear();
                    Navigator.pop(context);
                  },
                  text: 'Cancel',
                  backgroundColor: AppColors.lightorgeng,
                )),
                const SizedBox(
                  width: 20,
                ),
                Expanded(
                    child: cus_navigateBtn(
                  onPressed: () {
                    FocusScope.of(context).requestFocus(FocusNode());
                    controller.remarkSubmit(
                        index, controller.TextController.text);
                    Navigator.pop(context);
                  },
                  text: 'Submit',
                )),
              ],
            ),
            cus_size_box().sizedBox_10,
          ],
        ),
      ),
    );
  }

  ///table design
// Flexible(
//   child: controller.getGrnData.isNotEmpty?DataTable2(
//       columnSpacing: 0,
//       horizontalMargin: 20,
//       scrollController: controller.horizontalController,
//       isHorizontalScrollBarVisible: true,
//       isVerticalScrollBarVisible: true,
//       minWidth: 1000,
//       headingRowColor: MaterialStateProperty.all(AppColors.primaryColorBlue),
//       headingRowHeight: 30,
//       dataRowHeight: 55,
//       headingTextStyle: App_style().textS14MediumWhite,
//       dataTextStyle: App_style().textS14RegularBlue,
//       dataRowColor: MaterialStateProperty.all(Colors.white),
//       columns: const [
//         DataColumn2(
//           label: Text('Item Code'),
//           size: ColumnSize.S,
//         ),
//         DataColumn2(
//           label: Text('Item Name'),
//           size: ColumnSize.L,
//         ),
//         DataColumn2(
//           label: Text('Batch'),
//           size: ColumnSize.S,
//         ),
//         DataColumn2(
//           label: Text('Qty'),
//           size: ColumnSize.S,
//         ),
//         DataColumn2(
//           label: Text('Rate'),
//           size: ColumnSize.S,
//         ),
//         DataColumn2(
//           label: Text('Net Amt'),
//           size: ColumnSize.S,
//         ),
//         DataColumn2(
//           label: Text('Tol Amt'),
//           size: ColumnSize.S,
//         ),
//         DataColumn2(
//           label: Text('Remarks'),
//           size: ColumnSize.S,
//         ),
//       ],
//       rows:  List<DataRow>.generate(
//         controller.getGrnData.length,
//             (index) =>  DataRow(
//             cells: [
//               DataCell(Text(controller
//                   .getGrnData[index].materialNo
//                   .toString())),
//               DataCell(SizedBox(
//                 // width: MediaQuery.of(context).size.width/,
//                 child: Text(
//                   controller
//                       .getGrnData[index].materialName
//                       .toString(),
//                   maxLines: 2,
//                   overflow: TextOverflow.ellipsis,
//                 ),
//               )),
//               DataCell(Text(controller
//                   .getGrnData[index].batchNo
//                   .toString())),
//               DataCell(Text(controller
//                   .getGrnData[index].qtyInBox
//                   .toString())),
//               DataCell(Text(controller
//                   .getGrnData[index].batchRate
//                   .toString())),
//               DataCell(Text(controller
//                   .getGrnData[index].netAmt
//                   .toString())),
//               DataCell(Text(controller
//                   .getGrnData[index].totalAmt
//                   .toString())),
//               DataCell(SizedBox(
//                   height: 40,
//                   child: cus_navigateBtn(
//                     onPressed: () {
//                       ReviewShowDialog(
//                           context,
//                           controller
//                               .inputRemarks[index]);
//                     },
//                     text: 'Remarks',
//                   ))),
//             ]),
//       )):
//   const Center(child: Text("No Data Available")),
// ),
}
