import 'package:flutter/material.dart';
import 'package:pushcart/pages/page_route_name.dart';
import 'package:pushcart/utils/app_locale.dart';
import 'package:pushcart/utils/app_style.dart';
import 'package:pushcart/utils/custColors.dart';
import 'package:pushcart/widget/Scaffold_widget.dart';
import 'package:get/get.dart';
import '../../controller/Home_controller.dart';
import '../../widget/Date_Time/Date_time.dart';
import '../../widget/card/menuCard.dart';

class Home_screen extends GetView<HomeController> {
  const Home_screen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        body: SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                    child: menuCard(
                  image_path: AppImages.shopping_cart,
                  title_name: 'Purchase\n Order',
                  backgroundColor: AppColors.lightblue,
                  onTap: () {
                    Get.toNamed(route_purchase_order)?.then((value) => controller.getMypurchaseList(),);
                  },
                )),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                    child: menuCard(
                  image_path: AppImages.shopping_cart,
                      backgroundColor: AppColors.lightgreen,
                  title_name: 'GRN',
                  onTap: () { Get.toNamed(route_grn_screen);}
                )),
              ],
            ),
            cus_size_box().sizedBox_10,
            Row(
              children: [
                Expanded(
                    child: menuCard(
                  image_path: AppImages.salesOrder_img,
                      backgroundColor: AppColors.lightorgeng,
                  title_name: 'Sales Order',
                  onTap: () {
                    Get.toNamed(route_salesCustomer);
                  },
                )),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                    child: menuCard(
                  image_path: AppImages.attendance_icon,
                      backgroundColor: AppColors.lightgrey,
                  title_name: 'Attendance',
                  onTap: () {
                    Get.toNamed(route_attendance);

                  },
                )),
              ],
            ),
            cus_size_box().sizedBox_20,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Purchase Order',
                  style: App_style().textS16SemiboldBlue,
                ),
                InkWell(
                  onTap: (){
                    Get.toNamed(route_Mypurchase_order);
                  },
                  child: Text(
                    'See all',
                    style: App_style().textS14RegularOpacity,
                  ),
                )
              ],
            ),
            cus_size_box().sizedBox_5,
            GetBuilder(
              init: HomeController(),
              builder: (controller) {
                // if (controller.mypurchseList.isEmpty) {
                //   return const Center(child: CircularProgressIndicator());
                // }
                return ListView.builder(
                  itemCount: controller.Itemcount,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) => Column(
                    children: [
                      GestureDetector(
                        onTap: (){
                          Get.toNamed(route_MyPurchase_Details,arguments: [
                            controller.mypurchseList?[index].transactionNo,
                            controller.mypurchseList?[index].refOrderNo
                          ]);
                        },
                        child: Card(
                          surfaceTintColor: AppColors.whiteColor,
                          color: AppColors.whiteColor,
                          elevation: 2,
                          child: Padding(
                            padding: const EdgeInsets.all(10),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Row(
                                        children: [
                                          Text(
                                            'Order No: ',
                                            style: App_style()
                                                .textS14RegularOpacity,
                                          ),
                                          Text(
                                            controller
                                                .mypurchseList![index].transactionNo
                                                .toString(),
                                            style:
                                            App_style().textS14RegularBlue,
                                          ),

                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 10,),
                                    Text(
                                      Date_Time().DateTimeDD_MM_Y(
                                          controller.mypurchseList![index]
                                              .transactionDate
                                              .toString()),
                                      style:
                                      App_style().textS14RegularBlue,
                                    ),
                                  ],
                                ),
                                cus_size_box().sizedBox_5,
                                Row(
                                  children: [
                                    Text(
                                      'DMSOrderNo : ',
                                      style: App_style()
                                          .textS14RegularOpacity,
                                    ),
                                    Text(
                                      controller.mypurchseList![index].documentNo.toString(),
                                      style:
                                      App_style().textS14RegularBlue,
                                    ),
                                  ],
                                ),
                                cus_size_box().sizedBox_5,
                                Row(
                                  children: [
                                    Text(
                                      'Order Status : ',
                                      style: App_style().textS14RegularOpacity,
                                    ),
                                    Text(
                                      controller
                                          .mypurchseList![index]
                                          .orderStatusDescription
                                          .toString(),
                                      style: controller.StatusChange(controller
                                          .mypurchseList![index]
                                          .orderStatusFlag
                                          .toString()),
                                    ),
                                  ],
                                ),
                                Divider(
                                  color: AppColors.grey.shade300,
                                  thickness: 1,
                                ),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      '${Common_text.indiaCurrency} ${controller.mypurchseList?[index].netInvoiceAmt.toString()}',
                                      style:
                                      App_style().textS14RegularBlue,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      cus_size_box().sizedBox_3
                    ],
                  ),
                );
              }

            )
          ],
        ),
      ),
    ));
  }
}
