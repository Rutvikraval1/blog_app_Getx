
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../controller/MypurchaseOrderDetails.dart';
import '../../../utils/app_locale.dart';
import '../../../utils/app_style.dart';
import '../../../utils/custColors.dart';
import '../../../widget/Scaffold_widget.dart';
import '../../../widget/appbar_common.dart';
import '../../../widget/emptyScreen/ErrorScreen.dart';
import '../../../widget/emptyScreen/emptyScreen.dart';
import '../../../widget/input/SearchInput.dart';
import '../../../widget/loader/loader.dart';

class MypurchaseorderDetails extends GetView<MyPurchaseorderDetailsController> {
  const MypurchaseorderDetails({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold_widget(
        appBar: appbarCommon(
            title_text:'Ord NO : ${controller.orderId}',
            leading_ontap: () {
              Navigator.pop(context);
            }),
        body: controller.obx(
                (data) => Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SearchInput(
                    onChanged: (value) => controller.SearchFilter(value),
                    textcontroller: controller.SearchFilterText,
                    hintText: 'Search With Material Name / Code',
                  ),
                  cus_size_box().sizedBox_10,
                  Expanded(
                    child: ListView.builder(
                      itemCount: controller.resultList?.length,
                      shrinkWrap: true,
                      itemBuilder: (context, index) => Column(
                        children: [
                          Card(
                            surfaceTintColor: AppColors.whiteColor,
                            color: AppColors.whiteColor,
                            elevation: 2,
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        height: 50,
                                        width: 50,
                                        alignment: Alignment.center,
                                        child: Text('${index + 1}'),
                                      ),
                                      Expanded(
                                        child:
                                        Text.rich(
                                          TextSpan(
                                              text:
                                              controller.resultList?[index]
                                                  .materialName??'',
                                              style: App_style()
                                                  .textS16MediumPtc,
                                              children: <TextSpan>[
                                                TextSpan(
                                                    text:
                                                    ' (${controller.resultList?[index].materialCode ?? ''})',
                                                    style: App_style()
                                                        .textS16withOpacity),
                                              ]),
                                        ),
                                      )
                                    ],
                                  ),
                                  cus_size_box().sizedBox_5,
                                  Divider(
                                    color: AppColors.grey.shade300,
                                    thickness: 1,
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Text(
                                              'Rate : ',
                                              style: App_style()
                                                  .textS14RegularOpacity,
                                            ),
                                            Text(
                                              '${Common_text.indiaCurrency} ${controller.resultList?[index].rate.toString()}',
                                              style:
                                              App_style().textS14RegularBlue,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Text(
                                              'NetAmt : ',
                                              style: App_style()
                                                  .textS14RegularOpacity,
                                            ),
                                            Expanded(
                                              child: Text(
                                                '${Common_text.indiaCurrency} ${controller.resultList?[index].netAmt.toString()}',
                                                overflow: TextOverflow.ellipsis,maxLines: 1, style:
                                                App_style().textS14RegularBlue,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Text(
                                              'Qty (Box): ',
                                              style: App_style()
                                                  .textS14RegularOpacity,
                                            ),
                                            Text(
                                              controller.resultList![index].qty.toString(),
                                              style:
                                              App_style().textS14RegularBlue,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Text(
                                              'TotalTaxAmt : ',
                                              style: App_style()
                                                  .textS14RegularOpacity,
                                            ),
                                            Expanded(
                                              child: Text(
                                                '${Common_text.indiaCurrency} ${controller.resultList?[index].totalTaxAmt.toString()}',
                                                overflow: TextOverflow.ellipsis,maxLines: 1, style:
                                                App_style().textS14RegularBlue,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Text(
                                              'DiscAmt : ',
                                              style: App_style()
                                                  .textS14RegularOpacity,
                                            ),
                                            Text(
                                              '${Common_text.indiaCurrency} ${controller.resultList?[index].discAmt.toString()}',
                                              overflow: TextOverflow.ellipsis,maxLines: 1,  style:
                                              App_style().textS14RegularBlue,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Text(
                                              'Amount : ',
                                              style: App_style()
                                                  .textS14RegularOpacity,
                                            ),
                                            Expanded(
                                              child: Text(
                                                '${Common_text.indiaCurrency} ${controller.resultList?[index].amount.toString()}',
                                                overflow: TextOverflow.ellipsis,maxLines: 1, style:
                                                App_style().textS14RegularBlue,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          cus_size_box().sizedBox_3,
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
            onLoading: Center(child: Loader()),
            onEmpty: const Emptyscreen(),
            onError: (error) => Errorscreen(ErrorMessage: error.toString())));
  }


}