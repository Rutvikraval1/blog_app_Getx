import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pushcart/pages/page_route_name.dart';
import 'package:pushcart/widget/Scaffold_widget.dart';
import 'package:pushcart/widget/emptyScreen/emptyScreen.dart';

import '../../../controller/MyPurchaseorder_controller.dart';
import '../../../utils/app_locale.dart';
import '../../../utils/app_style.dart';
import '../../../utils/custColors.dart';
import '../../../widget/AlertDialog/Custom_AlertDialog.dart';
import '../../../widget/Date_Time/Date_time.dart';
import '../../../widget/Flutter_toast_mes.dart';
import '../../../widget/appbar_common.dart';
import '../../../widget/button/cus_navigateBtn.dart';
import '../../../widget/emptyScreen/ErrorScreen.dart';
import '../../../widget/input/CommonTextField.dart';
import '../../../widget/input/SearchInput.dart';
import '../../../widget/loader/alertBoxLoader.dart';
import '../../../widget/loader/loader.dart';

class Mypurchaseorder extends GetView<MyPurchaseorderController> {
  const Mypurchaseorder({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(
            title_text: 'My Purchase Order',
            leading_ontap: () {
              Navigator.pop(context);
            },
            filter_ontap: () {DateShowDialog(context);}),
        body: controller.obx(
            (data) => Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SearchInput(
                        onChanged: (value) => controller.SearchFilter(value),
                        textcontroller: controller.SearchFilterText,
                        hintText: 'Search With Order Id',
                      ),
                      cus_size_box().sizedBox_10,
                      controller.startDate.text!=''?Padding(
                        padding: const EdgeInsets.only(bottom: 5,left: 8,right: 8),
                        child: Row(
                          children: [
                            Expanded(child: Text('Date : ${controller.startDate.text} To  ${controller.toDate.text}')),
                            GestureDetector(
                              onTap: (){
                                LoaderAlert().ShowLoader(context: context);
                                controller.ReportDownLoad();
                              },
                              child: Row(
                                children: [
                                  Text("Report",style: App_style().textS14Medium_blueunderline,),
                                  const Icon(Icons.download,size: 20,color: AppColors.primaryColorBlue,)
                                ],
                              ),
                            )
                          ],
                        ),
                      ):const SizedBox(),
                      Expanded(
                        child: ListView.builder(
                          itemCount: controller.mypurchseList?.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index) => Column(
                            children: [
                              GestureDetector(
                                onTap: (){
                                  Get.toNamed(route_MyPurchase_Details,arguments: [
                                    controller.mypurchseList?[index].transactionNo,
                                    controller.mypurchseList?[index].refOrderNo
                                  ]);
                                }, child: Card(
                                  surfaceTintColor: AppColors.whiteColor,
                                  color: AppColors.whiteColor,
                                  elevation: 2,
                                  child: Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Row(
                                                children: [
                                                  Text(
                                                    'Order No: ',
                                                    style: App_style()
                                                        .textS14RegularOpacity,
                                                  ),
                                                  Text(
                                                    controller
                                                        .mypurchseList![index].transactionNo
                                                        .toString(),
                                                    maxLines: 2,
                                                    style:
                                                    App_style().textS14RegularBlue,
                                                  ),

                                                ],
                                              ),
                                            ),
                                            const SizedBox(width: 20,),
                                            Text(
                                              Date_Time().DateTimeDD_MM_Y(
                                                  controller.mypurchseList![index]
                                                      .transactionDate
                                                      .toString()),
                                              style:
                                                  App_style().textS14RegularBlue,
                                            ),
                                          ],
                                        ),
                                        cus_size_box().sizedBox_5,
                                        Row(
                                          children: [
                                            Text(
                                              'DMSOrderNo : ',
                                              style: App_style()
                                                  .textS14RegularOpacity,
                                            ),
                                            Text(
                                              controller.mypurchseList![index].documentNo.toString(),
                                              style:
                                              App_style().textS14RegularBlue,
                                            ),
                                          ],
                                        ),
                                        cus_size_box().sizedBox_5,
                                        Row(
                                          children: [
                                            Text(
                                              'Order Status : ',
                                              style: App_style().textS14RegularOpacity,
                                            ),
                                            Text(
                                              controller
                                                  .mypurchseList![index]
                                                  .orderStatusDescription
                                                  .toString(),
                                              style: controller.StatusChange(controller
                                                  .mypurchseList?[index]
                                                  .orderStatusFlag
                                                  .toString()),
                                            ),
                                          ],
                                        ),
                                        Divider(
                                          color: AppColors.grey.shade300,
                                          thickness: 1,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Text(
                                              '${Common_text.indiaCurrency} ${controller.mypurchseList?[index].netInvoiceAmt.toString()}',
                                              style:
                                                  App_style().textS14RegularBlue,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              cus_size_box().sizedBox_3,
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
            onLoading: Center(child: Loader()),
            onEmpty: const Emptyscreen(),
            onError: (error) => Errorscreen(ErrorMessage: error.toString())));
  }


  DateShowDialog(BuildContext context) {
    Custom_AlertDialog().AlertDialogBox(
      context: context,
      title: 'Filter',
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            cus_size_box().sizedBox_8,
            Text('Start Date', style: App_style().textS16withOpacity),
            cus_size_box().sizedBox_5,
            CustomInput(
                controller: controller.startDate,
                maxLines: 1,
                onTap: () async {
                  print("ssds");
                  controller.startDate.text=  (await  _showDatePicker(context))!;
                },
                hintText: 'Select Start Date'),
            cus_size_box().sizedBox_20,
            Text('To Date', style: App_style().textS16withOpacity),
            cus_size_box().sizedBox_5,
            CustomInput(
                controller: controller.toDate,
                maxLines: 1,
                onTap: () async {
                  if(controller.startDate.text!=''){
                    controller.toDate.text=  (await  _showDatePicker(context,ischeckStartDate: true))!;
                  }else{
                    Flutter_toast_mes().Error_Message('Please Select Start Date', error_code: true);
                  }

                },
                hintText: 'Select To Date'),
            cus_size_box().sizedBox_20,
            Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  text: 'Cancel',
                  backgroundColor: AppColors.lightorgeng,
                )),
                const SizedBox(
                  width: 20,
                ),
                Expanded(
                    child: cus_navigateBtn(
                  onPressed: () {
                    if(controller.startDate.text==''){
                      return Flutter_toast_mes().Error_Message('Please Select Start Date', error_code: true);
                    }else if(controller.toDate.text==''){
                      return Flutter_toast_mes().Error_Message('Please Select To Date', error_code: true);
                    }else{
                      Get.back();
                      controller.getMypurchaseList(
                        FromDate: controller.startDate.text,
                        ToDate:controller.toDate.text ,
                        isloader: true
                      );
                    }
                  },
                  text: 'Submit',
                )),
              ],
            ),
            cus_size_box().sizedBox_10,
          ],
        ),
      ),
    );
  }

  Future<String?> _showDatePicker(context,{bool ischeckStartDate=false}) async {
    DateTime? first_Date;
    if(ischeckStartDate){
      first_Date=controller.addDateTime(controller.startDate.text);
   }
    final Date = await showDatePicker(
      context: context,
      firstDate: first_Date??DateTime(2020),
      initialDate: DateTime.now(),
      lastDate: DateTime.now(),
      initialDatePickerMode: DatePickerMode.day,
    );
    if (Date != null) {
      String sDate = DateFormat('dd-MMM-yyyy').format(Date);
      return sDate;
    } else {
      return null;
    }
  }
}
