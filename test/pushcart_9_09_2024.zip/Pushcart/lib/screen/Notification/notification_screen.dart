

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controller/Notification_controller.dart';
import '../../widget/Scaffold_widget.dart';
import '../../widget/appbar_common.dart';


class NotificationScreen extends GetView<NotificationController> {
  const NotificationScreen({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
      appBar: appbarCommon(
          title_text: 'Notification',
          leading_ontap: () {
            Navigator.pop(context);
          },),
      body: const Padding(
        padding: EdgeInsets.all(8.0),
        child: Column(
          children: [],
        ),
      ),

    );
  }
}
