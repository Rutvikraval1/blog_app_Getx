
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pushcart/widget/Scaffold_widget.dart';
import '../../controller/attendance_controller.dart';
import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../utils/custColors.dart';
import '../../widget/AlertDialog/Custom_AlertDialog.dart';
import '../../widget/appbar_common.dart';
import '../../widget/button/cus_navigateBtn.dart';
import '../../widget/emptyScreen/ErrorScreen.dart';
import '../../widget/emptyScreen/emptyScreen.dart';
import '../../widget/input/SearchInput.dart';
import '../../widget/loader/alertBoxLoader.dart';
import '../../widget/loader/loader.dart';

class attendance_screen extends GetView<AttendanceController> {
  const attendance_screen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(
            title_text: 'Attendance',
            leading_ontap: () {
              Navigator.pop(context);
            },
            calender_ontap: () {
              _showDatePicker(context);
            }),
        body: controller.obx(
            (data) => Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    children: [
                      SearchInput(
                        onChanged: (value) => controller.SearchFilter(value),
                        textcontroller: controller.SearchFilterText,
                        hintText: 'Search With Customer Name',
                      ),
                      cus_size_box().sizedBox_10,
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Date : ${controller.SelectedDate}'),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              const Text('Check All'),
                              Checkbox(
                                  value: controller.CheckAll,
                                  onChanged: (value) {
                                    controller.CheckBoxAll(value);
                                  })
                            ],
                          ),
                        ],
                      ),
                      Expanded(
                        child: ListView.builder(
                          itemCount: controller.getAttandancedata?.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index) => Column(
                            children: [
                              ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: Text("${index + 1}",
                                    style: App_style().textS16MediumPtc),
                                title: Text(
                                    controller.getAttandancedata?[index]
                                            .custSupName ??
                                        '',
                                    style: App_style().textS16MediumPtc),
                                subtitle: Text(
                                    controller.getAttandancedata?[index]
                                            .custSupCode ??
                                        '',
                                    style: App_style().textS16withOpacity),
                                trailing: Checkbox(
                                    value: controller.AttandancecheckBox?[index],
                                    onChanged: (value) {
                                      controller.checkBoxValue(index, value);
                                    }),
                              ),
                              Divider(
                                color: AppColors.grey.shade300,
                                thickness: 1,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
            onLoading: Center(child: Loader()),
          onEmpty: const Emptyscreen(),
          onError: (error) =>  Errorscreen(ErrorMessage:error.toString(),),
        ),
        bottomNavigationBar: Container(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: BottomAppBar(
            elevation: 0,
            padding:
                const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
            color: Colors.transparent,
            child: Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                  onPressed: () async {
                    FocusScope.of(context).requestFocus(FocusNode());
                    LoaderAlert().ShowLoader(context: context);
                    bool isBool=await  controller.getMaxAttendaceDate(controller.SelectedDate);
                    if(isBool){
                      controller.SaveVendorAttandaceData();
                    }else {
                      Get.back();
                    }
                  },
                  text: 'Submit',
                )),
              ],
            ),
          ),
        ));
  }

  _showDatePicker(context) async {
    final Date = await showDatePicker(
      context: context,
      firstDate: DateTime.now().add(const Duration(days:-7)),
      initialDate: DateTime.now(),
      lastDate: DateTime.now(),
      initialDatePickerMode: DatePickerMode.day,
    );
    if (Date != null) {
      String sDate = DateFormat('dd-MM-yyyy').format(Date);
      bool istrue= await controller.getMaxAttendaceDate(sDate);
      if(istrue){
        HolidayShowDialog(context,sDate);
        return sDate;
      }
    } else {
      return null;
    }
  }

  HolidayShowDialog(BuildContext context,String Date) {
    Custom_AlertDialog().AlertDialogBox(
      context: context,
      title: 'Holiday!',
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            cus_size_box().sizedBox_8,
            Text('$Date is Holiday', style: App_style().textS16withOpacity),
            cus_size_box().sizedBox_5,
            cus_size_box().sizedBox_20,
            Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        Navigator.pop(context);
                        controller.DateChange(Date,false);
                      },
                      text: 'No',
                      backgroundColor: AppColors.lightorgeng,
                    )),
                const SizedBox(
                  width: 20,
                ),
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        Navigator.pop(context);
                        HolidayConfirmShowDialog(context,Date);

                      },
                      text: 'Yes',
                    )),
              ],
            ),
            cus_size_box().sizedBox_10,
          ],
        ),
      ),
    );
  }

  HolidayConfirmShowDialog(BuildContext context,String Date) {
    Custom_AlertDialog().AlertDialogBox(
      context: context,
      title: 'Confirm Holiday!',
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            cus_size_box().sizedBox_8,
            Text('Are you sure to Confirm Holiday?', style: App_style().textS16withOpacity),
            cus_size_box().sizedBox_5,
            cus_size_box().sizedBox_20,
            Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        Navigator.pop(context);
                        controller.DateChange(Date,false);
                      },
                      text: 'No',
                      backgroundColor: AppColors.lightorgeng,
                    )),
                const SizedBox(
                  width: 20,
                ),
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        Navigator.pop(context);
                        controller.DateChange(Date,true);
                        LoaderAlert().ShowLoader(context: context);
                        controller.SaveVendorAttandaceData(IsconfirmHoliday: true);
                      },
                      text: 'Yes',
                    )),
              ],
            ),
            cus_size_box().sizedBox_10,
          ],
        ),
      ),
    );
  }

}
