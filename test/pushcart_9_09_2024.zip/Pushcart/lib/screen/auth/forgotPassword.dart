



import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:pushcart/controller/forgotPassword_controller.dart';
import 'package:pushcart/widget/Scaffold_widget.dart';

import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../widget/Flutter_toast_mes.dart';
import '../../widget/button/cus_navigateBtn.dart';
import '../../widget/input/CommonTextField.dart';
import '../../widget/loader/alertBoxLoader.dart';

class ForgotPasswordscreen extends GetView<ForgotPasswordController> {
  const ForgotPasswordscreen({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold_widget(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              cus_size_box().sizedBox_30,
              Text(Common_text.forgot_Password, style: App_style().textS24SemiboldPtc),
              Text(Common_text.welcomeText2,
                  style: App_style().textS14SemiboldPtc),
              cus_size_box().sizedBox_30,
              CommonText_Title.textField_title(text: 'Username'),
              cus_size_box().sizedBox_10,
              CustomInput(
                  controller: controller.Username,
                  hintText: 'Username'),
              cus_size_box().sizedBox_30,
              CommonText_Title.textField_title(text: 'Old ${Common_text.password}'),
              cus_size_box().sizedBox_10,
              CustomInput(
                  controller: controller.Oldpassword,
                  hintText: '*********',
                  suffixIcon: true),
              cus_size_box().sizedBox_30,
              CommonText_Title.textField_title(text: 'New ${Common_text.password}'),
              cus_size_box().sizedBox_10,
              CustomInput(
                  controller: controller.NewPassword,
                  hintText: '*********',
                  suffixIcon: true),
              cus_size_box().sizedBox_30,
              CommonText_Title.textField_title(text: 'Confirm New ${Common_text.password}'),
              cus_size_box().sizedBox_10,
              CustomInput(
                  controller: controller.NewConfirmPassword,
                  hintText: '*********',
                  suffixIcon: true),
              cus_size_box().sizedBox_5,
            ],

          ),
        ),
      ),
        bottomNavigationBar: Container(
          padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: BottomAppBar(
            elevation: 0,
            padding:
            const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
            color: Colors.transparent,
            child: Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        FocusScope.of(context).requestFocus(FocusNode());
                        if (controller.Username.text == '') {
                          Flutter_toast_mes().Error_Message('Please enter username',
                              error_code: true);
                        } else if (controller.Oldpassword.text == '') {
                          Flutter_toast_mes().Error_Message('Please enter old password',
                              error_code: true);
                        }  else if (controller.NewPassword.text == '') {
                          Flutter_toast_mes().Error_Message('Please enter new password',
                              error_code: true);
                        } else if (controller.NewPassword.text.length<=5) {
                          Flutter_toast_mes().Error_Message('Please enter valid password',
                              error_code: true);
                        }
                        else if (controller.NewConfirmPassword.text == '') {
                          Flutter_toast_mes().Error_Message('Please enter confirm new password',
                              error_code: true);
                        } else if (controller.NewPassword.text != controller.NewConfirmPassword.text) {
                          Flutter_toast_mes().Error_Message('Passwords do NOT match.',
                              error_code: true);
                        } else {
                          LoaderAlert().ShowLoader(context: context);
                          controller.ForotPassword();
                        }
                      },
                      text: 'Submit',
                    )),
              ],
            ),
          ),
        )
    );
  }
}