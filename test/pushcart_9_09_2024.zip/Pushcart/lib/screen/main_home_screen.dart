import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pushcart/screen/profile/profile_screen.dart';
import 'package:pushcart/screen/report/reportScreen.dart';
import 'package:pushcart/utils/app_locale.dart';
import 'package:pushcart/utils/app_style.dart';
import 'package:pushcart/utils/custColors.dart';
import 'package:pushcart/widget/img_show/Image_show.dart';
import '../../widget/Scaffold_widget.dart';
import '../../widget/appbar_common.dart';
import '../pages/page_route_name.dart';
import '../service/app_permission.dart';
import '../service/pref_manager.dart';
import '../service/versionCode.dart';
import '../widget/AlertDialog/Custom_AlertDialog.dart';
import '../widget/Hocco_Support.dart';
import '../widget/button/cus_navigateBtn.dart';
import 'Home/home_screen.dart';

class Main_home_screen extends StatefulWidget {
  const Main_home_screen({super.key});

  @override
  State<Main_home_screen> createState() => _Main_home_screenState();
}

class _Main_home_screenState extends State<Main_home_screen> {
  int _currentIndex = 0;
  final List<Widget> _screens = [
    const Home_screen(),
    const Reportscreen(),
    const Profile_screen(),
  ];

  @override
  void initState() {
    // TODO: implement initState
    versionCodeName();
    super.initState();
  }

  final List<String> _screensName = [
    'Home',
    'Report',
    'My Profile',
  ];
  String version="";

  Future<void> versionCodeName() async {
    // versionCode
    version=await VersionCode().versionCodeName(isbuildNumber: false);
    AppPermission().requestInstallAPK();
    print("version");
    print(version);
    setState(() {});
    // var data= await Get_GPS_Location().determinePosition();
    // if(data!=null){
    //   var locationAddress=data['Address']??'';
    //   print("locationAddress");
    //   print(locationAddress);
    // }
  }
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        if (_currentIndex == 0) {
          return exit(0);
        } else {
          change_route(_currentIndex);
          return Future.value(false);
        }
      },
      child: Scaffold_widget(
          appBar: MainAppBar(
              title: _screensName[_currentIndex],
              menu_icon: 'true',
              noti_fun: () {Get.toNamed(route_notification);}),
          body: _screens[_currentIndex],
          drawer: drawerMenu(),
          bottomNavigationBar: _buildBottomBar(context)),
    );
  }

  void change_route(int value) {
    _currentIndex = 0;
    setState(() {});
  }

  Widget _buildBottomBar(BuildContext context) {
    return Container(
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(30), topLeft: Radius.circular(30)),
          boxShadow: [
            BoxShadow(color: Colors.black38, spreadRadius: 0, blurRadius: 10),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(30.0),
            topRight: Radius.circular(30.0),
          ),
          child: BottomNavigationBar(
            onTap: (value){
              _currentIndex = value;
              setState(() {});
            },
            currentIndex:_currentIndex,
            selectedLabelStyle: App_style().text13SemiboldPtc,
            selectedItemColor: AppColors.primaryColorBlue,
            unselectedItemColor:AppColors.primaryColorBlue.withOpacity(0.5) ,
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                  icon: Icon(Icons.home),
                  label: 'Home'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.document_scanner_outlined),
                  label: 'Report'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.person),
                  label: 'My Profile')
            ],
          ),
        ));

    //   CustomNavigationBar(
    //   selectedColor: AppColors.whiteColor_45,
    //   borderRadius:const BorderRadius.only(topLeft: Radius.circular(20),topRight: Radius.circular(20)),
    //   elevation: 0,
    //   backgroundColor: AppColors.whiteColor,
    //   onTap: (value) {
    //     setState(() {
    //       _currentIndex = value;
    //     });
    //   },
    //   unSelectedColor: AppColors.primaryColorBlue.withOpacity(0.6),
    //   currentIndex: _currentIndex,
    //   items: [
    //     CustomNavigationBarItem(
    //       title: Text("Home",style: App_style().textS14RegularOpacity,),
    //       icon: Image_show().Img_asset(AppImages.home_img),
    //       selectedIcon: Image_show().Img_asset(AppImages.home_img,color_code: AppColors.primaryColorBlue),
    //       selectedTitle: Text("Home",style: App_style().textS14RegularBlue,),
    //     ),
    //     CustomNavigationBarItem(
    //       title:  Text("Report",style: App_style().textS14RegularOpacity,),
    //         icon: Image_show().Img_asset(AppImages.report_img,color_code: AppColors.primaryColorBlue.withOpacity(0.6)),
    //         selectedIcon: Image_show().Img_asset(AppImages.report_img,color_code: AppColors.primaryColorBlue),
    //     selectedTitle: Text("Report",style: App_style().textS14RegularBlue,),
    //     ),
    //     CustomNavigationBarItem(
    //       title:  Text("My Profile",style: App_style().textS14RegularOpacity,),
    //         icon: Image_show().Img_asset(AppImages.profile_img,color_code: AppColors.primaryColorBlue.withOpacity(0.6)),
    //         selectedIcon: Image_show().Img_asset(AppImages.profile_img,color_code: AppColors.primaryTextColor),
    //       selectedTitle: Text("My Profile",style: App_style().textS14RegularBlue,),
    //     ),
    //   ],
    // );
  }

  Widget drawerMenu() {

    return Drawer(
      surfaceTintColor: AppColors.whiteColor,
      backgroundColor: AppColors.whiteColor,
      elevation: 1,
      child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              color: AppColors.primaryColorBlue.withOpacity(0.9),
              child: Column(
                children: [
                  cus_size_box().sizedBox_20,
                  CircleAvatar(
                    backgroundColor: Colors.grey.shade200,
                    backgroundImage: const AssetImage(AppImages.Userprofile_img),
                    radius: 50,
                  ),
                  cus_size_box().sizedBox_10,
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Text(
                      textAlign: TextAlign.center,
                      Preferences.getStringValuesSF(Preferences.plantName),
                      // 'Rutvik Raval',
                      style: App_style().textS16MediumWhite,
                    ),
                  ),
                  cus_size_box().sizedBox_8,
                  Text(
                    Preferences.getStringValuesSF(Preferences.userName),
                    // '+234 84 7227 4922',
                    style: App_style().textS16MediumWhite,
                  ),
                  cus_size_box().sizedBox_10,
                ],
              ),
            ),
            Column(
              children: [
                cus_size_box().sizedBox_10,
                //Dashboard
                AccountButton(
                  onTap: () {
                    Get.back();
                    _currentIndex = 0;
                    setState(() {});
                  },
                  icon: AppImages.home_img,
                  text: 'Dashboard',
                ),
                //My Profile
                AccountButton(
                  onTap: () {
                    Get.back();
                    _currentIndex = 2;
                    setState(() {});
                  },
                  icon: AppImages.profile_img,
                  text: 'My Profile',
                ),
                AccountButton(
                  onTap: () {
                    Get.back();
                    Get.toNamed(route_purchase_order);
                  },
                  icon: AppImages.shopping_cart,
                  text: 'Purchase Order',
                ),
                AccountButton(
                  onTap: () {
                    Get.back();
                    Get.toNamed(route_grn_screen);
                  },
                  icon: AppImages.shopping_cart,
                  text: 'GRN',
                ),
                AccountButton(
                  onTap: () {
                    Get.back();
                    Get.toNamed(route_salesCustomer);
                  },
                  icon: AppImages.salesOrder_img,
                  text: 'Sales Order',
                ),
                AccountButton(
                  onTap: () {
                    Get.back();
                    Get.toNamed(route_attendance);
                  },
                  icon: AppImages.attendance_icon,
                  text: 'Attendance',
                ),
                //Report
                AccountButton(
                  onTap: () {
                    Get.back();
                    _currentIndex = 1;
                    setState(() {});
                  },
                  icon: AppImages.report_img,
                  text: 'Report',
                ),
                AccountButton(
                  onTap: () {
                    Get.back();
                    LogoutShowDialog(context);
                  },
                  icon: AppImages.logout_icon,
                  ImgType: 'Svg',
                  text: 'Logout',
                ),
                cus_size_box().sizedBox_5,
                const Divider(
                  thickness: 0.3,
                ),


                const Hocco_Support(isShowColumn: true,),
                cus_size_box().sizedBox_10,
                if(version!='')
                  Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(text: "App Version Name: ",style: App_style().textS14Regulargrey,),
                      TextSpan(
                        text: version,style: App_style().textS14MediumBlue,
                        // style: TextStyle(fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
                cus_size_box().sizedBox_10,
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget AccountButton(
      {required String text, required Function onTap, required String icon,String ImgType='' }) {
    return ListTile(
      onTap: () {
        onTap();
      },
      visualDensity: const VisualDensity(vertical: -2),
      leading:ImgType==''? Image_show().Img_asset(icon, width: 24, height: 24): Image_show().SvgPicture_asset(icon, width: 24, height: 24),
      title: Text(
        text,
        style: App_style().textS14MediumPriTextColor,
      ),
      trailing: const SizedBox(
          width: 30, child: Icon(Icons.arrow_forward_ios, size: 18)),
    );
  }

  LogoutShowDialog(BuildContext context) {
    Custom_AlertDialog().AlertDialogBox(
      context: context,
      title: 'Logout',
      content: SingleChildScrollView(
        child: Column(
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            cus_size_box().sizedBox_20,
            Text("Are you sure to logout?",style: App_style().textS14Regularblack,),
            cus_size_box().sizedBox_30,
            Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        Get.back();
                      },
                      text: 'Close',
                      backgroundColor: AppColors.lightorgeng,
                    )),
                const SizedBox(
                  width: 20,
                ),
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        Get.back();
                        Preferences.clearAllValuesSF();
                        Get.toNamed(route_loginScreen);
                      },
                      text: 'Ok',
                    )),
              ],
            ),
            cus_size_box().sizedBox_10,
          ],
        ),
      ),
    );
  }
}
