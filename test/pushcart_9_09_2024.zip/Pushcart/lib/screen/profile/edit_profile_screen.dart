
import 'package:flutter/material.dart';
import 'package:pushcart/widget/img_show/Image_show.dart';
import '../../utils/app_locale.dart';
import '../../widget/Scaffold_widget.dart';
import '../../widget/appbar_common.dart';
import '../../widget/button/cus_navigateBtn.dart';
import '../../widget/input/CommonTextField.dart';

class EditProfile_screen extends StatefulWidget {
  const EditProfile_screen({super.key});

  @override
  State<EditProfile_screen> createState() => _EditProfile_screenState();
}

class _EditProfile_screenState extends State<EditProfile_screen> {
  TextEditingController FName=TextEditingController();
  TextEditingController LName=TextEditingController();
  TextEditingController MobileNo=TextEditingController();
  TextEditingController Email=TextEditingController();
  TextEditingController companyName=TextEditingController();
  TextEditingController noOfEmp=TextEditingController();
  TextEditingController companyAddress=TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(title_text: 'Edit Profile',leading_ontap: () {
          Navigator.pop(context);
        }),
        body: SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.grey.shade200,
                    backgroundImage:const AssetImage(AppImages.dummyimg),
                    radius: 70,
                  ),
                  Positioned(
                      bottom: 5,
                      right: 5,
                      child: Image_show().SvgPicture_asset(AppImages.camare_icon))
                ],
              ),
            ),
            cus_size_box().sizedBox_10,
            CommonText_Title.textField_title(text: 'First name*'),
            cus_size_box().sizedBox_10,
            CustomInput(controller: FName,hintText: 'Enter your first name'),
            cus_size_box().sizedBox_20,
            CommonText_Title.textField_title(text: 'Last name*'),
            cus_size_box().sizedBox_10,
            CustomInput(controller: LName,hintText: 'Enter your last name'),
            cus_size_box().sizedBox_20,
            CommonText_Title.textField_title(text: 'Mobile Number*'),
            cus_size_box().sizedBox_10,
            CustomInput(controller: MobileNo,hintText: 'Enter your mobile number'),
            cus_size_box().sizedBox_20,
            CommonText_Title.textField_title(text: 'Email*'),
            cus_size_box().sizedBox_10,
            CustomInput(controller: Email,hintText: 'Enter your email'),
          ],
        ),
      ),
    ),
        bottomNavigationBar: Container(
          padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: BottomAppBar(
            elevation: 0,
            padding:
            const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
            color: Colors.transparent,
            child: Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        FocusScope.of(context).requestFocus(FocusNode());
                        print('submit');
                      },
                      text: 'Save',
                    )),
              ],
            ),
          ),
        )
    );
  }
}
