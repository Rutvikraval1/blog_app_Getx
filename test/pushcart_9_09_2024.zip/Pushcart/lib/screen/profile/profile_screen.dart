import 'package:flutter/material.dart';
import 'package:pushcart/pages/page_route_name.dart';
import 'package:pushcart/widget/img_show/Image_show.dart';
import '../../controller/Profile_controller.dart';
import '../../service/pref_manager.dart';
import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../utils/custColors.dart';
import '../../widget/AlertDialog/Custom_AlertDialog.dart';
import '../../widget/Hocco_Support.dart';
import '../../widget/Scaffold_widget.dart';
import '../../widget/button/cus_navigateBtn.dart';
import 'package:get/get.dart';

class Profile_screen extends GetView<ProfileController>{
  const Profile_screen({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                cus_size_box().sizedBox_15,
                Center(
                  child: Column(
                    children: [
                      Stack(
                        alignment: Alignment.center,
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.grey.shade200,
                            backgroundImage: const AssetImage(AppImages.Userprofile_img),
                            radius: 70,
                          ),
                          // Positioned(
                          //     bottom: 5,
                          //     right: 5,
                          //     child: Image_show()
                          //         .SvgPicture_asset(AppImages.edit_icon))
                        ],
                      ),
                      cus_size_box().sizedBox_10,
                      Text(
                        Preferences.getStringValuesSF(Preferences.plantName),
                        style: App_style().textS16BoldPtc,
                      ),
                      cus_size_box().sizedBox_10,
                      Text(
                        Preferences.getStringValuesSF(Preferences.userName),
                        style: App_style().textS14SemiboldPtc,
                      ),
                      cus_size_box().sizedBox_10,

                    ],
                  ),
                ),
                const Divider(
                  thickness: 0.3,
                ),
                AccountButton(
                  onTap: () {
                    Get.toNamed(route_changePassword);
                  },
                  icon: AppImages.profile_icon,
                  text: 'Change Password',
                ),
                AccountButton(
                  onTap: () {
                    Get.toNamed(route_notification);
                  },
                  icon: AppImages.notifi_icon,
                  text: 'Notification',
                ),
                const Divider(
                  thickness: 0.3,
                ),
                AccountButton(
                  onTap: () {
                    LogoutShowDialog(context);
                  },
                  icon: AppImages.logout_icon,
                  text: 'Logout',
                ),
                const Divider(
                  thickness: 0.3,
                ),
                cus_size_box().sizedBox_10,
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(text: "App Version Name : ",style: App_style().textS14Regulargrey,),
                      TextSpan(
                        text: Preferences.getStringValuesSF(Preferences.versionCode),style: App_style().textS14MediumBlue,
                        // style: TextStyle(fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
                cus_size_box().sizedBox_10,
                const Hocco_Support(),
              ],
            ),
          ),
        ));
  }

  Widget AccountButton({
    required String text,
    required Function onTap,
    required String icon}){
    return ListTile(
      onTap: (){
        onTap();
      },
      visualDensity: const VisualDensity(vertical: -3),
      leading: Image_show().SvgPicture_asset(icon, width: 24, height: 24),
      title: Text(
        text,
        style: App_style().textS14MediumPriTextColor,
      ),

      trailing:const SizedBox(
          width: 30,
          child: Icon(Icons.arrow_forward_ios, size: 18)),
    );
  }

  LogoutShowDialog(BuildContext context) {
    Custom_AlertDialog().AlertDialogBox(
      context: context,
      title: 'Logout',
      content: SingleChildScrollView(
        child: Column(
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            cus_size_box().sizedBox_20,
            Text("Are you sure to logout?",style: App_style().textS14Regularblack,),
            cus_size_box().sizedBox_30,
            Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        Get.back();
                      },
                      text: 'Close',
                      backgroundColor: AppColors.lightorgeng,
                    )),
                const SizedBox(
                  width: 20,
                ),
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        Get.back();
                        Preferences.clearAllValuesSF();
                        Get.toNamed(route_loginScreen);
                      },
                      text: 'Ok',
                    )),
              ],
            ),
            cus_size_box().sizedBox_10,
          ],
        ),
      ),
    );
  }

}
