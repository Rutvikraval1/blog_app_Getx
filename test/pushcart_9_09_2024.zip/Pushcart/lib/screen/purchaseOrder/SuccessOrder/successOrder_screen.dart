import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pushcart/utils/app_locale.dart';
import 'package:pushcart/utils/app_style.dart';
import 'package:pushcart/widget/Scaffold_widget.dart';
import 'package:pushcart/widget/img_show/Image_show.dart';

import '../../../controller/cartCounter.dart';
import '../../../utils/custColors.dart';
import '../../../widget/Date_Time/Date_time.dart';
import '../../../widget/button/cus_navigateBtn.dart';

class SuccessorderScreen extends StatefulWidget {
  final String OrderNo;
  final String TotalPaymnet;
  final String? customerName;
  final String? customerCode;
  const SuccessorderScreen(
      {super.key,
      this.customerName,
      this.customerCode,
      required this.OrderNo,
      required this.TotalPaymnet});

  @override
  State<SuccessorderScreen> createState() => _SuccessorderScreenState();
}

class _SuccessorderScreenState extends State<SuccessorderScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => Future.value(false),
      child: Scaffold_widget(
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Expanded(
                  child: ListView(
                children: [
                  cus_size_box().sizedBox_20,
                  SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height / 2.5,
                    child: Image_show()
                        .Img_asset(AppImages.successOrder),
                  ),
                  // cus_size_box().sizedBox_5,
                  Text(
                    widget.customerName == null
                        ? "Purchase Order Saved Successfully!"
                        : 'Sales Order Saved Successfully!',
                    textAlign: TextAlign.center,
                    style: App_style().textS24SemiboldPtc,
                  ),
                  cus_size_box().sizedBox_5,
                  Card(
                    surfaceTintColor: AppColors.whiteColor,
                    color: AppColors.whiteColor,
                    elevation: 1,
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        children: [
                          if (widget.customerName != null)
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Vendor Name\n(code)',
                                  style: App_style().textS14RegularOpacity,
                                ),
                                Text(
                                  '${widget.customerName}\n(${widget.customerCode})',
                                  style: App_style().textS14Regularblack,
                                )
                              ],
                            ),
                          if (widget.customerName != null)
                            cus_size_box().sizedBox_8,
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Order Date',
                                style: App_style().textS14RegularOpacity,
                              ),
                              Text(
                                Date_Time().ShowDateTime().toString(),
                                style: App_style().textS14Regularblack,
                              )
                            ],
                          ),
                          const Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Order Number ',
                                style: App_style().textS14RegularOpacity,
                              ),
                              Text(
                                widget.OrderNo,
                                style: App_style().textS14Regularblack,
                                maxLines: 1,
                              )
                            ],
                          ),
                          const Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Total Payment',
                                style: App_style().textS14RegularOpacity,
                              ),
                              Text(
                                '${Common_text.indiaCurrency} ${widget.TotalPaymnet}',
                                style: App_style().textS14Regularblack,
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              )),
              Column(
                children: [
                  GetBuilder<CartCounter>(
                    init: CartCounter(),
                    builder: (controllerValue) => Row(
                      children: [
                        Expanded(
                            child: cus_navigateBtn(
                          onPressed: () {
                            FocusScope.of(context).requestFocus(FocusNode());
                            controllerValue.TotalCart();
                            Get.back();
                          },
                          text: 'Continue Shopping',
                        )),
                      ],
                    ),
                  ),
                  cus_size_box().sizedBox_10,
                  InkWell(
                      onTap: () {
                        Get.back();
                        Get.back();
                      },
                      child: Text(
                        'Back To Home',
                        style: App_style().textS16MediumPtc,
                      )),
                  cus_size_box().sizedBox_10,
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
