import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pushcart/pages/page_route_name.dart';
import 'package:pushcart/widget/Scaffold_widget.dart';

import '../../controller/PurchaseOrder_controller.dart';
import '../../controller/cartCounter.dart';
import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../utils/custColors.dart';
import '../../widget/Flutter_toast_mes.dart';
import '../../widget/appbar_common.dart';
import '../../widget/button/cus_navigateBtn.dart';
import '../../widget/emptyScreen/ErrorScreen.dart';
import '../../widget/emptyScreen/emptyScreen.dart';
import '../../widget/input/CommonTextField.dart';
import '../../widget/input/SearchInput.dart';
import '../../widget/loader/loader.dart';

class PurchaseOrder extends GetView<PurchaseorderController> {
  const PurchaseOrder({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(
            title_text: 'Purchase Order',
            leading_ontap: () {
              Navigator.pop(context);
            },
            cart_ontap: () {
              Get.toNamed(route_cart_screen)?.then((value) => controller.getpurchaseList(isloader: true),);
            }),
        body: controller.obx((data) => Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SearchInput(
                    onChanged: (value) => controller.SearchFilter(value),
                    textcontroller: controller.SearchFilterText,
                    hintText: 'Search With Material Name / Code',
                  ),
                  cus_size_box().sizedBox_10,
                  SizedBox(
                    height:40,
                    child: ListView.builder(
                      itemCount: controller.materialCategoryNo?.length,
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) => Row(
                        children: [
                          InkWell(
                            onTap: (){
                              controller.CategoryOnTap(controller.materialCategoryNo?[index]);
                            },
                            child: Card(
                              surfaceTintColor: AppColors.whiteColor,
                              color: controller.materialCategoryNo?[index]!=controller.seleted_cate_id?AppColors.primaryColorBlue.withOpacity(0.4):AppColors.whiteColor,
                              elevation: 1,
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                                child: Text(controller.materialCategoryName?[index],style: controller.materialCategoryNo?[index]!=controller.seleted_cate_id? App_style().textS14RegularwhiteColor:App_style().textS14RegularBlue,),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  cus_size_box().sizedBox_5,
                  Expanded(
                    child: ListView.builder(
                      itemCount: controller.materialMst?.length,
                      shrinkWrap: true,
                      itemBuilder: (context, index) => Column(
                        children: [
                          Card(
                            surfaceTintColor: AppColors.whiteColor,
                            color: AppColors.whiteColor,
                            elevation: 2,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        height: 50,
                                        width: 50,
                                        alignment: Alignment.center,
                                        child: Text('${index + 1}'),
                                      ),
                                      Expanded(
                                          child:
                                          Text.rich(
                                            TextSpan(
                                                text:
                                                controller.materialMst?[index]
                                                            .materialName??'',
                                                style: App_style()
                                                    .textS16MediumPtc,
                                                children: <TextSpan>[
                                                  TextSpan(
                                                      text:
                                                      ' (${controller.materialMst?[index].materialCode ?? ''})',
                                                      style: App_style()
                                                          .textS16withOpacity),
                                                ]),
                                          ),
                                      )
                                    ],
                                  ),
                                  Divider(
                                    color: AppColors.grey.shade300,
                                    thickness: 1,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            'Rate : ',
                                            style: App_style()
                                                .textS14RegularOpacity,
                                          ),
                                          Text(
                                            '${Common_text.indiaCurrency} ${controller.materialMst?[index].rate.toString()}',
                                            style:
                                                App_style().textS14RegularBlue,
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          SizedBox(
                                            width:MediaQuery.of(context).size.width/3.7,
                                            height: 40,
                                            child: CustomInput(
                                                controller:
                                                    controller.inputText![index],
                                                digitsOnlyNo: 4,
                                                hintStyle: true,
                                                hintText: 'QTY(BOX)'),
                                          ),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          GetBuilder<CartCounter>(
                                            init: CartCounter(),
                                            builder: (controllerValue) =>
                                                SizedBox(
                                                    width: MediaQuery.of(context).size.width/4.5,
                                                    height: 40,
                                                    child: cus_navigateBtn(
                                                      onPressed: () async {
                                                        FocusScope.of(context)
                                                            .requestFocus(
                                                                FocusNode());
                                                        if (controller
                                                                .inputText?[
                                                                    index]
                                                                .text ==
                                                            '') {
                                                          return Flutter_toast_mes()
                                                              .Error_Message(
                                                                  "Please Add Qty");
                                                        } else {
                                                          bool data = await controller
                                                              .checklocalDb(
                                                                  materialNo: controller
                                                                      .materialMst![
                                                                          index]
                                                                      .materialNo
                                                                      .toString());
                                                          print('step 1');
                                                          print(data);
                                                          controller
                                                              .addChart(
                                                                  materialCategoryName: controller
                                                                      .materialMst![
                                                                          index]
                                                                      .materialCategoryName
                                                                      .toString(),
                                                                  materialCategoryNo:
                                                                      controller.materialMst![index].materialCategoryNo
                                                                          .toString(),
                                                                  materialCode: controller
                                                                      .materialMst![
                                                                          index]
                                                                      .materialCode
                                                                      .toString(),
                                                                  materialName: controller
                                                                      .materialMst![
                                                                          index]
                                                                      .materialName
                                                                      .toString(),
                                                                  materialNo: controller
                                                                      .materialMst![
                                                                          index]
                                                                      .materialNo
                                                                      .toString(),
                                                                  mrp: controller
                                                                      .materialMst![index]
                                                                      .mrp
                                                                      .toString(),
                                                                  rate: controller.materialMst![index].rate.toString(),
                                                                  stateWiseTaxPerc: controller.materialMst![index].stateWiseTaxPerc.toString(),
                                                                  taxAmount: controller.materialMst![index].taxAmount.toString(),
                                                                  Qty: controller.inputText![index].text)
                                                              .then(
                                                            (value) {
                                                              if (!data) {
                                                                print('step 2');
                                                                controllerValue
                                                                    .TotalCart();
                                                              }
                                                            },
                                                          );
                                                        }
                                                      },
                                                      text: 'ADD',
                                                    )),
                                          )
                                        ],
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ),
                          cus_size_box().sizedBox_3
                        ],
                      ),
                    ),
                  )
                ],
              ),
            )
            ,onLoading: Center(child:  Loader()),
            onEmpty: const Emptyscreen(),
            onError: (error) =>  Errorscreen(ErrorMessage:error.toString())
        ));
  }
}
