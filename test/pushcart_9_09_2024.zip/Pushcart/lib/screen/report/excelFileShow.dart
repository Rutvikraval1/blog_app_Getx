//
//
//
// import 'package:flutter/material.dart';
// import 'package:pushcart/widget/Scaffold_widget.dart';
// import '../../widget/appbar_common.dart';
//
// class excelFileShow extends StatefulWidget {
//   const excelFileShow({super.key});
//
//   @override
//   State<excelFileShow> createState() => _excelFileShowState();
// }
//
// class _excelFileShowState extends State<excelFileShow> {
//   bool _isConverting = false;
//   @override
//   void initState() {
//     loadExcelfile();
//     super.initState();
//   }
//
//   Future<void> loadExcelfile() async {
//     // setState(() {
//     //   _isConverting = true;
//     // });
//
//     String link = "https://hoccocoretest-pharmanet.ssplbusiness.com/Report_Files/GRNDump_20240122_20250125_20240723_114601.xlsx";
//     // try {
//     //   // Make HTTP GET request to download Excel file
//     //   var response = await http.get(Uri.parse(link));
//     //
//     //   // Check if request was successful
//     //   if (response.statusCode == 200) {
//     //
//     //
//     //
//     //     // // Load Excel file
//     //     // var excel = Excel.decodeBytes(response.bodyBytes);
//     //     //
//     //     // // Initialize PDF document
//     //     // final pdf = pw.Document();
//     //     //
//     //     // // Iterate through sheets
//     //     // for (var table in excel.tables.keys) {
//     //     //   // Generate PDF content for each sheet
//     //     //   pdf.addPage(pw.Page(
//     //     //     build: (pw.Context context) {
//     //     //       return pw.Table(
//     //     //         // Table body
//     //     //         children: [
//     //     //           for (var row in excel.tables[table]!.rows)
//     //     //             pw.TableRow(
//     //     //               // Table rows
//     //     //               children: [
//     //     //                 for (var cell in row) pw.Text(cell!.value.toString()),
//     //     //               ],
//     //     //             ),
//     //     //         ],
//     //     //       );
//     //     //     },
//     //     //   ));
//     //     // }
//     //
//     //   } else {
//     //     throw Exception('Failed to load Excel file: ${response.statusCode}');
//     //   }
//     // } catch (e) {
//     //   print('Error converting Excel to PDF: $e');
//     // } finally {
//     //   setState(() {
//     //     _isConverting = false;
//     //   });
//     // }
//
//     // OpenFile.open(link);
//
//   }
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold_widget(
//         appBar: appbarCommon(
//             title_text: 'My GRN Report',
//             leading_ontap: () {
//               Navigator.pop(context);
//             },
//             filter_ontap: () {}),
//         body: Column(
//       children: [
//       ],
//     ));
//   }
// }
