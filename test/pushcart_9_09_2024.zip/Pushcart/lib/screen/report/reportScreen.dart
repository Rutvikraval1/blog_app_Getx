
import 'package:flutter/material.dart';
import 'package:flutter_bounceable/flutter_bounceable.dart';
import 'package:get/get.dart';
import 'package:pushcart/utils/app_locale.dart';
import 'package:pushcart/utils/app_style.dart';
import 'package:pushcart/widget/Scaffold_widget.dart';

import '../../pages/page_route_name.dart';
import '../../utils/custColors.dart';

class Reportscreen extends StatefulWidget {
  const Reportscreen({super.key});

  @override
  State<Reportscreen> createState() => _ReportscreenState();
}

class _ReportscreenState extends State<Reportscreen> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        body: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 8),
          child: Column(
                children: [
                  CusContainer(
                    title: "My Purchase Order",
                    colorCode: Colors.lightBlueAccent.shade100,
                    OnTap: (){
                      Get.toNamed(route_Mypurchase_order);
                    }
                  ),
                  cus_size_box().sizedBox_5,
                  CusContainer(
                      title: "My GRN Order",
                      colorCode:Colors.white30,
                      OnTap: (){
                        Get.toNamed(route_MyGRN_order);
                      }
                  ),
                  cus_size_box().sizedBox_5,
                  CusContainer(
                      title: "My Sales Order",
                      colorCode:Colors.blueGrey.shade100,
                      OnTap: (){
                        Get.toNamed(route_MySalesorder);
                      }
                  ),

                  // CusContainer(
                  //     title: "My Sales report",
                  //     colorCode:Colors.blueGrey.shade100,
                  //     OnTap: (){
                  //      Navigator.push(context, MaterialPageRoute(builder: (context) => const excelFileShow(),));
                  //     }
                  // ),

                ],
              ),
        ));
  }

  Widget CusContainer({required String title,required VoidCallback OnTap,Color? colorCode}){
    return Bounceable(
      onTap:OnTap,
      child: Card(
        surfaceTintColor: colorCode??AppColors.whiteColor,
        color: colorCode??AppColors.whiteColor,
        elevation: 2,
        child: ListTile(
          title: Text(title,style: App_style().textS16MediumPtc,),
          trailing: const Icon(Icons.arrow_forward_ios_rounded),
        ),
      ),
    );
  }
}
