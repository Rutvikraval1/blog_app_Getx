
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../controller/SalesCart_controller.dart';
import '../../../controller/cartCounter.dart';
import '../../../utils/app_locale.dart';
import '../../../utils/app_style.dart';
import '../../../utils/custColors.dart';
import '../../../widget/AlertDialog/Custom_AlertDialog.dart';
import '../../../widget/Flutter_toast_mes.dart';
import '../../../widget/Scaffold_widget.dart';
import '../../../widget/appbar_common.dart';
import '../../../widget/button/cus_navigateBtn.dart';
import '../../../widget/emptyScreen/emptyScreen.dart';
import '../../../widget/input/CommonTextField.dart';
import '../../../widget/loader/alertBoxLoader.dart';
import '../../../widget/loader/loader.dart';

class SalesCart_screen extends GetView<SalesCartController> {
  const SalesCart_screen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(
          title_text: 'Sales Order Cart',
          leading_ontap: () {
            Navigator.pop(context);
          },
        ),
        body: controller.obx((data) => Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: controller.lst?.length,
                  shrinkWrap: true,
                  itemBuilder: (context, index) => Column(
                    children: [
                    Card(
                    surfaceTintColor: AppColors.whiteColor,
                    color: AppColors.whiteColor,
                    elevation: 0.5,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                height: 50,
                                width: 50,
                                alignment: Alignment.center,
                                child: Text('${index + 1}'),
                              ),
                              Expanded(
                                  child:
                                  Text.rich(
                                    TextSpan(
                                        text:  controller.lst?[index]
                                        ['materialName'] ??
                                            '',
                                        style: App_style()
                                            .textS16MediumPtc,
                                        children: <TextSpan>[
                                          TextSpan(
                                              text:
                                              '(${controller.lst?[index]['materialCode']}) (${controller.lst?[index]['BatchNo']})',
                                              style: App_style()
                                                  .textS16withOpacity),
                                        ]),
                                  )),
                              InkWell(
                                onTap: (){
                                  DeleteShowDialog(context,controller.lst![index]['materialNo'].toString());
                                },
                                child: const Icon(
                                  Icons.delete_forever,
                                  color: AppColors.red,
                                  size: 30,
                                ),
                              )
                            ],
                          ),
                          Divider(
                            color: AppColors.grey.shade300,
                            thickness: 1,
                          ),
                          Row(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        'Stock(PCS) : ',
                                        style: App_style()
                                            .textS14RegularOpacity,
                                      ),
                                      Text(
                                        controller.lst![index]['stock'].toString(),
                                        style: App_style()
                                            .textS14RegularBlue,
                                      ),
                                    ],
                                  ),
                                  cus_size_box().sizedBox_3,
                                  Row(
                                    children: [
                                      Text(
                                        'Rate : ',
                                        style: App_style()
                                            .textS14RegularOpacity,
                                      ),
                                      Text(
                                        '${Common_text.indiaCurrency} ${controller.lst?[index]['rate'].toString()}',
                                        style: App_style()
                                            .textS14RegularBlue,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  SizedBox(
                                    width: MediaQuery.of(context).size.width/3.7,
                                    height: 40,
                                    child: CustomInput(
                                        controller: controller
                                            .inputText![index],
                                        digitsOnlyNo: 4,
                                        hintStyle: true,
                                        hintText: 'QTY(PCS)'),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  SizedBox(
                                      width: MediaQuery.of(context).size.width/4.5,
                                      height: 40,
                                      child: cus_navigateBtn(
                                        onPressed: () async {
                                          FocusScope.of(context)
                                              .requestFocus(
                                              FocusNode());
                                          if (controller
                                              .inputText?[index]
                                              .text ==
                                              '') {
                                            return Flutter_toast_mes()
                                                .Error_Message(
                                                "Please Add Qty");
                                          } else {
                                            controller.salesCartUpdateQty(
                                                Qty: controller
                                                    .inputText![
                                                index]
                                                    .text,
                                                materialNo: controller
                                                    .lst![index][
                                                'materialNo']
                                                    .toString(),context: context);
                                          }
                                        },
                                        text: 'Update',
                                      )),
                                ],
                              ),
                            ],
                          ),
                          cus_size_box().sizedBox_3,
                          Row(
                            children: [
                              Text(
                                'View  : ',
                                style: App_style()
                                    .textS14RegularOpacity,
                              ),
                              Text(
                                '${Common_text.indiaCurrency} ${controller.lst?[index]['rate'].toString()} '
                                    '* ${controller.inputText?[index].text}'
                                    ' = ${controller.particular_Total_rate(cur_rate: controller.lst![index]['rate'].toString(), totalQty: controller.inputText![index].text)}',
                                style:
                                App_style().textS14RegularBlue,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                      cus_size_box().sizedBox_3,
                    ],
                  ),
                ),
              ),
              cus_size_box().sizedBox_10,
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Net Amount',
                          style: App_style().textS14RegularOpacity,
                        ),
                        Text(
                          '${Common_text.indiaCurrency} ${controller.NetAmt.toStringAsFixed(2)}',
                          style: App_style().textS16MediumPtc,
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Total Tax(CGST)',
                          style: App_style().textS14RegularOpacity,
                        ),
                        Text(
                          '${Common_text.indiaCurrency} ${controller.CGST_Tax.toStringAsFixed(2)}',
                          style: App_style().textS16MediumPtc,
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Total Tax(SGST)',
                          style: App_style().textS14RegularOpacity,
                        ),
                        Text(
                          '${Common_text.indiaCurrency} ${controller.SGST_Tax.toStringAsFixed(2)}',
                          style: App_style().textS16MediumPtc,
                        ),
                      ],
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Round off',
                          style: App_style().textS14RegularOpacity,
                        ),
                        Text(
                          '${Common_text.indiaCurrency} ${controller.totalamtRoundOff.toStringAsFixed(2)}',
                          style: App_style().textS16MediumPtc,
                        ),
                      ],
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Total Amount',
                          style: App_style().textS16MediumPtc,
                        ),
                        Text(
                          '${Common_text.indiaCurrency} ${controller.totalamount.round()}',
                          style: App_style().textS16MediumPtc,
                        ),
                      ],
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
            onLoading:Center(child:  Loader()),
          onEmpty: const Emptyscreen(cartimgPath: AppImages.emptyCart,),
        ),
        bottomNavigationBar:Container(
          padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: BottomAppBar(
            elevation: 0,
            padding:
            const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
            color: Colors.transparent,
            child: Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        FocusScope.of(context).requestFocus(FocusNode());
                        if(controller.CGST_Tax==0||controller.SGST_Tax==0){
                          Flutter_toast_mes().Error_Message("Please after try again");
                        }else{
                          LoaderAlert().ShowLoader(context: context);
                          controller.SalesCartSubmitData(context);
                        }

                      },
                      text: 'Submit Order',
                    )),
              ],
            ),
          ),
        ));
  }

  DeleteShowDialog(BuildContext context,String materialNo) {
    Custom_AlertDialog().AlertDialogBox(
      context: context,
      title: 'Delete!',
      content: SingleChildScrollView(
        child: Column(
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            cus_size_box().sizedBox_20,
            Text("Are you sure to delete?",style: App_style().textS14Regularblack,),
            cus_size_box().sizedBox_30,
            Row(
              children: [
                Expanded(
                    child: cus_navigateBtn(
                      onPressed: () {
                        Get.back();
                      },
                      text: 'No',
                      backgroundColor: AppColors.lightorgeng,
                    )),
                const SizedBox(
                  width: 20,
                ),
                GetBuilder<SalesCartCounter>(
                  init: SalesCartCounter(CustId: controller.custId),
                  builder: (controllerValue) =>
                      Expanded(
                          child: cus_navigateBtn(
                            onPressed: () {
                              Get.back();controller
                                  .deleteCartValue(
                                  materialNo: materialNo,context: context)
                                  .then(
                                    (value) {
                                  controller.SalesTotalCart(isloader: true, context: context);
                                  controllerValue.TotalCart(controller.custId);
                                },
                              );
                            },
                            text: 'Yes',
                          )),
                ),
              ],
            ),
            cus_size_box().sizedBox_10,
          ],
        ),
      ),
    );
  }
}