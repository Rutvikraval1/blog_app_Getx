


import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pushcart/pages/page_route_name.dart';
import 'package:pushcart/widget/Scaffold_widget.dart';
import '../../controller/SalesCustomer_controller.dart';
import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../utils/custColors.dart';
import '../../widget/appbar_common.dart';
import '../../widget/emptyScreen/ErrorScreen.dart';
import '../../widget/emptyScreen/emptyScreen.dart';
import '../../widget/input/SearchInput.dart';
import '../../widget/loader/loader.dart';


class SalesCustomerScreen extends GetView<SalesCustomerController> {
  const SalesCustomerScreen({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        appBar: appbarCommon(
            title_text: 'Sales Order',
            leading_ontap: () {
              Navigator.pop(context);
            },
        ),
        body:  controller.obx(
              (data) =>  Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                SearchInput(
                  onChanged: (value) => controller.SearchFilter(value),
                  textcontroller: controller.SearchFilterText,
                  hintText: 'Search With Customer Name',
                ),
                cus_size_box().sizedBox_10,
                Expanded(
                  child: ListView.builder(
                    itemCount: controller.getCustomerdata?.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index) => Column(
                      children: [
                        InkWell(
                          onTap: (){
                            Get.toNamed(route_sales_order,arguments: [
                              controller.getCustomerdata?[index].custSupName.toString(),
                              controller.getCustomerdata?[index].custSupNo.toString(),
                              controller.getCustomerdata?[index].divisionNo.toString(),
                              controller.getCustomerdata?[index].billto.toString(),
                              controller.getCustomerdata?[index].shipto.toString(),
                              controller.getCustomerdata?[index].custSupTypeNo.toString(),
                              controller.getCustomerdata?[index].custSupCode.toString(),
                            ]);
                          },
                          child: Card(
                            surfaceTintColor: AppColors.whiteColor,
                            color: AppColors.whiteColor,
                            elevation: 2,
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        height: 25,
                                        width: 30,
                                        alignment: Alignment.center,
                                        child: Text('${index+1}'),
                                      ),
                                      const SizedBox(width: 10,),
                                      Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                  controller.getCustomerdata?[index].custSupName??'',
                                                  style:
                                                  App_style().textS16MediumPtc),
                                              Text(
                                                  '(${controller.getCustomerdata?[index].custSupCode??''})',
                                                  style: App_style().textS16withOpacity),
                                            ],
                                          ))
                                    ],
                                  ),
                                  // Divider(
                                  //   color: AppColors.grey.shade300,
                                  //   thickness: 1,
                                  // ),
                                  // Row(
                                  //   children: [
                                  //     Text(
                                  //       'LOD :  ',
                                  //       style: App_style()
                                  //           .textS14RegularOpacity,
                                  //     ),
                                  //     Text(
                                  //       Date_Time().ShowDateTime().toString(),
                                  //       style:
                                  //       App_style().textS14RegularBlue,
                                  //     ),
                                  //   ],
                                  // ),
                                  // Row(
                                  //   children: [
                                  //     Text(
                                  //       'LOD :  ',
                                  //       style: App_style()
                                  //           .textS14RegularOpacity,
                                  //     ),
                                  //     Text(
                                  //       '0',
                                  //       style:
                                  //       App_style().textS14RegularBlue,
                                  //     ),
                                  //   ],
                                  // ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        cus_size_box().sizedBox_3
                      ],
                    ),
                  ),
                ),


              ],
            ),
          ),
                onLoading: Center(child: Loader()),
          onEmpty: const Emptyscreen(),
    onError: (error) =>  Errorscreen(ErrorMessage:error.toString()),
        ));
  }

  void SearchFilter(String value) {

  }
}
