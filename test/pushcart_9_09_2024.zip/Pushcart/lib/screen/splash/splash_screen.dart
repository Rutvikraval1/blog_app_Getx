

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pushcart/pages/page_route_name.dart';
import 'package:pushcart/widget/img_show/Image_show.dart';
import '../../service/pref_manager.dart';
import '../../utils/app_locale.dart';
import '../../widget/Scaffold_widget.dart';

class splash_screen extends StatefulWidget {
  const splash_screen({super.key});

  @override
  State<splash_screen> createState() => _splash_screenState();
}

class _splash_screenState extends State<splash_screen> {


  @override
  void initState() {
    Preferences.init();
    startTimer();
    super.initState();
  }
  startTimer() async {
    var duration = const Duration(seconds: 5);
    return Timer(duration, route);
  }
  route() {
    if(Preferences.getBoolValuesSF(Preferences.user_active)==null){
      Get.offNamed(route_loginScreen);
    }else{
      Get.offNamed(route_main_dashboard);

    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
      body: Center(
        child: Image_show().SvgPicture_asset(AppImages.app_logo),
      ),
    );
  }
}
