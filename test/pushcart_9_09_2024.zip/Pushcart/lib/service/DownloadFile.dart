//
// import 'dart:io';
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/foundation.dart';
// import 'package:get/get.dart';
// import 'package:open_file/open_file.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:permission_handler/permission_handler.dart';
//
// import '../widget/loader/alertBoxLoader.dart';
//
//
// class DownloadFile{
//   HttpClient httpClient =  HttpClient();
//   Future<String> downloadFile(String url, String fileName) async {
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       LoaderAlert().ShowLoader();
//     });
//     File file;
//     String filePath = '';
//     try {
//       print("url");
//       print(url);
//       var request = await httpClient.getUrl(Uri.parse(url));
//       var response = await request.close();
//       if(response.statusCode == 200) {
//         Directory? externalDir = await getExternalStorageDirectory();
//         if (externalDir == null) {
//           throw Exception("External storage directory not found");
//         }
//         File destinationFile = File('${externalDir.path}/$fileName');
//         // String dir = (await getDownloadsDirectory())!.path;
//         var bytes = await consolidateHttpClientResponseBytes(response);
//         // filePath = '$dir/$fileName';
//         // print("filePath");
//         // print(filePath);
//         // file = File(filePath);
//         await destinationFile.writeAsBytes(bytes);
//         destinationFile.open();
//         Get.back();
//         print("destinationFile.path");
//         print(destinationFile.path);
//         final result = await  OpenFile.open(destinationFile.path);
//         print('result');
//         print(result.message);
//         print(result.type);
//
//
//
//       }
//       else {
//         filePath = 'Error code: ${response.statusCode}';
//         Get.back();
//       }
//     }
//     catch(ex){
//
//       filePath = 'Can not fetch url';
//       Get.back();
//     }
//     return filePath;
//   }
//
// }