import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';

import '../widget/Flutter_toast_mes.dart';

class Get_GPS_Location {
  LocationPermission? permission;
  Position? position;
  String long = "";
  String lat = "";
  String address = "";

  Future determinePosition() async {
    bool serviceEnabled;
    bool locationSettings;
    print("step 1");

    // Check if location services are enabled
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    print("step 2");
    print(serviceEnabled);

    if (!serviceEnabled) {
      print("step 3");
       Flutter_toast_mes().Error_Message('Location services are disabled.');
      return null;
    }

    // Check location permission status
    permission = await Geolocator.checkPermission();
    print("step 4");
    print(permission);

    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      print("step 5");
      // Request location permission
      permission = await Geolocator.requestPermission();
      print("step 6");
      print(permission);

      if (permission == LocationPermission.always ||
          permission == LocationPermission.whileInUse) {
        // Permission granted, fetch location
        return await _getCurrentLocation();
      } else if (permission == LocationPermission.denied) {
        // User denied permission
        Flutter_toast_mes().Error_Message('Location permission denied. Please grant permission.');
        await Geolocator.openAppSettings();
        permission = await Geolocator.requestPermission();
         return null;
      } else if (permission == LocationPermission.deniedForever) {
        // User denied permission forever
        Flutter_toast_mes().Error_Message('Location permission permanently denied. Please enable it in settings.');
        await Geolocator.openAppSettings();
        permission = await Geolocator.requestPermission();
        return null;
      }
    } else {
      // Permission already granted, fetch location
      return await _getCurrentLocation();
    }
  }

  Future<Map<String, String>?> _getCurrentLocation() async {
    try {
      position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.low);
      long = position!.longitude.toString();
      lat = position!.latitude.toString();
      address = await _getAddressFromLatLong(position!);
      return {
        'lat': lat,
        'long': long,
        'address': address,
      };
    } catch (e) {
      print("Error fetching location: $e");
       Flutter_toast_mes().Error_Message('Error fetching location.');
      return null;
    }
  }

  Future<String> _getAddressFromLatLong(Position position) async {
    print("step 17");
    print(position);
    try {
      List<Placemark> placemarks =
      await placemarkFromCoordinates(position.latitude, position.longitude, localeIdentifier: 'en');
      Placemark place = placemarks[0];
      address = '${place.street ?? ''}, ${place.subLocality ?? ''}, ${place.isoCountryCode ?? ''}, ${place.locality ?? ''}, ${place.postalCode ?? ''}, ${place.country ?? ''}';
      print("step 18");
      print(address);
      return address;
    } catch (e) {
      print("Error fetching address: $e");
      return 'Address not found.';
    }
  }
}
