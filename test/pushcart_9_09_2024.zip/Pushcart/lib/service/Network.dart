
import 'dart:convert';
import "package:http/http.dart" as http;

import '../localDB/DatabaseHelper.dart';
import '../utils/app_locale.dart';
import '../widget/Date_Time/Date_time.dart';
class Network {
  // STAG SERVER Call API
  // static const String base_url = "https://hoccocoretest-pharmanet.ssplbusiness.com";
 // LIVE SERVER Call API
  static const String base_url = "https://hoccocore-pharmanet.ssplbusiness.com";

  static const String api_verison = "api/MobileCOMS";
  Map<String, String> requestHeader = {
    'CallType': "-999",
    'User-Agent': 'ms web api client protocol',
    'sAuthenticationHeader': '1/18sRDra84/WYqZzPHX8JIz1gN0BHOFc2Id9InSmO+bxKfuHsMSV6s0Dz94pLEwBOh/ORGm2jN5HQpR+mpLUNcfWNXnP4Ykqmz1ZdnD1gU=',
    "content-type": "application/json",
    "UserID": "1",
    "Profile": "1",
    "TIMEZONENO": "1",
  };

  Future<String> postMethodCall({required Map params, required String page_name}) async {
    // bool isOnline = await ClsCommon.isConnected();
    bool isOnline = true;
    if (isOnline) {
      Uri _uri=Uri.parse("$base_url/$api_verison/$page_name");
      print(_uri);
      print('params');
      print(jsonEncode(params));
      final response = await http.post(_uri,
        headers: requestHeader,
        body: jsonEncode(params),
      );
      print("statusCode");
      print(response.statusCode);
      var tempDataResponse=jsonDecode(response.body);
      print("tempData");
      print(tempDataResponse);
      String jsonParams = jsonEncode(params);
      String jsonDataResponse = jsonEncode(tempDataResponse);
      if (tempDataResponse['responseCode'] == Common_text.RESPONSE_OK) {
        addLocalDbLogAPI(
            methodName: page_name,
          parameter: jsonParams,
          response: jsonDataResponse,
        );
      }else{
        addLocalDbLogAPI(
            methodName: page_name,
            parameter: jsonParams,
            response: jsonDataResponse,
            isError: true
        );
      }
      return response.body;

    }
    // else {
    //   Fluttertoast.showToast(msg: "Please Connect Internet");
    //   throw Exception('Please Connect Internet');
    // }
  }

  Future<String> getMethodCall({var params,required String pageName}) async {
    bool isOnline = true;
    // bool isOnline = await ClsCommon.isConnected();
    if (isOnline) {
      var URL = Uri.parse('$base_url/$api_verison/$pageName');
      URL = URL.replace(queryParameters: params);
      print("From Req*******");
      print(URL);
      final response = await http.get(URL, headers: requestHeader);
      print(response.statusCode);
      var tempDataResponse=jsonDecode(response.body);
      String jsonParams = jsonEncode(params);
      String jsonDataResponse = jsonEncode(tempDataResponse);
      if (tempDataResponse['responseCode'] == Common_text.RESPONSE_OK) {
          addLocalDbLogAPI(
            methodName: pageName,
            parameter: jsonParams,
            response: jsonDataResponse,
            isError: tempDataResponse['message'] == "Fail"
          );
      }else{
        addLocalDbLogAPI(
            methodName: pageName,
            parameter: jsonParams,
            response: jsonDataResponse,
            isError: true
        );
      }
      return response.body;
    }
    // else {
    //   Fluttertoast.showToast(msg: "Please Connect Internet");
    //   throw Exception('Please Connect Internet');
    // }
  }



  Future<void> addLocalDbLogAPI({
    required String methodName,
    required  String parameter,
    required String response,
    bool isError=false}) async {
    String currentTime=Date_Time().TimeCurrent();
    String currentDate=Date_Time().DateTimeCurrent();

    // Insert row
    final data = await DBHelper().insertLogAPI({
      DBHelper.log_MethodName: methodName,
      DBHelper.log_Parameter: parameter,
      DBHelper.log_Response: response,
      DBHelper.log_Time: currentTime,
      DBHelper.log_Date: currentDate,
      DBHelper.log_IsError: isError,
    });

    if (data != '') {
      print("Successfully added local database");
    } else {
      print("Please try again");
    }
  }

}
