
import 'package:permission_handler/permission_handler.dart';

import 'Get_GPS_Location.dart';

class AppPermission{

  Future requestInstallAPK() async {

    bool ismanageExternalS= await Permission.manageExternalStorage.isGranted;
    print("ismanageExternalS");
    print(ismanageExternalS);
    if(!ismanageExternalS){
      await Permission.manageExternalStorage.request();
    }
    bool isrequestInstall=await Permission.requestInstallPackages.isGranted;
    print("isrequestInstall");
    print(isrequestInstall);
    if(!isrequestInstall){
      await Permission.requestInstallPackages.request();
    }
    await Get_GPS_Location().determinePosition();

  }

}