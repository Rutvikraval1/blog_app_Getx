
import 'dart:convert';

import '../../model/AttendanceModel.dart';
import '../../model/GrnModel.dart';
import '../../model/GrnOrderDetailsModel.dart';
import '../../model/MyGRNOrderModel.dart';
import '../../model/MyPurchaseOrdersModel.dart';
import '../../model/MySalesOrderModel.dart';
import '../../model/PurchaseOrderDetailsModel.dart';
import '../../model/PurchaseOrderModel.dart';
import '../../model/SalesOrderDetailsModel.dart';
import '../../model/SalesOrderModel.dart';
import '../../model/loginModel.dart';
import '../Network.dart';

class Provider{
  Future<LoginModel> getLoginDetails({String username='',String password=''}) async {
    try {
      Map mapdata = {
        "username": username,
        "password": password
      };
      final response = await Network().postMethodCall(params: mapdata, page_name: 'GetLogin');
      return loginModelFromJson(response);
    }catch(e){
      print(e.toString());
      return loginModelFromJson('');
    }
  }

  Future<PurchaseOrderModel> getPurchaseOrderList(Map mapdata) async {
    try {

      final response = await Network().getMethodCall(params: mapdata,pageName: 'COMSFillMaterial');
      return purchaseOrderModelFromJson(response);
    }catch(e){
      print(e.toString());
      return purchaseOrderModelFromJson('');
    }
  }

  Future<MyPurchaseOrdersModel> getMyPurchaseOrderList(Map mapdata) async {
    try {
      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetMyPurchaseOrders');
      return myPurchaseOrdersModelFromJson(response);
    }catch(e){
      print(e.toString());
      return myPurchaseOrdersModelFromJson('');
    }
  }
  Future<MyGoodsReceiptNotesModel> GetMyGoodsReceiptNotesList(Map mapdata) async {
    try {

      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetMyGoodsReceiptNotes');
      return myGENModelFromJson(response);
    }catch(e){
      print(e.toString());
      return myGENModelFromJson('');
    }
  }

  Future<MySalesModel> GetMySalesOrdersList(Map mapdata) async {
    try {
      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetMySalesOrders');
      return mySalesodelFromJson(response);
    }catch(e){
      print(e.toString());
      return mySalesodelFromJson('');
    }
  }
  Future<dynamic> GetAppVersionMst(Map mapdata) async {
    try {
      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetAppVersionMst');
      return jsonDecode(response);
    }catch(e){
      print(e.toString());
      return null;
    }
  }

  Future<dynamic> GetAllReportDownload({required Map mapdata,String pageName=''}) async {
    try {
      final response = await Network().getMethodCall(params: mapdata,pageName: pageName);
      return jsonDecode(response);
    }catch(e){
      print(e.toString());
      return null;
    }
  }

  Future<PurchaseOrderDetailsModel> getMyPurchaseDetailsOrderList(Map mapdata) async {
    try {
      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetViewPurchaseOrderDetails');
      return purchaseOrderDetailsModelFromJson(response);
    }catch(e){
      print(e.toString());
      return purchaseOrderDetailsModelFromJson('');
    }
  }

  Future<GrnOrderDetailsModel> getMyGrnDetailsOrderList(Map mapdata) async {
    try {
      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetViewGRNDetails');
      return grnOrderDetailsModelFromJson(response);
    }catch(e){
      print(e.toString());
      return grnOrderDetailsModelFromJson('');
    }
  }

  Future<SalesOrderDetailsModel> getMySalesDetailsOrderList(Map mapdata) async {
    try {
      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetViewSalesOrderDetails');
      return salesOrderDetailsModelFromJson(response);
    }catch(e){
      print(e.toString());
      return salesOrderDetailsModelFromJson('');
    }
  }




  Future<SalesOrderModel> getSalesOrderList(Map mapdata) async {
    try {

      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetMaterialForSalesOrder');
      return salesOrderModelFromJson(response);
    }catch(e){
      print(e.toString());
      return salesOrderModelFromJson('');
    }
  }

  Future<dynamic> ForotPassword(Map mapdata) async {
    try {
      final response = await Network().postMethodCall(params: mapdata,page_name: 'ChangePassword');
      return jsonDecode(response);
    }catch(e){
      print(e);
      return '';
    }
  }

  Future<dynamic> changePassword(Map mapdata) async {
    try {
      final response = await Network().postMethodCall(params: mapdata,page_name: 'ChangePassword');
      return jsonDecode(response);
    }catch(e){
      print(e);
      return '';
    }
  }


  Future<dynamic> addCartData(Map mapdata) async {
    try {
      final response = await Network().postMethodCall(params: mapdata,page_name: 'COMSSaveMSellData');
      return jsonDecode(response);
    }catch(e){
      print(e);
      return '';
    }
  }


  Future<dynamic> addSalesCartData(Map mapdata) async {
    try {
      final response = await Network().postMethodCall(params: mapdata,page_name: 'SaveSalesOrder');
      return jsonDecode(response);
    }catch(e){
      print("Error Show");
      print(e);
      return '';
    }
  }

  Future<dynamic> GetTaxDetails(Map mapdata) async {
    try {
      final response = await Network().postMethodCall(params: mapdata,page_name: 'COMSGetTaxDetails');
      return jsonDecode(response);
    }catch(e){
      print(e.toString());
      return '';
    }
  }


  Future<GrnModel> getGRNList(Map mapdata) async {
    try {

      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetCOMSGRN');
      return grnModelFromJson(response);
    }catch(e){
      print(e.toString());
      return grnModelFromJson('');
    }
  }

  Future<dynamic> SaveGRNData(Map mapdata) async {
    try {
      final response = await Network().postMethodCall(params: mapdata,page_name: 'SaveGRN');
      return jsonDecode(response);
    }catch(e){
      print(e.toString());
      return '';
    }
  }

  //Attendance
  Future<AttandanceModel> getAttendanceList(Map mapdata) async {
    try {

      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetVendorAttandance');
      return attandanceModelFromJson(response);
    }catch(e){
      print(e.toString());
      return attandanceModelFromJson('');
    }
  }

  //Attendance
  Future<dynamic> GetMaxAttendaceDate(Map mapdata) async {
    try {

      final response = await Network().getMethodCall(params: mapdata,pageName: 'GetMaxAttendaceDate');
      return jsonDecode(response);
    }catch(e){
      print(e.toString());
      return '';
    }
  }

  Future<dynamic> SaveVendorAttandaceData(Map mapdata) async {
    try {
      final response = await Network().postMethodCall(params: mapdata,page_name: 'SaveVendorAttandace');
      return jsonDecode(response);
    }catch(e){
      print(e.toString());
      return '';
    }
  }
}