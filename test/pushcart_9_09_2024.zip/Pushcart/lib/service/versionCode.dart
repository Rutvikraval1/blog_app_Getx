



import 'package:package_info_plus/package_info_plus.dart';
import 'package:pushcart/service/pref_manager.dart';

class VersionCode{
  Future<dynamic> versionCodeName({bool isbuildNumber=true}) async {
    try{
      PackageInfo packageInfo = await PackageInfo.fromPlatform();
      // String appName = packageInfo.appName;
      // String packageName = packageInfo.packageName;
      String version = packageInfo.version;
      String buildNumber = packageInfo.buildNumber;
      print("version");
      print(version);
      print("buildNumber");
      print(buildNumber);
      Preferences.addDataToSF(Preferences.versionCode, version.toString());
      Preferences.addDataToSF(Preferences.BuildNumber, buildNumber.toString());
      if(isbuildNumber){
        return buildNumber;
      }else{
        return version;
      }

    }catch(e){
      print("sdsd");
      print(e);
    }
  }
}