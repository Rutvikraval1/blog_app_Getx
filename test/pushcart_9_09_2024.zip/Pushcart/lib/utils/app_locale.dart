
import 'package:flutter/material.dart';
import 'app_style.dart';

class AppImages {
  //Svg image
  static const String app_logo = 'assets/svg/logo-white.svg';
  static const String back_arrow = 'assets/svg/back_arrow.svg';
  static const String eye_icon = 'assets/svg/eye.svg';
  static const String menu_icon = 'assets/svg/menu_icon.svg';
  static const String notification_icon = 'assets/svg/notification_icon.svg';
  static const String edit_icon = 'assets/svg/edit_icon.svg';
  static const String camare_icon = 'assets/svg/camare_icon.svg';
  static const String lang_icon = 'assets/svg/lang_icon.svg';
  static const String logout_icon = 'assets/svg/logout_icon.svg';
  static const String notifi_icon = 'assets/svg/notifi_icon.svg';
  static const String policy_icon = 'assets/svg/policy_icon.svg';
  static const String profile_icon = 'assets/svg/profile_icon.svg';


  //Png image
  static const String dummyimg = 'assets/png/dummyimg.png';
  static const String emptyCart = 'assets/png/emptyCart.png';
  static const String Userprofile_img = 'assets/png/profile.png';
  static const String chat_img = 'assets/png/chat_img.png';
  static const String home_img = 'assets/png/home_img.png';
  static const String order_img = 'assets/png/order_img.png';
  static const String profile_img = 'assets/png/profile_img.png';
  static const String shopping_cart = 'assets/png/shopping_cart.png';
  static const String attendance_icon = 'assets/png/attendance_icon.png';
  static const String filter_icon = 'assets/png/filter_icon.png';
  static const String calendar_icon = 'assets/png/calendar.png';
  static const String cart_icon = 'assets/png/cart_icon.png';
  static const String report_img = 'assets/png/report_img.png';
  static const String salesOrder_img = 'assets/png/salesOrder.png';
  static const String successOrder = 'assets/png/successOrder.png';
  static const String empt_icon = 'assets/png/empt_icon.png';
  static const String error_icon = 'assets/png/error_icon.png';


}

class Common_text{
  static const String PushCart='PushCart';
  static const String APK='APK';
  static const String PushCartAPK='PushCart.apk';
  static const String Report_FilesFolder='Report_Files';
  static const String login='Login';
  static const String forgot_Password='Forgot Password';
  static const String createAC='Create an account';
  static const String welcomeText='Welcome back! Please enter your details.';
  static const String welcomeText2='Welcome! Please enter your details.';
  static const String email='Email';
  static const String password='Password';
  static const String forgetPassword='Forgot password?';
  static const String fullName='Full Name';



  //JSON RESPONSECODE
  static String RESPONSE_OK = "OK";
  static String indiaCurrency = "\u{20B9}";
  static String GrnCode = "ZGRN";
  static String SalesOrderCode = "ZOD1";
  static int SalesOrdermode = 1;
  static String GrnCodeRemark = "SAPDC";
  static List TotalGST_CUT=['C_Gst','S_Gst'];
}

class font_name {
  static const String Poppins_Bold = 'Poppins_Bold';
  static const String Poppins_Medium = 'Poppins_Medium';
  static const String Poppins_Regular = 'Poppins_Regular';
  static const String Poppins_SemiBold = 'Poppins_SemiBold';
}




class Tost_meassage{
  static const String connectInternet='Please connect internet!';
  static const String tryAgain='Please try again';

}

class cus_size_box{
  SizedBox sizedBox_3= const SizedBox(height: 3);
  SizedBox sizedBox_5= const SizedBox(height: 5);
  SizedBox sizedBox_8= const SizedBox(height: 8);
  SizedBox sizedBox_10= const SizedBox(height: 10);
  SizedBox sizedBox_15= const SizedBox(height: 15);
  SizedBox sizedBox_20= const SizedBox(height: 20);
  SizedBox sizedBox_25= const SizedBox(height: 25);
  SizedBox sizedBox_30= const SizedBox(height: 30);
  SizedBox sizedBox_50= const SizedBox(height: 50);
}

class CommonText_Title {
  static Widget textField_title({
    required String text,
  }) => Text(text,style: App_style().textS16MediumPtc);
}


