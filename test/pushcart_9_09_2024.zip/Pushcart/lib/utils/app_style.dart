
import 'package:flutter/material.dart';

import 'app_locale.dart';
import 'custColors.dart';

class App_style{
  TextStyle textS16SemiboldPtc= const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 16,
    fontFamily: font_name.Poppins_SemiBold
  );
  TextStyle textS16SemiboldwhiteColor= const TextStyle(
      color: AppColors.whiteColor,
      fontSize: 16,
      fontFamily: font_name.Poppins_SemiBold
  );

  TextStyle textS16MediumPtc = const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 16,
      fontFamily: font_name.Poppins_Medium
  );
  TextStyle textS16BoldPtc = const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 16,
      fontFamily: font_name.Poppins_Bold
  );
  TextStyle textS24SemiboldPtc = const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 24,
      fontFamily: font_name.Poppins_SemiBold
  );
  TextStyle textS24SemiboldPtcwhiteColor = const TextStyle(
      color: AppColors.whiteColor,
      fontSize: 24,
      fontFamily: font_name.Poppins_SemiBold
  );
  TextStyle textS24boldPtcwhiteColor = const TextStyle(
      color: AppColors.whiteColor,
      fontSize: 24,
      fontFamily: font_name.Poppins_Bold
  );
  TextStyle textS14SemiboldPtc =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.6),
      fontSize: 14,
      fontFamily: font_name.Poppins_SemiBold
  );

  TextStyle text14SemiboldPtc =  TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 14,
      fontFamily: font_name.Poppins_SemiBold
  );

  TextStyle text13SemiboldPtc =  TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 13,
      fontFamily: font_name.Poppins_SemiBold
  );

  TextStyle textS16SemiboldwithOpacity =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.6),
      fontSize: 16,
      fontFamily: font_name.Poppins_SemiBold
  );
  TextStyle textS16withOpacity =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.4),
      fontSize: 16,
      fontFamily: font_name.Poppins_Regular
  );

  TextStyle textS16Medium_blue =  const TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 16,
    decoration: TextDecoration.underline,
      fontFamily: font_name.Poppins_Medium
  );
  TextStyle textS14Medium_blueunderline =  const TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 14,
      decoration: TextDecoration.underline,
      fontFamily: font_name.Poppins_Medium
  );

  TextStyle textS16MediumWhite =  const TextStyle(
      color: AppColors.whiteColor,
      fontSize: 16,
      fontFamily: font_name.Poppins_Medium
  );
  TextStyle textS14MediumWhite =  const TextStyle(
      color: AppColors.whiteColor,
      fontSize: 14,
      fontFamily: font_name.Poppins_Regular
  );
  TextStyle textS14Regulargrey =  const TextStyle(
      color: AppColors.grey,
      fontSize: 14,
      fontFamily: font_name.Poppins_Regular
  );

  TextStyle textS14MediumPriTextColor =  const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 14,
      fontFamily: font_name.Poppins_Medium
  );
  TextStyle textS14RegularwhiteColor =  TextStyle(
      color: AppColors.whiteColor.withOpacity(0.6),
      fontSize: 14,
      fontFamily: font_name.Poppins_Regular
  );
  TextStyle textS16Semibold =  const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 16,
      fontFamily: font_name.Poppins_SemiBold
  );
  TextStyle textS16Semiboldred =  const TextStyle(
      color: AppColors.red,
      fontSize: 20,
      fontFamily: font_name.Poppins_SemiBold
  );

  TextStyle textS14Semiboldred =  const TextStyle(
      color: AppColors.red,
      fontSize: 14,
      fontFamily: font_name.Poppins_SemiBold
  );

  TextStyle textS14SemiboldlOrgeng=  const TextStyle(
      color: AppColors.orange,
      fontSize: 14,
      fontFamily: font_name.Poppins_SemiBold
  );
  TextStyle textS14SemiboldGreen=   const TextStyle(
      color: AppColors.green,
      fontSize: 14,
      fontFamily: font_name.Poppins_SemiBold
  );


  TextStyle textS16SemiboldBlue =  const TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 16,
      fontFamily: font_name.Poppins_SemiBold
  );


  TextStyle textS20SemiboldPtc = const TextStyle(
      color: AppColors.primaryTextColor,
      fontSize: 20,
      fontFamily: font_name.Poppins_SemiBold
  );
  TextStyle textS20SemiboldBlue = const TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 20,
      fontFamily: font_name.Poppins_SemiBold
  );
  TextStyle textS12RegularOpacity =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.6),
      fontSize: 12,
      fontFamily: font_name.Poppins_Regular
  );
  TextStyle textS14RegularOpacity04 =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.4),
      fontSize: 14,
      fontFamily: font_name.Poppins_Regular
  );

  TextStyle textS12RegularOpacity04 =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.4),
      fontSize: 12,
      fontFamily: font_name.Poppins_Regular
  );

  TextStyle textS14RegularOpacity =  TextStyle(
      color: AppColors.primaryTextColor.withOpacity(0.6),
      fontSize: 14,
      fontFamily: font_name.Poppins_Regular
  );
  TextStyle textS14Regularblack =  const TextStyle(
      color: AppColors.black,
      fontSize: 14,
      fontFamily: font_name.Poppins_Regular
  );
  TextStyle textS14RegularBlue =  const TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 14,
      fontFamily: font_name.Poppins_Regular
  );
  TextStyle textS14MediumBlue =  const TextStyle(
      color: AppColors.primaryColorBlue,
      fontSize: 14,
      fontFamily: font_name.Poppins_Medium
  );
}