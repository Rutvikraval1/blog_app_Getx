
import 'package:flutter/material.dart';

class AppColors {
  static const primaryColorBlue = Color(0xFF2B3386);
  static const primaryTextColor = Color(0xFF121538);
  static const primarybutton = Color(0xFFFBAF43);
  static const whiteColor = Color(0xFFFFFFFF);
  static const whiteColor_45 = Color(0xffF5F5F5);
  static const whiteColorf8f8 = Color(0xffF8F8F8);
  static const black = Color(0xff121313);
  static const red = Colors.red;
  static const green = Colors.green;
  static const orange = Colors.orange;
  static const transparent = Colors.transparent;
  static const lightblue = Color(0xff948BFF);
  static const lightgreen = Color(0xffff7854);
  static const lightorgeng = Color(0xfffea725);
  static const lightgrey = Color(0xff28ce6c);
  static const grey =Colors.grey;
}

