
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:pushcart/pages/page_route_name.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../service/DownloadFile.dart';
import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../button/cus_navigateBtn.dart';
import '../downloadAPK/downloadAPK.dart';
import '../loader/alertBoxLoader.dart';

class UpdateApp{
  DialogBox({String updateLink=''}){
    return Get.dialog(
        WillPopScope(
          onWillPop: () => Future(() => false,),
          child: AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.0),
              ),
              titlePadding: const EdgeInsets.symmetric(vertical: 10),
              title:  const Center(child: Text("App Update")),
              titleTextStyle: App_style().textS20SemiboldBlue,
              contentPadding: const EdgeInsets.symmetric(horizontal: 20),
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  cus_size_box().sizedBox_8,
                  Text('New Update Available', style: App_style().textS16withOpacity),
                  cus_size_box().sizedBox_8,
                  SizedBox(
                    width: double.infinity,
                    child: cus_navigateBtn(
                      onPressed: () async {
                        Get.back();
                         _launchUrl(updateLink);

                      },
                      text: 'Update',
                    ),
                  ),
                  cus_size_box().sizedBox_10,
                ],
              ),
          ),
        )
    );
  }

  Future<void> _launchUrl(updateLink) async {
   //  String path="/storage/emulated/0/Android/data/com.pushcart.pushcart/files/PushCart.apk";
   // try{
   //   final result = await  OpenFilex.open(path);
   //   print('result');
     print("updateLink");
     print(updateLink);
   // }catch(e){
   //   print('e');
   //   print(e);
   // }

    if(await Permission.requestInstallPackages.request().isGranted){
      if (await Permission.manageExternalStorage.request().isGranted) {
        Get.to(() => DownloadapkScreen(fileName:Common_text.PushCartAPK ,linkurl: updateLink,));
        // DownloadFile().downloadFile(, );
      }
    }


    // final Uri _url = Uri.parse(updateLink);
    // print("_url");
    // print(_url);
    // if (!await launchUrl(_url,mode: LaunchMode.externalApplication)) {
    //   throw Exception('Could not launch $_url');
    // }
  }
}