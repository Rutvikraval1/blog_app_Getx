
import 'package:flutter/material.dart';

import '../../utils/app_style.dart';

class Custom_AlertDialog{

  AlertDialogBox({
    required BuildContext context,
    required String  title,
    Widget? content
}){
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.0),
          ),
          titlePadding: const EdgeInsets.symmetric(vertical: 10),
          title: Stack(
            children: [
              Column(
                children: [
                  Text(title),
                  const Divider(height: 5,)
                ],
              ),
              Positioned(
                  right: 10,
                  child: InkWell(
                      onTap: (){
                        Navigator.pop(context);
                      },
                      child: const Icon(Icons.close)))
            ],
          ),
          titleTextStyle: App_style().textS20SemiboldBlue,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20),
          content: SizedBox(
              width: double.maxFinite,
              child: content)
        );
      },
    );

  }
}

