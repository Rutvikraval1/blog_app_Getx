

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../utils/app_style.dart';
import '../button/cus_navigateBtn.dart';

class CusReponseMess{
  DialogBox({
     bool  errorType=false,
    required String reposMess
  }){
    return Get.dialog(
        AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8.0),
            ),
            titlePadding: const EdgeInsets.symmetric(vertical: 10),
            title: Stack(
              children: [
                Column(
                  children: [
                    Text(!errorType?"Success":"Failed"),
                    const Divider(height: 5,)
                  ],
                ),
                Positioned(
                    right: 10,
                    child: InkWell(
                        onTap: (){
                         Get.back();
                        },
                        child: const Icon(Icons.close)))
              ],
            ),
            titleTextStyle: App_style().textS20SemiboldBlue,
            contentPadding: const EdgeInsets.symmetric(horizontal: 20),
            content: SizedBox(
                width: double.maxFinite,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(reposMess,style:errorType?App_style().textS14Semiboldred:App_style().textS16Semiboldred,),
                    const SizedBox(height: 10,),
                    SizedBox(
                      width:  double.maxFinite,
                      child: cus_navigateBtn(
                        onPressed: () {
                          Get.back();
                        },
                        text: 'Ok',
                      ),
                    ),
                    const SizedBox(height: 10,),
                  ],
                ))
        )
    );
  }
}