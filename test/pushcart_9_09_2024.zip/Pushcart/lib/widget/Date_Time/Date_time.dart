
import 'package:intl/intl.dart';

class Date_Time{
  // DateTim
  static String  millisecondsDateTime  = DateTime.now().millisecondsSinceEpoch.toString();
  // static DateTime now = DateTime.now();
  static String currentYear = DateTime.now().year.toString();

  String DateTimeCurrent() {
    String datetime= DateFormat('yyyy-MM-dd').format(DateTime.now());
    return datetime;
  }

  String TimeCurrent() {
    print(DateTime.now());
    String datetime= DateFormat('kk:mm:ss').format(DateTime.now());
    return datetime;
  }

  String ShowDateTime({DateTime? dateTime}) {
    String datetime= DateFormat('dd-MM-yyyy').format(dateTime??DateTime.now());
    return datetime.toString();
  }

  String ShowDateDDMMMY({DateTime? dateTime}) {
    String datetime= DateFormat('dd-MMM-yyyy').format(dateTime??DateTime.now());
    return datetime.toString();
  }

  String DateYYYY_MM_DD(String current_date) {
    try {
      if (current_date != '') {
        var inputFormat = DateFormat("dd-MM-y");
        var inputDate = inputFormat.parse(current_date);
        var outputFormat = DateFormat('yyyy-MM-dd');
        var DDMMY = outputFormat.format(inputDate);
        return DDMMY;
      } else {
        return '';
      }
    } catch (e) {
      return '';
    }
  }


  String DateTimeYY_MM_DD(String current_date) {
    try {
      if (current_date != '') {
        var inputFormat = DateFormat("yyyy-MM-dd'T'HH:mm:ssz");
        var inputDate = inputFormat.parse(current_date);
        var outputFormat = DateFormat('yyyy-MM-dd');
        var DDMMY = outputFormat.format(inputDate);
        return DDMMY;
      } else {
        return '';
      }
    } catch (e) {
      return '';
    }
  }


  String DateTimeDD_MM_Y(String current_date) {
    try {
      if (current_date != '') {
        var inputFormat = DateFormat("yyyy-MM-dd'T'HH:mm:ssz");
        var inputDate = inputFormat.parse(current_date);
        var outputFormat = DateFormat('dd-MMM-yyyy');
        var DDMMY = outputFormat.format(inputDate);
        return DDMMY;
      } else {
        return '';
      }
    } catch (e) {
      return '';
    }
  }



  bool DateComparison({String apiDate='',String seletedDate=""}){
    DateTime dt1 = DateTime.parse(apiDate);
    DateTime dt2 = DateTime.parse(seletedDate);
    if(dt2.isBefore(dt1)){
      print("dt2 is after dt1");
      return false;
    }else{
      print("dt2 is befor dt1");
      return true;
    }
  }


}