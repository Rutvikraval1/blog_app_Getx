
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../utils/app_locale.dart';
import '../utils/app_style.dart';
import '../utils/custColors.dart';

class Hocco_Support extends StatelessWidget {
  final bool isShowColumn;
  const Hocco_Support({super.key,this.isShowColumn=false});

  final  String Number1='+91 8153066004';
  final  String Number2='+91 8153066005';

  @override
  Widget build(BuildContext context) {
    return Container(
      color:AppColors.grey.shade200,
      padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Hocco Support",
            style: App_style().textS14MediumPriTextColor,
          ),
          cus_size_box().sizedBox_10,
          if(isShowColumn)
            Column(
            children: [
              InkWell(
                onTap: (){
                  _callMe(Number1);
                },
                child: Row(
                  children: [
                    const Icon(Icons.call),
                    Text(Number1),
                  ],
                ),
              ),
              cus_size_box().sizedBox_5,
              InkWell(
                onTap: (){
                  _callMe(Number2);
                },
                child: Row(
                  children: [
                    const Icon(Icons.call),
                    Text(Number2)
                  ],
                ),
              ),
            ],
          )
          else
            Row(
            children: [
              Expanded(child: InkWell(
                onTap: (){
                  _callMe(Number1);
                },
                child: Row(
                  children: [
                    const Icon(Icons.call),
                    Text(Number1),
                  ],
                ),
              )),
              Expanded(child: InkWell(
                onTap: (){
                  _callMe(Number2);
                },
                child: Row(
                  children: [
                    const Icon(Icons.call),
                    Text(Number2)
                  ],
                ),
              ))
            ],
          )
        ],
      ),
    );
  }

  _callMe(phoneNo) async {
    var uri = 'tel:$phoneNo';
    if (await canLaunch(uri)) {
      await launch(uri);
    } else {
      throw 'Could not launch $uri';
    }
  }
}
