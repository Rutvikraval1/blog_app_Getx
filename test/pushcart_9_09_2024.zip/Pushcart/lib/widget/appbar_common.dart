import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:pushcart/utils/custColors.dart';

import '../controller/cartCounter.dart';
import '../utils/app_locale.dart';
import '../utils/app_style.dart';
import 'img_show/Image_show.dart';

PreferredSizeWidget appbarCommon(
    {
      String? title_text,
      String? CustId,
    Function? calender_ontap,
    Function? leading_ontap,
    Function? cart_ontap,
    Function? sales_cart_ontap,
    Function? filter_ontap}) {
  return AppBar(
    title: title_text != null ? Text(title_text) : null,
    titleSpacing: 0,
    centerTitle: true,
    titleTextStyle: App_style().textS16SemiboldPtc,
    backgroundColor:AppColors.whiteColor_45,
    surfaceTintColor: AppColors.whiteColor_45,
    leadingWidth: leading_ontap != null ? 65 : 20,
    automaticallyImplyLeading: false,
    leading: leading_ontap != null
        ? Padding(
            padding: const EdgeInsets.only(left: 20, top: 8),
            child: GestureDetector(
                onTap: () {
                  leading_ontap();
                },
                child: Image_show()
                    .SvgPicture_asset(AppImages.back_arrow, width: 25)),
          )
        : const SizedBox(),
    iconTheme: const IconThemeData(color: Colors.black),
    elevation: 0,
    actions: [
      //Calender icon
      calender_ontap != null
          ? Padding(
              padding: const EdgeInsets.only(right: 20),
              child: InkWell(
                onTap: () {
                  calender_ontap();
                },
                child: Image_show().Img_asset(AppImages.calendar_icon,
                    width: 20, color_code: AppColors.primaryColorBlue),
              ),
            )
          : const SizedBox(),

      //filter icon
      filter_ontap != null
          ? Padding(
              padding: const EdgeInsets.only(right: 20),
              child: InkWell(
                onTap: () {
                  filter_ontap();
                },
                child: Image_show().Img_asset(AppImages.filter_icon,
                    width: 30, color_code: AppColors.primaryColorBlue),
              ),
            )
          : const SizedBox(),
      //sales cart icon
      sales_cart_ontap != null
          ? Padding(
        padding: const EdgeInsets.only(right: 20),
        child: InkWell(
          onTap: () {
            sales_cart_ontap();
          },
          child: Stack(
            children: [
              Align(
                // alignment: Alignment.bottomCenter,
                  child: Image_show().Img_asset(AppImages.cart_icon,
                      width: 30, color_code: AppColors.primaryColorBlue)),
              Positioned(
                top: 4,
                right: 5,
                child: GetBuilder<SalesCartCounter>(
                  init: SalesCartCounter(CustId: CustId??''), // intialize with the Controller
                  builder: (value) => Text(
                    value.lst!.isEmpty ? '' : value.lst!.length.toString(),
                    style: App_style().textS16Semiboldred,
                  ),
                ),
              ),
            ],
          ),
        ),
      )
          : const SizedBox(),

      //cart icon
      cart_ontap != null
          ? Padding(
              padding: const EdgeInsets.only(right: 20),
              child: InkWell(
                onTap: () {
                  cart_ontap();
                },
                child: Stack(
                  children: [
                    Align(
                        // alignment: Alignment.bottomCenter,
                        child: Image_show().Img_asset(AppImages.cart_icon,
                            width: 30, color_code: AppColors.primaryColorBlue)),
                    Positioned(
                      top: 4,
                      right: 5,
                      child: GetBuilder<CartCounter>(
                        init: CartCounter(), // intialize with the Controller
                        builder: (value) => Text(
                          value.lst!.isEmpty ? '' : value.lst!.length.toString(),
                          style: App_style().textS16Semiboldred,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          : const SizedBox()
    ],
  );
}

PreferredSizeWidget MainAppBar(
    {required String title, String? menu_icon, Function? noti_fun}) {
  return AppBar(
    titleSpacing: 0,
    title: Text(title),
    centerTitle: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(
        bottom: Radius.circular(30),
      ),
    ),
    titleTextStyle: App_style().textS16SemiboldwhiteColor,
    backgroundColor: AppColors.primaryColorBlue.withOpacity(0.9),
    surfaceTintColor: AppColors.whiteColor_45,
    leadingWidth: menu_icon != null ? 65 : 20,
    automaticallyImplyLeading: false,
    leading: menu_icon != null
        ? Padding(
            padding: const EdgeInsets.only(left: 20, top: 2),
            child: Builder(
              builder: (context) => InkWell(
                  onTap: () {
                    Scaffold.of(context).openDrawer();
                  },
                  child: Image_show().SvgPicture_asset(AppImages.menu_icon,color_code: AppColors.whiteColor)),
            ),
          )
        : null,
    iconTheme: const IconThemeData(color: Colors.black),
    actions: [
      noti_fun != null
          ? Image_show().SvgPicture_asset(AppImages.notification_icon,color_code: AppColors.whiteColor)
          : const SizedBox(),
      const SizedBox(
        width: 12,
      ),
    ],
    elevation: 5,
  );
}
