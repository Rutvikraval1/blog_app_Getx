
import 'package:flutter/material.dart';
import 'package:flutter_bounceable/flutter_bounceable.dart';
import 'package:pushcart/widget/img_show/Image_show.dart';

import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../utils/custColors.dart';

class menuCard extends StatelessWidget {
  final String title_name;
  final String image_path;
  final Function onTap;
  final Color backgroundColor;
  const menuCard({super.key,required  this.title_name,
    required  this.image_path,required this.onTap,required this.backgroundColor
  });

  @override
  Widget build(BuildContext context) {
    return Bounceable(
      onTap: (){
        onTap();
      },
      child: Card(
        surfaceTintColor: AppColors.whiteColor,
        color: backgroundColor,
        elevation: 3,
        shadowColor: AppColors.grey,
        child: SizedBox(
          height: 160,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Card(
                  surfaceTintColor: AppColors.whiteColor,
                  color: AppColors.whiteColor,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Image_show().Img_asset(image_path,height: 40,color_code: backgroundColor),
                  ),
                ),
                cus_size_box().sizedBox_5,
                Text(title_name,textAlign: TextAlign.center,maxLines:2,style: App_style().textS16MediumWhite,)
              ],
            ),
          ),
        ),
      ),
    );
  }
}
