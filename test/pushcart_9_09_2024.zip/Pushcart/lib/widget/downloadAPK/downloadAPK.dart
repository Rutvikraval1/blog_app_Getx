import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get_connect/http/src/request/request.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pushcart/utils/app_locale.dart';
import 'package:pushcart/utils/app_style.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import "package:http/http.dart" as http;
import '../AlertDialog/ResponseMessageShow.dart';

class DownloadapkScreen extends StatefulWidget {
  final String linkurl;
  final String fileName;
  const DownloadapkScreen(
      {super.key, required this.fileName, required this.linkurl});

  @override
  State<DownloadapkScreen> createState() => _DownloadapkScreenState();
}

class _DownloadapkScreenState extends State<DownloadapkScreen> {
  double progressBarValue = 0;
  double maxValue = 100.0;
  HttpClient httpClient = HttpClient();
  String _message = '';
  @override
  void initState() {
    // TODO: implement initState
    downloadFile();
    super.initState();
  }
  Future<dynamic> downloadFile() async {
    String filePath = '';
    try {
      var request = await httpClient.getUrl(Uri.parse(widget.linkurl));
      var response = await request.close();
      if(response.statusCode == 200) {
        Directory? externalDir = await getExternalStorageDirectory();
        if (externalDir == null) {
          throw Exception("External storage directory not found");
        }
        File destinationFile = File('${externalDir.path}/${widget.fileName}');
        int totalBytes = response.contentLength ?? 0;
        int bytesReceived = 0;
        print("totalBytes");
        print(totalBytes);
        var sink = destinationFile.openWrite();
        response.listen( (List<int> chunk) {
          print("sddsd");
          print(chunk.length);
          bytesReceived += chunk.length;
          sink.add(chunk);
          setState(() {
            progressBarValue =  (bytesReceived / totalBytes) * 100 ;
            print("progressBarValue");
            print(progressBarValue);
          });
        },
          onDone: () async {
            await sink.flush();
            await sink.close();
            final result = await OpenFile.open(destinationFile.path);
          },
          onError: (error) {
            _message = 'Download error: $error';
            CusReponseMess()
                .DialogBox(reposMess: _message, errorType: true);
          },
          cancelOnError: true,);
        // var bytes = await consolidateHttpClientResponseBytes(response);
        // print("bytes");
        // print(bytes);
        // await destinationFile.writeAsBytes(bytes);
        // destinationFile.open();
        // final result = await  OpenFile.open(destinationFile.path);
        print('result');
        // print(result.message);
        // print(result.type);
      }
      else {
        filePath = 'Error code: ${response.statusCode}';
        CusReponseMess().DialogBox(reposMess: filePath,errorType: true);
      }
    }
    catch(ex){
      filePath = 'Can not fetch url $ex';
      CusReponseMess().DialogBox(reposMess: filePath,errorType: true);

    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => Future(() => false,),
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Download Pushcart APK File",style: App_style().textS16MediumPtc,),
                cus_size_box().sizedBox_20,
                SfRadialGauge(axes: <RadialAxis>[
                  RadialAxis(
                      minimum: 0,
                      maximum: 100,
                      showLabels: false,
                      showTicks: false,
                      startAngle: 270,
                      endAngle: 270,
                      axisLineStyle: const AxisLineStyle(
                        thickness: 0.05,
                        color: Color.fromARGB(100, 0, 169, 181),
                        thicknessUnit: GaugeSizeUnit.factor,
                      ),
                      pointers: <GaugePointer>[
                        RangePointer(
                            value: progressBarValue,
                            width: 0.1,
                            sizeUnit: GaugeSizeUnit.factor,
                            cornerStyle: progressBarValue == maxValue
                                ? CornerStyle.bothFlat
                                : CornerStyle.bothCurve)
                      ],
                      annotations: <GaugeAnnotation>[
                        GaugeAnnotation(
                            widget: Text('${progressBarValue.toStringAsFixed(0)}%',
                                // 10.toStringAsFixed(0) + ' / 100%',
                                style: const TextStyle(
                                    fontSize: 25, fontWeight: FontWeight.w500)),
                            angle: 90)
                      ])
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
