import 'package:flutter/material.dart';
import 'package:pushcart/utils/app_locale.dart';
import 'package:pushcart/utils/app_style.dart';
import 'package:pushcart/widget/Scaffold_widget.dart';
import 'package:pushcart/widget/img_show/Image_show.dart';

class Emptyscreen extends StatelessWidget {
  final String? cartimgPath;
  const Emptyscreen({super.key,this.cartimgPath});

  @override
  Widget build(BuildContext context) {
    return Scaffold_widget(
        body: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: cartimgPath==null?MediaQuery.of(context).size.height / 2.5:MediaQuery.of(context).size.height / 3,
            child: Image_show().Img_asset(cartimgPath??AppImages.empt_icon),
          ),
          cus_size_box().sizedBox_20,
          Text(
            cartimgPath==null?'Data Not Available':'Your cart is empty!',
            style: App_style().textS20SemiboldBlue,
          )
        ],
      ),
    ));
  }
}
