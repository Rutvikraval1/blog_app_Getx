
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../utils/app_locale.dart';
import '../../utils/app_style.dart';
import '../../utils/custColors.dart';
import '../img_show/Image_show.dart';
class CustomInput extends StatefulWidget {
  final String? hintText;
  final bool? suffixIcon;
  final bool? hintStyle;
  final int? digitsOnlyNo;
  final int? maxLines;
  final TextEditingController controller;
  final GestureTapCallback? onTap;

  const CustomInput(
      {Key? key,this.digitsOnlyNo,this.maxLines,this.onTap,this.hintStyle,
        required this.controller,this.hintText,this.suffixIcon=false})
      : super(key: key);

  @override
  State<CustomInput> createState() => _CustomInputState();
}

class _CustomInputState extends State<CustomInput> {
  bool _passwordVisible = false;
  DateTime? pickedDate;
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      maxLines: widget.maxLines ?? (!widget.suffixIcon!?null:1),
      // style: App_style().text_16_700_black,
      obscureText: !widget.suffixIcon!?false:!_passwordVisible,
      inputFormatters:  widget.digitsOnlyNo!=null? [FilteringTextInputFormatter.digitsOnly,
      LengthLimitingTextInputFormatter(widget.digitsOnlyNo)
      ]:null,
        keyboardType: widget.digitsOnlyNo!=null?TextInputType.number:null,
      decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:  BorderSide(
                width: 0.8,
                color: AppColors.primaryTextColor.withOpacity(0.5)
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:  BorderSide(
                width: 0.8,
                color: AppColors.primaryTextColor.withOpacity(0.5)
              // style: BorderStyle.,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:  BorderSide(
                width: 0.8,
                color: AppColors.primaryTextColor.withOpacity(0.5)
            ),
          ),
          disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:  BorderSide(
                width: 0.8,
                color: AppColors.primaryTextColor.withOpacity(0.5)
            ),
          ),
          fillColor: AppColors.whiteColor,
          hintText: widget.hintText,
          hintStyle:widget.hintStyle!=null?App_style().textS12RegularOpacity04 :App_style().textS14RegularOpacity04,
          contentPadding: EdgeInsets.symmetric(horizontal: 20,vertical: widget.maxLines==null?0:10),
          suffixIcon: widget.suffixIcon!?Padding(
            padding: const EdgeInsets.only(right: 10),
            child: GestureDetector(
                onTap: (){
                  _passwordVisible = !_passwordVisible;
                  setState(() {});
                  },
                child:Image_show().SvgPicture_asset(AppImages.eye_icon,)),
          ):null,
          suffixIconConstraints: const BoxConstraints(minHeight: 25),
      ),
      readOnly: widget.onTap==null?false:true,
      onTap: widget.onTap,
    );
  }

  bool validateEmail(String value) {
    RegExp regex = RegExp(r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$');
    return (!regex.hasMatch(value)) ? false : true;
  }

}







