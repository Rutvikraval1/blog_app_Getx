
import 'package:flutter/material.dart';
import 'package:pushcart/utils/custColors.dart';

import '../../utils/app_style.dart';

class Custom_DropDown extends StatefulWidget {
  final ValueChanged<String> onChanged;
  final List itemsValue;
  final String hintText;
  const Custom_DropDown({super.key,required this.hintText,required this.onChanged,required this.itemsValue});

  @override
  State<Custom_DropDown> createState() => _Custom_DropDownState();
}

class _Custom_DropDownState extends State<Custom_DropDown> {
  var selected_value;

  @override
  Widget build(BuildContext context) {
    return  Container(
      height: 50,
      width: double.infinity,
      padding: const EdgeInsets.all(5.0),
      decoration: BoxDecoration(
        color: AppColors.whiteColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
            color:  AppColors.primaryTextColor.withOpacity(0.5), width: 0.8,),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<dynamic>(
          elevation: 0,
          value: selected_value,
          icon: const Icon(Icons.keyboard_arrow_down),
          hint: Text(widget.hintText,style: App_style().textS16withOpacity),
          padding: const EdgeInsets.only(left: 10),
          items:widget.itemsValue.map((items) {
            return DropdownMenuItem(
                value: items,
                child: Text(items)
            );
          }).toList(),
          onChanged: (newValue){
            selected_value = newValue!;
            setState(() {});
            widget.onChanged(newValue);
          },
        ),
      ),
    );
  }
}
