
import 'package:flutter/material.dart';

import '../../utils/app_style.dart';

class SearchInput extends StatefulWidget {
 final  TextEditingController textcontroller;
 final  ValueChanged<String> onChanged;
 final  String  hintText;

  const SearchInput({super.key,required this.hintText,required this.textcontroller,required this.onChanged});

  @override
  State<SearchInput> createState() => _SearchInputState();
}

class _SearchInputState extends State<SearchInput> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      cursorColor: Colors.grey,
      controller: widget.textcontroller,
      onChanged: (value){
        widget.onChanged(value);
      },
      decoration: InputDecoration(
          fillColor: Colors.white,
          filled: true,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none
          ),
          hintText: widget.hintText,
          hintStyle: App_style().textS16withOpacity,
          prefixIcon: Container(
            padding: const EdgeInsets.all(0),
            width: 18,
            child: const Icon(Icons.search),
          )
      ),
    );
  }
}