

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'loader.dart';

class LoaderAlert{
  ShowLoader({
     BuildContext? context,
  }){
    return Get.dialog(
        WillPopScope(
          onWillPop: () => Future.value(false),
          child: AlertDialog(
              backgroundColor: Colors.transparent,
              surfaceTintColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.0),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 20),
              content: SizedBox(
                width: double.maxFinite,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Loader(),
                  ],
                ),
              )
          ),
        )
    );

  }

}